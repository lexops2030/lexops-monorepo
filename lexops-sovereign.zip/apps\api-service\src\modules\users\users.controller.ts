import { Controller, Get, Param, Request, Version } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { UsersRepository } from './users.repository';
import { Roles } from '../auth/firebase.guard';
import { Request as ExpressRequest } from 'express';
import type { LexOpsClaims } from '../auth/firebase.guard';

@ApiTags('Users')
@ApiBearerAuth('Firebase-JWT')
@Controller('users')
export class UsersController {
  constructor(private readonly usersRepo: UsersRepository) {}

  @Get('me')
  @Version('1')
  async getMe(@Request() req: ExpressRequest & { user: LexOpsClaims }) {
    if (!req.user.tenantId) return { uid: req.user.uid, role: req.user.role };
    return this.usersRepo.findByUid(req.user.tenantId, req.user.uid);
  }

  @Get('tenant/:tenantId')
  @Version('1')
  @Roles('sovereign', 'entity_admin')
  findAllInTenant(
    @Param('tenantId') tenantId: string,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    // Entity admins can only query their own tenant
    const targetTenant = req.user.role === 'sovereign' ? tenantId : req.user.tenantId!;
    return this.usersRepo.findAllInTenant(targetTenant);
  }
}
