/**
 * LexOps — Attendance Repository
 *
 * Attendance records follow the C9 Ledger principle:
 *   - CREATE is always allowed.
 *   - UPDATE is restricted to the `status` and `review` fields only.
 *     (raw location data, timestamps, and HMAC fields are immutable)
 *   - DELETE is never allowed (enforced at Firestore rules level).
 */

import {
  Injectable, Inject,
  NotFoundException, ConflictException,
} from '@nestjs/common';
import { Firestore, FieldValue } from '@google-cloud/firestore';
import type { GeofenceResult } from './geofence.service';
import type { SpoofCheckResult } from './spoof.service';

// ── Types ─────────────────────────────────────────────────────────────────────

export type AttendanceStatus = 'accepted' | 'pending_review' | 'rejected';
export type AttendanceEventType = 'check_in' | 'check_out';

export interface AttendanceReview {
  reviewedBy: string;              // Admin UID
  reviewedAt: FirebaseFirestore.Timestamp;
  decision: 'accepted' | 'rejected';
  reason: string;
}

export interface AttendanceRecord {
  recordId: string;
  tenantId: string;
  employeeUid: string;
  branchId: string;
  eventType: AttendanceEventType;
  status: AttendanceStatus;

  // ── Geolocation (immutable after creation) ──────────────────────────────
  lat: number;
  lng: number;
  accuracy: number;
  distanceMeters: number;
  isMock: boolean;
  isMockSuspected: boolean;
  spoofReason: string | null;
  geofenceReason: string;
  velocityMps: number | null;

  // ── Device fingerprint ──────────────────────────────────────────────────
  deviceId?: string;
  deviceTimestampMs: number;        // Device-reported epoch ms
  serverTimestampMs: number;        // Server-side epoch ms (tamper-proof)
  ipAddress?: string;

  // ── Review (mutable — admin only) ──────────────────────────────────────
  review?: AttendanceReview;

  // ── Metadata ────────────────────────────────────────────────────────────
  createdAt: FirebaseFirestore.Timestamp;
  updatedAt: FirebaseFirestore.Timestamp;
}

// ── Repository ────────────────────────────────────────────────────────────────

@Injectable()
export class AttendanceRepository {
  constructor(@Inject('FIRESTORE') private readonly db: Firestore) {}

  private recordRef(tenantId: string, recordId: string) {
    return this.db
      .collection('entities').doc(tenantId)
      .collection('attendance').doc(recordId);
  }

  private attendanceCol(tenantId: string) {
    return this.db.collection('entities').doc(tenantId).collection('attendance');
  }

  async findById(tenantId: string, recordId: string): Promise<AttendanceRecord | null> {
    const snap = await this.recordRef(tenantId, recordId).get();
    return snap.exists ? (snap.data() as AttendanceRecord) : null;
  }

  /** Retrieve the latest check-in for an employee (for anti-spoof velocity check) */
  async findLatestCheckIn(
    tenantId: string,
    employeeUid: string,
  ): Promise<AttendanceRecord | null> {
    const snap = await this.attendanceCol(tenantId)
      .where('employeeUid', '==', employeeUid)
      .where('eventType', '==', 'check_in')
      .orderBy('serverTimestampMs', 'desc')
      .limit(1)
      .get();
    return snap.empty ? null : (snap.docs[0].data() as AttendanceRecord);
  }

  /** Find the open (un-checked-out) check-in for an employee */
  async findOpenCheckIn(
    tenantId: string,
    employeeUid: string,
  ): Promise<AttendanceRecord | null> {
    const snap = await this.attendanceCol(tenantId)
      .where('employeeUid', '==', employeeUid)
      .where('eventType', '==', 'check_in')
      .where('status', 'in', ['accepted', 'pending_review'])
      .orderBy('serverTimestampMs', 'desc')
      .limit(1)
      .get();
    return snap.empty ? null : (snap.docs[0].data() as AttendanceRecord);
  }

  /** List records pending admin review */
  async findPendingReview(
    tenantId: string,
    limit = 50,
  ): Promise<AttendanceRecord[]> {
    const snap = await this.attendanceCol(tenantId)
      .where('status', '==', 'pending_review')
      .orderBy('createdAt', 'asc')
      .limit(limit)
      .get();
    return snap.docs.map((d) => d.data() as AttendanceRecord);
  }

  /** Query all records for a specific employee */
  async findByEmployee(
    tenantId: string,
    employeeUid: string,
    limit = 30,
  ): Promise<AttendanceRecord[]> {
    const snap = await this.attendanceCol(tenantId)
      .where('employeeUid', '==', employeeUid)
      .orderBy('serverTimestampMs', 'desc')
      .limit(limit)
      .get();
    return snap.docs.map((d) => d.data() as AttendanceRecord);
  }

  /** Create an immutable attendance record */
  async create(
    tenantId: string,
    recordId: string,
    data: Omit<AttendanceRecord, 'recordId' | 'tenantId' | 'createdAt' | 'updatedAt'>,
  ): Promise<AttendanceRecord> {
    const ref = this.recordRef(tenantId, recordId);
    const doc: AttendanceRecord = {
      ...data,
      recordId,
      tenantId,
      createdAt: FieldValue.serverTimestamp() as FirebaseFirestore.Timestamp,
      updatedAt: FieldValue.serverTimestamp() as FirebaseFirestore.Timestamp,
    };
    await ref.set(doc);
    return doc;
  }

  /**
   * Apply a review decision (admin only).
   * Only `status`, `review`, and `updatedAt` are mutated — all raw fields stay intact.
   */
  async applyReview(
    tenantId: string,
    recordId: string,
    review: AttendanceReview,
  ): Promise<void> {
    const ref = this.recordRef(tenantId, recordId);
    const snap = await ref.get();

    if (!snap.exists) {
      throw new NotFoundException(
        `Attendance record '${recordId}' not found in tenant '${tenantId}'`,
      );
    }

    const record = snap.data() as AttendanceRecord;
    if (record.status !== 'pending_review') {
      throw new ConflictException(
        `Record '${recordId}' is already '${record.status}' and cannot be reviewed again.`,
      );
    }

    await ref.update({
      status: review.decision,
      review,
      updatedAt: FieldValue.serverTimestamp(),
    });
  }
}
