import {
  Controller, Get, Post, Patch, Delete,
  Param, Body, Request, Version,
  UseGuards, Query,
} from '@nestjs/common';
import {
  ApiTags, ApiBearerAuth, ApiOperation,
  ApiParam, ApiQuery,
} from '@nestjs/swagger';
import {
  IsEnum, IsNotEmpty, IsOptional,
  IsString, IsDateString, IsUrl, IsNumber, IsPositive,
} from 'class-validator';
import { LeavesService } from './leaves.service';
import { LeaveType, LeaveStatus } from './leaves.repository';
import { Roles } from '../auth/firebase.guard';
import { TenantScopeGuard } from '../../common/guards';
import { Request as ExpressRequest } from 'express';
import type { LexOpsClaims } from '../auth/firebase.guard';

// ── DTOs ──────────────────────────────────────────────────────────────────────

class RequestLeaveDto {
  @IsEnum(['annual', 'sick', 'unpaid', 'other'])
  leaveType: LeaveType;

  @IsDateString()
  startDate: string;

  @IsDateString()
  endDate: string;

  @IsString() @IsNotEmpty()
  reason: string;

  @IsUrl() @IsOptional()
  attachmentUrl?: string;

  /** Override per-employee entitlement (admin use). Defaults to 21 days. */
  @IsNumber() @IsPositive() @IsOptional()
  annualEntitlement?: number;
}

class ReviewLeaveDto {
  @IsEnum(['approved', 'rejected'])
  decision: 'approved' | 'rejected';

  @IsString() @IsNotEmpty()
  reason: string;
}

// ── Controller ────────────────────────────────────────────────────────────────

@ApiTags('Leaves — Leave Management & Policies')
@ApiBearerAuth('Firebase-JWT')
@Controller('entities/:tenantId/leaves')
@UseGuards(TenantScopeGuard)
export class LeavesController {
  constructor(private readonly leavesService: LeavesService) {}

  // ── GET /my — Employee: own leaves only ─────────────────────────────────────
  @Get('my')
  @Version('1')
  @Roles('employee', 'entity_admin', 'sovereign')
  @ApiOperation({ summary: 'سجل إجازات الموظف المُسجَّل — للموظف فقط' })
  @ApiParam({ name: 'tenantId' })
  getMyLeaves(
    @Param('tenantId') tenantId: string,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.leavesService.findMyLeaves(tenantId, req.user.uid);
  }

  // ── GET / — Admin: all tenant leaves ────────────────────────────────────────
  @Get()
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'جميع طلبات إجازات المنشأة — للمدير فقط' })
  @ApiQuery({ name: 'status',    required: false, enum: ['requested','approved','rejected','cancelled'] })
  @ApiQuery({ name: 'leaveType', required: false, enum: ['annual','sick','unpaid','other'] })
  findAll(
    @Param('tenantId') tenantId: string,
    @Query('status')    status?: LeaveStatus,
    @Query('leaveType') leaveType?: LeaveType,
  ) {
    return this.leavesService.findAll(tenantId, { status, leaveType });
  }

  // ── POST / — Employee: submit new request ───────────────────────────────────
  @Post()
  @Version('1')
  @Roles('employee', 'entity_admin', 'sovereign')
  @ApiOperation({
    summary:
      'تقديم طلب إجازة — يُطبَّق محرك السياسات (تداخل / رصيد / نطاق). يُختم في C9.',
  })
  requestLeave(
    @Param('tenantId') tenantId: string,
    @Body() dto: RequestLeaveDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.leavesService.requestLeave(tenantId, {
      ...dto,
      employeeUid: req.user.uid,
      branchId:    req.user.tenantId ?? tenantId, // will be enriched from employee profile
    });
  }

  // ── PATCH /:leaveId/review — Admin: approve/reject ──────────────────────────
  @Patch(':leaveId/review')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({
    summary: 'اعتماد أو رفض طلب إجازة — entity_admin فقط — مختوم في C9',
  })
  reviewLeave(
    @Param('tenantId') tenantId: string,
    @Param('leaveId')  leaveId: string,
    @Body() dto: ReviewLeaveDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.leavesService.reviewLeave(tenantId, leaveId, {
      adminUid: req.user.uid,
      ...dto,
    });
  }

  // ── DELETE /:leaveId — Employee: cancel own request ─────────────────────────
  @Delete(':leaveId')
  @Version('1')
  @Roles('employee', 'entity_admin', 'sovereign')
  @ApiOperation({ summary: 'إلغاء طلب إجازة (حالة requested فقط)' })
  cancelLeave(
    @Param('tenantId') tenantId: string,
    @Param('leaveId')  leaveId: string,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.leavesService.cancelLeave(tenantId, leaveId, req.user.uid);
  }

  // ── GET /:leaveId/deductions — Admin: payroll deduction preview ─────────────
  @Get(':leaveId/deductions/monthly')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({
    summary: 'حساب خصومات الإجازات للشهر — تحضير Sprint 5 (Payroll)',
  })
  @ApiQuery({ name: 'monthStart', required: true, example: '2026-04-01' })
  @ApiQuery({ name: 'monthEnd',   required: true, example: '2026-04-30' })
  @ApiQuery({ name: 'dailyRate',  required: true, example: '200' })
  @ApiQuery({ name: 'employeeUid', required: true })
  getMonthlyDeductions(
    @Param('tenantId') tenantId: string,
    @Query('employeeUid') employeeUid: string,
    @Query('monthStart')  monthStart: string,
    @Query('monthEnd')    monthEnd: string,
    @Query('dailyRate')   dailyRate: string,
  ) {
    return this.leavesService.calculateLeaveDeductions(
      tenantId,
      employeeUid,
      monthStart,
      monthEnd,
      parseFloat(dailyRate),
    );
  }
}
