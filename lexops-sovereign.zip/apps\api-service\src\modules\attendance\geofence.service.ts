/**
 * LexOps — Geofence Service
 *
 * Implements the Haversine formula to compute the great-circle distance
 * between two GPS coordinates, then applies LexOps' 3-tier acceptance policy.
 *
 * Tier 1 — ACCEPTED:        distance <= (radiusMeters + 30m)  AND  accuracy <= 50m
 * Tier 2 — PENDING_REVIEW:  distance > (radiusMeters + 30m)   OR   accuracy  > 50m
 * Tier 3 — REJECTED:        accuracy > 150m  (GPS too imprecise to trust)
 */

import { Injectable } from '@nestjs/common';

export type GeofenceVerdict = 'accepted' | 'pending_review' | 'rejected';

export interface GeofenceResult {
  verdict: GeofenceVerdict;
  distanceMeters: number;      // Calculated distance between employee and branch
  radiusMeters: number;        // Branch allowed radius
  accuracy: number;            // GPS accuracy reported by device
  toleranceApplied: number;    // Fixed tolerance added to radius (30m)
  reason: string;              // Human-readable explanation
}

// ── Constants ─────────────────────────────────────────────────────────────────
const EARTH_RADIUS_M       = 6_371_000;   // Mean Earth radius in metres
const GEOFENCE_TOLERANCE_M = 30;          // Grace buffer added to radiusMeters
const ACCURACY_REJECT_M    = 150;         // Accuracy threshold for outright rejection
const ACCURACY_REVIEW_M    = 50;          // Accuracy threshold requiring review

@Injectable()
export class GeofenceService {
  /**
   * Compute Haversine distance (metres) between two WGS-84 coordinate pairs.
   * Formula: a = sin²(Δlat/2) + cos(lat1)·cos(lat2)·sin²(Δlng/2)
   *          c = 2·atan2(√a, √(1−a))
   *          d = R·c
   */
  computeDistance(
    employeeLat: number,
    employeeLng: number,
    branchLat: number,
    branchLng: number,
  ): number {
    const toRad = (deg: number) => (deg * Math.PI) / 180;

    const dLat = toRad(branchLat - employeeLat);
    const dLng = toRad(branchLng - employeeLng);

    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(toRad(employeeLat)) *
        Math.cos(toRad(branchLat)) *
        Math.sin(dLng / 2) ** 2;

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return Math.round(EARTH_RADIUS_M * c * 100) / 100; // round to cm
  }

  /**
   * Apply LexOps 3-tier acceptance policy against branch geofence.
   */
  verify(params: {
    employeeLat: number;
    employeeLng: number;
    accuracy: number;
    branchLat: number;
    branchLng: number;
    radiusMeters: number;
  }): GeofenceResult {
    const { employeeLat, employeeLng, accuracy, branchLat, branchLng, radiusMeters } = params;

    const distanceMeters = this.computeDistance(
      employeeLat, employeeLng, branchLat, branchLng,
    );

    const effectiveRadius = radiusMeters + GEOFENCE_TOLERANCE_M;

    // ── Tier 3: GPS too imprecise — outright rejection ──────────────────────
    if (accuracy > ACCURACY_REJECT_M) {
      return {
        verdict: 'rejected',
        distanceMeters,
        radiusMeters,
        accuracy,
        toleranceApplied: GEOFENCE_TOLERANCE_M,
        reason: `دقة GPS (${accuracy}م) تجاوزت الحد الأقصى المسموح (${ACCURACY_REJECT_M}م). مرفوض.`,
      };
    }

    // ── Tier 2: Inside radius but poor accuracy — pending review ────────────
    if (accuracy > ACCURACY_REVIEW_M) {
      return {
        verdict: 'pending_review',
        distanceMeters,
        radiusMeters,
        accuracy,
        toleranceApplied: GEOFENCE_TOLERANCE_M,
        reason: `دقة GPS (${accuracy}م) تجاوزت حد المراجعة (${ACCURACY_REVIEW_M}م). يحتاج مراجعة.`,
      };
    }

    // ── Tier 2: Outside geofence radius — pending review ────────────────────
    if (distanceMeters > effectiveRadius) {
      return {
        verdict: 'pending_review',
        distanceMeters,
        radiusMeters,
        accuracy,
        toleranceApplied: GEOFENCE_TOLERANCE_M,
        reason:
          `المسافة (${distanceMeters.toFixed(1)}م) تجاوزت النطاق المسموح ` +
          `(${effectiveRadius}م = ${radiusMeters}م + ${GEOFENCE_TOLERANCE_M}م تسامح). يحتاج مراجعة.`,
      };
    }

    // ── Tier 1: All checks passed — accepted ─────────────────────────────────
    return {
      verdict: 'accepted',
      distanceMeters,
      radiusMeters,
      accuracy,
      toleranceApplied: GEOFENCE_TOLERANCE_M,
      reason: `الموظف داخل النطاق الجغرافي (${distanceMeters.toFixed(1)}م من ${effectiveRadius}م).`,
    };
  }
}
