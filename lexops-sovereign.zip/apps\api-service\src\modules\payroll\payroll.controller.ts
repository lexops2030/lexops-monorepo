/**
 * LexOps — Payroll Controller
 *
 * REST Endpoints:
 *
 * ENTITY PAYROLL (TenantScopeGuard enforced on all routes):
 *   POST   /v1/entities/:tenantId/payroll/generate          → generate run (entity_admin, sovereign)
 *   GET    /v1/entities/:tenantId/payroll/runs              → list runs    (entity_admin, sovereign)
 *   GET    /v1/entities/:tenantId/payroll/runs/:runId       → get run      (entity_admin, sovereign)
 *   GET    /v1/entities/:tenantId/payroll/runs/:runId/items → payslips     (entity_admin, sovereign)
 *   PATCH  /v1/entities/:tenantId/payroll/runs/:runId/approve → approve   (entity_admin, sovereign)
 *   PATCH  /v1/entities/:tenantId/payroll/runs/:runId/close   → close     (entity_admin, sovereign)
 *   POST   /v1/entities/:tenantId/payroll/runs/:runId/adjustments → add adj (entity_admin, sovereign)
 *   GET    /v1/entities/:tenantId/payroll/runs/:runId/adjustments → list adj
 *
 * INDEPENDENT WORKER (personal_vault — routeToVault enforced):
 *   POST   /v1/independent/payroll/invoice     → generate stamped tax invoice (freelancer)
 *   GET    /v1/independent/payroll/invoices    → list invoices                (freelancer)
 */

import {
  Controller, Get, Post, Patch,
  Param, Body, Request, Version, UseGuards,
  HttpCode, HttpStatus,
  ForbiddenException,
} from '@nestjs/common';
import {
  ApiTags, ApiBearerAuth, ApiOperation, ApiParam, ApiBody,
} from '@nestjs/swagger';
import {
  IsString, IsNotEmpty, IsNumber, IsBoolean,
  IsPositive, Min, Max, IsOptional, IsDateString,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { PayrollService } from './payroll.service';
import { FirebaseAuthGuard, TenantScopeGuard, Roles, LexOpsClaims } from '../auth/firebase.guard';
import { Request as ExpressRequest } from 'express';

// ── DTOs ─────────────────────────────────────────────────────────────────────

class GeneratePayrollDto {
  @IsString() @IsNotEmpty()
  month: string; // 'YYYY-MM'
}

class ApproveCloseDto {
  @IsString() @IsOptional()
  note?: string;
}

class AddAdjustmentDto {
  @IsString() @IsNotEmpty()
  employeeUid: string;

  @IsNumber() @IsNotEmpty()
  amount: number; // positive = bonus, negative = deduction (SAR)

  @IsString() @IsNotEmpty()
  reason: string;

  @IsBoolean()
  carryForward: boolean; // true → carry to next month's run
}

class GenerateInvoiceDto {
  @IsString() @IsNotEmpty()
  month: string; // 'YYYY-MM'

  @IsNumber() @IsPositive()
  documentedHours: number;

  @IsNumber() @IsPositive()
  hourlyRate: number; // SAR

  @IsNumber() @IsOptional() @Min(0) @Max(1)
  vatRate?: number; // default 0.15
}

// ── Controller: Entity Payroll ─────────────────────────────────────────────────

@ApiTags('Payroll — Entity')
@ApiBearerAuth('Firebase-JWT')
@Controller('entities/:tenantId/payroll')
@UseGuards(FirebaseAuthGuard, TenantScopeGuard)
export class PayrollController {
  constructor(private readonly payrollService: PayrollService) {}

  // ── Generate ────────────────────────────────────────────────────────────────

  @Post('generate')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'توليد مسير رواتب شهري — معادلة نظام العمل السعودي' })
  @ApiParam({ name: 'tenantId', description: 'رقم المنشأة (700-series)' })
  async generatePayroll(
    @Param('tenantId') tenantId: string,
    @Body() dto: GeneratePayrollDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.payrollService.generateEntityPayroll({
      tenantId,
      month:       dto.month,
      generatedBy: req.user.uid,
    });
  }

  // ── List & Get Runs ─────────────────────────────────────────────────────────

  @Get('runs')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'قائمة مسيرات الرواتب (آخر 12 شهر)' })
  listRuns(@Param('tenantId') tenantId: string) {
    return this.payrollService.listRuns(tenantId);
  }

  @Get('runs/:runId')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'تفاصيل مسير رواتب' })
  getRun(
    @Param('tenantId') tenantId: string,
    @Param('runId') runId: string,
  ) {
    return this.payrollService.getRun(tenantId, runId);
  }

  @Get('runs/:runId/items')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'قوائم الرواتب الفردية (Payslips) داخل المسير' })
  listItems(
    @Param('tenantId') tenantId: string,
    @Param('runId') runId: string,
  ) {
    return this.payrollService.listItems(tenantId, runId);
  }

  // ── Approve ─────────────────────────────────────────────────────────────────

  @Patch('runs/:runId/approve')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'اعتماد مسير الرواتب (draft → approved) + C9 Seal' })
  async approveRun(
    @Param('tenantId') tenantId: string,
    @Param('runId') runId: string,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
    @Body() _dto: ApproveCloseDto,
  ) {
    return this.payrollService.approvePayroll(tenantId, runId, req.user.uid);
  }

  // ── Close ────────────────────────────────────────────────────────────────────

  @Patch('runs/:runId/close')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({
    summary: 'إغلاق نهائي لمسير الرواتب (approved → closed) — لا تراجع بعد الإغلاق',
    description:
      'بعد الإغلاق، يرفض النظام أي تعديل على بنود المسير. ' +
      'استخدم نقطة التسويات (adjustments) للتعديل على الشهر القادم.',
  })
  async closeRun(
    @Param('tenantId') tenantId: string,
    @Param('runId') runId: string,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
    @Body() _dto: ApproveCloseDto,
  ) {
    return this.payrollService.closePayroll(tenantId, runId, req.user.uid);
  }

  // ── Adjustments ─────────────────────────────────────────────────────────────

  @Post('runs/:runId/adjustments')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    summary: 'إضافة تسوية ما بعد الإغلاق — تُرحَّل للشهر القادم إن كان carryForward=true',
  })
  addAdjustment(
    @Param('tenantId') tenantId: string,
    @Param('runId') runId: string,
    @Body() dto: AddAdjustmentDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.payrollService.addAdjustment({
      tenantId,
      runId,
      employeeUid:  dto.employeeUid,
      amount:       dto.amount,
      reason:       dto.reason,
      addedBy:      req.user.uid,
      carryForward: dto.carryForward,
    });
  }

  @Get('runs/:runId/adjustments')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'قائمة التسويات لمسير مغلق' })
  listAdjustments(
    @Param('tenantId') tenantId: string,
    @Param('runId') runId: string,
  ) {
    return this.payrollService.listAdjustments(tenantId, runId);
  }
}

// ── Controller: Independent Worker Invoice ────────────────────────────────────

@ApiTags('Payroll — Independent Worker (فاتورة ضريبية)')
@ApiBearerAuth('Firebase-JWT')
@Controller('independent/payroll')
@UseGuards(FirebaseAuthGuard)
export class IndependentPayrollController {
  constructor(private readonly payrollService: PayrollService) {}

  @Post('invoice')
  @Version('1')
  @Roles('freelancer')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    summary: 'توليد فاتورة ضريبية مختومة — Pay-per-Action (العامل المستقل)',
    description:
      'تحسب الفاتورة: إجمالي الأجر = ساعات العمل الموثقة × المعدل الساعي التعاقدي + ضريبة القيمة المضافة (15%). ' +
      'تُختم تلقائياً وتُربط بالخزانة الشخصية (personal_vault).',
  })
  async generateInvoice(
    @Body() dto: GenerateInvoiceDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    // Enforce IND_ routing gate — only independent workers may use this endpoint
    if (!req.user.routeToVault) {
      throw new ForbiddenException(
        'هذه النقطة مخصصة للعمال المستقلين فقط. ' +
        'يجب أن يبدأ tenantId بـ IND_ للوصول إليها.',
      );
    }

    return this.payrollService.generateIndependentInvoice({
      uid:             req.user.uid,
      month:           dto.month,
      documentedHours: dto.documentedHours,
      hourlyRate:      dto.hourlyRate,
      vatRate:         dto.vatRate,
    });
  }

  @Get('invoices')
  @Version('1')
  @Roles('freelancer')
  @ApiOperation({ summary: 'قائمة الفواتير الضريبية للعامل المستقل من خزانته الشخصية' })
  listInvoices(
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    if (!req.user.routeToVault) {
      throw new ForbiddenException('مخصص للعمال المستقلين فقط.');
    }
    return this.payrollService.listInvoices(req.user.uid);
  }
}
