import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { MapPin, Building2, CheckCircle2, AlertCircle } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import api from '../../lib/api';

// ── Validation Schema ─────────────────────────────────────────────────────────

const branchSchema = z.object({
  name:         z.string().min(2, 'اسم الفرع مطلوب'),
  nameEn:       z.string().optional(),
  city:         z.string().min(2, 'المدينة مطلوبة'),
  address:      z.string().min(5, 'العنوان التفصيلي مطلوب'),
  geofence: z.object({
    lat:          z.number({ invalid_type_error: 'خط العرض يجب أن يكون رقماً' })
                    .min(-90).max(90),
    lng:          z.number({ invalid_type_error: 'خط الطول يجب أن يكون رقماً' })
                    .min(-180).max(180),
    radiusMeters: z.number()
                    .min(50, 'الحد الأدنى للنطاق 50 متر')
                    .max(5000, 'الحد الأقصى للنطاق 5000 متر'),
  }),
  managerUid: z.string().optional(),
});

type BranchFormValues = z.infer<typeof branchSchema>;

// ── Component ─────────────────────────────────────────────────────────────────

interface BranchFormPageProps {
  tenantId: string;
  onSuccess?: () => void;
}

export default function BranchFormPage({ tenantId, onSuccess }: BranchFormPageProps) {
  const queryClient = useQueryClient();
  const [success, setSuccess] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<BranchFormValues>({
    resolver: zodResolver(branchSchema),
    defaultValues: {
      geofence: { lat: 24.6877, lng: 46.7219, radiusMeters: 200 }, // Riyadh default
    },
  });

  const mutation = useMutation({
    mutationFn: (data: BranchFormValues) =>
      api.post(`/entities/${tenantId}/branches`, data).then((r) => r.data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['branches', tenantId] });
      setSuccess(true);
      reset();
      setTimeout(() => { setSuccess(false); onSuccess?.(); }, 2500);
    },
  });

  return (
    <div className="mx-auto max-w-2xl">
      {/* ── Header ── */}
      <div className="mb-8 flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10">
          <Building2 className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">إضافة فرع جديد</h1>
          <p className="text-sm text-neutral-500">
            حدد الإحداثيات الجغرافية لتفعيل نطاق الحضور
          </p>
        </div>
      </div>

      {/* ── Success Banner ── */}
      {success && (
        <div className="mb-6 flex items-center gap-3 rounded-xl border border-green-200 bg-green-50 px-5 py-4 animate-fade-in">
          <CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" />
          <p className="text-sm font-medium text-green-800">تم إنشاء الفرع وختمه في سجل C9 بنجاح</p>
        </div>
      )}

      {/* ── Error Banner ── */}
      {mutation.isError && (
        <div className="mb-6 flex items-center gap-3 rounded-xl border border-red-200 bg-red-50 px-5 py-4 animate-fade-in">
          <AlertCircle className="h-5 w-5 text-red-600 shrink-0" />
          <p className="text-sm text-red-700">
            {(mutation.error as { response?: { data?: { message?: string } } })
              ?.response?.data?.message ?? 'حدث خطأ أثناء إنشاء الفرع'}
          </p>
        </div>
      )}

      <form onSubmit={handleSubmit((d) => mutation.mutate(d))} noValidate>
        <div className="card-sovereign space-y-6">

          {/* ── Section: Basic Info ── */}
          <div>
            <h2 className="mb-4 text-sm font-semibold uppercase tracking-wider text-neutral-400">
              معلومات الفرع
            </h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Input
                id="name"
                label="اسم الفرع (عربي)"
                placeholder="مثال: فرع الرياض - العليا"
                required
                error={errors.name?.message}
                {...register('name')}
              />
              <Input
                id="nameEn"
                label="اسم الفرع (إنجليزي)"
                placeholder="e.g. Riyadh - Olaya Branch"
                error={errors.nameEn?.message}
                {...register('nameEn')}
              />
              <Input
                id="city"
                label="المدينة"
                placeholder="الرياض"
                required
                error={errors.city?.message}
                {...register('city')}
              />
              <Input
                id="address"
                label="العنوان التفصيلي"
                placeholder="حي العليا، شارع العروبة"
                required
                error={errors.address?.message}
                {...register('address')}
              />
            </div>
          </div>

          {/* ── Divider ── */}
          <hr className="border-neutral-100" />

          {/* ── Section: Geofencing ── */}
          <div>
            <div className="mb-4 flex items-center gap-2">
              <MapPin className="h-4 w-4 text-primary" />
              <h2 className="text-sm font-semibold uppercase tracking-wider text-neutral-400">
                نطاق الحضور الجغرافي (Geofencing)
              </h2>
            </div>

            <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 mb-4">
              <p className="text-xs text-primary-dark">
                سيُسمح للموظفين بتسجيل الحضور فقط في حال وجودهم ضمن النطاق المحدد.
                الحد الأدنى: 50م — الحد الأقصى: 5000م.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <Input
                id="lat"
                label="خط العرض (Latitude)"
                type="number"
                step="0.0000001"
                placeholder="24.6877"
                required
                error={errors.geofence?.lat?.message}
                {...register('geofence.lat', { valueAsNumber: true })}
              />
              <Input
                id="lng"
                label="خط الطول (Longitude)"
                type="number"
                step="0.0000001"
                placeholder="46.7219"
                required
                error={errors.geofence?.lng?.message}
                {...register('geofence.lng', { valueAsNumber: true })}
              />
              <Input
                id="radiusMeters"
                label="النطاق المسموح (بالأمتار)"
                type="number"
                placeholder="200"
                required
                hint="بين 50 و 5000 متر"
                error={errors.geofence?.radiusMeters?.message}
                {...register('geofence.radiusMeters', { valueAsNumber: true })}
              />
            </div>
          </div>

          {/* ── Actions ── */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <Button type="button" variant="ghost" onClick={() => reset()}>
              مسح البيانات
            </Button>
            <Button type="submit" loading={mutation.isPending}>
              إنشاء الفرع وختم C9
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
