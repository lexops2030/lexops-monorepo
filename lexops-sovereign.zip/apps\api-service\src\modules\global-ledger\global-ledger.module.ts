import { Module } from '@nestjs/common';
import { GlobalLedgerService } from './global-ledger.service';
import { GlobalLedgerController } from './global-ledger.controller';
import { DatabaseModule } from '../../database/database.module';

@Module({
  imports:     [DatabaseModule],   // Firestore + C9LedgerRepository
  providers:   [GlobalLedgerService],
  controllers: [GlobalLedgerController],
  exports:     [GlobalLedgerService],
})
export class GlobalLedgerModule {}
