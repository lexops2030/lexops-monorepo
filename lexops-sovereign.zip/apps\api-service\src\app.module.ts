import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { AuthModule } from './modules/auth/auth.module';
import { EntitiesModule } from './modules/entities/entities.module';
import { UsersModule } from './modules/users/users.module';
import { LexiModule } from './modules/lexi/lexi.module';
import { DatabaseModule } from './database/database.module';
import { BranchesModule } from './modules/branches/branches.module';
import { EmployeesModule } from './modules/employees/employees.module';
import { AttendanceModule } from './modules/attendance/attendance.module';
import { LeavesModule } from './modules/leaves/leaves.module';
import { LifecycleModule } from './modules/lifecycle/lifecycle.module';
import { PayrollModule } from './modules/payroll/payroll.module';
import { ComplianceModule } from './modules/compliance/compliance.module';
import { ObjectionsModule } from './modules/objections/objections.module';
import { LegalModule } from './modules/legal/legal.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { GlobalLedgerModule } from './modules/global-ledger/global-ledger.module';

@Module({
  imports: [
    // ── Configuration ─────────────────────────────────────────────────────────
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env.local', '.env'],
    }),

    // ── Rate Limiting (Anti-abuse) ────────────────────────────────────────────
    ThrottlerModule.forRoot([
      {
        name: 'short',
        ttl: 1000,
        limit: 10,
      },
      {
        name: 'long',
        ttl: 60_000,
        limit: 200,
      },
    ]),

    // ── Core Modules ──────────────────────────────────────────────────────────
    DatabaseModule,    // Firestore + PostgreSQL (C9 Ledger)
    AuthModule,        // Firebase Auth Guard + RBAC
    EntitiesModule,    // Fortress 700 — Entity (Company) management
    UsersModule,       // Multi-tenant user management
    LexiModule,        // LEXI AI Legal Engine (Vertex AI / Gemini)
    BranchesModule,    // Sprint 2 — Branch management + Geofencing
    EmployeesModule,   // Sprint 2 — Employee management + Cross-branch validation
    AttendanceModule,  // Sprint 3 — Geofencing + Anti-Spoofing + Review Workflow
    LeavesModule,      // Sprint 4 — Leave Management + Policies + Payroll prep
    LifecycleModule,   // Sprint 5 Pillar 1 — Lifecycle Engine (establishment + employee)
    PayrollModule,     // Sprint 5 — Payroll Engine (Entity + Independent Worker)
    ComplianceModule,  // Sprint 6 — Compliance Engine (JSON Logic + 180-Day Recurrence)
    ObjectionsModule,  // Sprint 7 — Objections Lifecycle (draft→submit→review)
    LegalModule,          // Sprint 7 — Legal AI Engine (Vertex AI + Royal Decree 11438)
    NotificationsModule,  // Sprint 8 — Multi-Channel Notifications (SMS/Email/Push)
    GlobalLedgerModule,   // Sprint 8 — Genesis Block + SHA-512 Final Sovereign Seal
  ],
})
export class AppModule {}
