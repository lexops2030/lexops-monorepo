import {
  Injectable, NotFoundException, ForbiddenException,
} from '@nestjs/common';
import {
  LeavesRepository, LeaveDocument, LeaveType,
  LeaveStatus, LeaveReview,
} from './leaves.repository';
import { LeavePoliciesEngine } from './leave-policies.engine';
import { C9LedgerRepository } from '../../database/c9-ledger.repository';
import { randomUUID } from 'crypto';

// ── Input shapes ──────────────────────────────────────────────────────────────

export interface RequestLeaveInput {
  employeeUid:      string;
  branchId:         string;
  leaveType:        LeaveType;
  startDate:        string;
  endDate:          string;
  reason:           string;
  attachmentUrl?:   string;
  annualEntitlement?: number;
}

export interface ReviewLeaveInput {
  adminUid:   string;
  decision:   'approved' | 'rejected';
  reason:     string;
}

// ── Payroll helper types ──────────────────────────────────────────────────────

export interface LeaveDeduction {
  leaveId:         string;
  leaveType:       LeaveType;
  daysRequested:   number;
  deductibleDays:  number;   // only unpaid => deductible
  deductionAmount: number;   // SAR amount (dailyRate * deductibleDays)
}

export interface LeaveDeductionSummary {
  employeeUid:      string;
  totalDays:        number;
  unpaidDays:       number;
  deductionAmount:  number;   // SAR
  breakdown:        LeaveDeduction[];
}

// ── Service ───────────────────────────────────────────────────────────────────

@Injectable()
export class LeavesService {
  constructor(
    private readonly leavesRepo: LeavesRepository,
    private readonly policiesEngine: LeavePoliciesEngine,
    private readonly c9: C9LedgerRepository,
  ) {}

  // ──────────────────────────────────────────────────────────────────────────
  // REQUEST A LEAVE
  // ──────────────────────────────────────────────────────────────────────────

  async requestLeave(
    tenantId: string,
    input: RequestLeaveInput,
  ): Promise<LeaveDocument> {
    const daysRequested = this.calculateDays(input.startDate, input.endDate);

    // ── Policy enforcement (throws 422 on violation) ──────────────────────
    let policyResult;
    try {
      policyResult = await this.policiesEngine.enforce({
        tenantId,
        employeeUid:      input.employeeUid,
        leaveType:        input.leaveType,
        startDate:        input.startDate,
        endDate:          input.endDate,
        daysRequested,
        annualEntitlement: input.annualEntitlement,
      });
    } catch (err) {
      // C9 Seal: LEAVE_POLICY_VIOLATION
      await this.c9.append({
        tenantId,
        eventType:   'LEAVE_POLICY_VIOLATION',
        actorUid:    input.employeeUid,
        actorRole:   'employee',
        subjectUid:  input.employeeUid,
        subjectType: 'leave_request',
        payload: {
          leaveType:     input.leaveType,
          startDate:     input.startDate,
          endDate:       input.endDate,
          daysRequested,
          violations:    (err as { response?: { violations?: string[] } })?.response?.violations ?? [],
        },
      });
      throw err;
    }

    // ── Persist request ────────────────────────────────────────────────────
    const leaveId = `leave_${randomUUID().replace(/-/g, '').slice(0, 14)}`;

    const leave = await this.leavesRepo.create(tenantId, leaveId, {
      employeeUid:   input.employeeUid,
      branchId:      input.branchId,
      leaveType:     input.leaveType,
      status:        'requested',
      startDate:     input.startDate,
      endDate:       input.endDate,
      daysRequested,
      reason:        input.reason,
      attachmentUrl: input.attachmentUrl,
      createdBy:     input.employeeUid,
    });

    // ── C9 Seal: LEAVE_REQUESTED ──────────────────────────────────────────
    await this.c9.append({
      tenantId,
      eventType:   'LEAVE_REQUESTED',
      actorUid:    input.employeeUid,
      actorRole:   'employee',
      subjectUid:  leaveId,
      subjectType: 'leave_request',
      payload: {
        leaveId,
        leaveType:     input.leaveType,
        startDate:     input.startDate,
        endDate:       input.endDate,
        daysRequested,
        remainingDays: policyResult.remainingDays,
      },
    });

    return leave;
  }

  // ──────────────────────────────────────────────────────────────────────────
  // REVIEW — entity_admin only
  // ──────────────────────────────────────────────────────────────────────────

  async reviewLeave(
    tenantId: string,
    leaveId: string,
    input: ReviewLeaveInput,
  ): Promise<{ message: string }> {
    const leave = await this.leavesRepo.findById(tenantId, leaveId);
    if (!leave) {
      throw new NotFoundException(`طلب الإجازة '${leaveId}' غير موجود.`);
    }

    const review: LeaveReview = {
      reviewedBy: input.adminUid,
      reviewedAt: { toDate: () => new Date() } as FirebaseFirestore.Timestamp,
      decision:   input.decision,
      reason:     input.reason,
    };

    await this.leavesRepo.applyReview(tenantId, leaveId, review);

    // ── C9 Seal ───────────────────────────────────────────────────────────
    await this.c9.append({
      tenantId,
      eventType:   input.decision === 'approved' ? 'LEAVE_APPROVED' : 'LEAVE_REJECTED',
      actorUid:    input.adminUid,
      actorRole:   'entity_admin',
      subjectUid:  leaveId,
      subjectType: 'leave_request',
      payload: {
        leaveId,
        employeeUid:  leave.employeeUid,
        leaveType:    leave.leaveType,
        startDate:    leave.startDate,
        endDate:      leave.endDate,
        daysRequested: leave.daysRequested,
        decision:     input.decision,
        reason:       input.reason,
      },
    });

    const verb = input.decision === 'approved' ? 'اعتماد' : 'رفض';
    return { message: `تم ${verb} طلب الإجازة '${leaveId}' وختمه في سجل C9.` };
  }

  // ──────────────────────────────────────────────────────────────────────────
  // QUERIES
  // ──────────────────────────────────────────────────────────────────────────

  findAll(tenantId: string, filters: { status?: LeaveStatus; leaveType?: LeaveType } = {}) {
    return this.leavesRepo.findAllByTenant(tenantId, filters);
  }

  findMyLeaves(tenantId: string, employeeUid: string) {
    return this.leavesRepo.findByEmployee(tenantId, employeeUid);
  }

  async cancelLeave(tenantId: string, leaveId: string, employeeUid: string) {
    await this.leavesRepo.cancel(tenantId, leaveId, employeeUid);
    return { message: `تم إلغاء طلب الإجازة '${leaveId}'.` };
  }

  // ──────────────────────────────────────────────────────────────────────────
  // ATTENDANCE INTEGRATION — used by AttendanceService
  // ──────────────────────────────────────────────────────────────────────────

  /**
   * Check if a specific date falls within an approved leave for this employee.
   * Called by AttendanceService.checkIn() to block check-in during leave.
   */
  async isDateOnApprovedLeave(
    tenantId: string,
    employeeUid: string,
    date: string, // 'YYYY-MM-DD'
  ): Promise<{ onLeave: boolean; leave: LeaveDocument | null }> {
    const overlapping = await this.leavesRepo.findApprovedOverlapping(
      tenantId, employeeUid, date, date,
    );
    const match = overlapping.length > 0 ? overlapping[0] : null;
    return { onLeave: match !== null, leave: match };
  }

  // ──────────────────────────────────────────────────────────────────────────
  // PAYROLL INTEGRATION — Sprint 5 preparation
  // ──────────────────────────────────────────────────────────────────────────

  /**
   * Calculate leave deductions for a given employee within a month range.
   *
   * Rule (Saudi Labor Law):
   *   - annual  → 0 deduction (paid leave)
   *   - sick    → 0 deduction (paid leave, within limits)
   *   - unpaid  → full day deduction per day
   *   - other   → 0 deduction (discretionary paid)
   *
   * @param dailySalaryRate Employee's base salary / 30
   */
  async calculateLeaveDeductions(
    tenantId: string,
    employeeUid: string,
    monthStart: string, // 'YYYY-MM-DD'
    monthEnd: string,   // 'YYYY-MM-DD'
    dailySalaryRate: number,
  ): Promise<LeaveDeductionSummary> {
    const allLeaves = await this.leavesRepo.findApprovedOverlapping(
      tenantId, employeeUid, monthStart, monthEnd,
    );

    const breakdown: LeaveDeduction[] = allLeaves.map((leave) => {
      // Clip leave range to the billing month
      const effectiveStart = leave.startDate < monthStart ? monthStart : leave.startDate;
      const effectiveEnd   = leave.endDate   > monthEnd   ? monthEnd   : leave.endDate;
      const effectiveDays  = this.calculateDays(effectiveStart, effectiveEnd);

      const deductibleDays  = leave.leaveType === 'unpaid' ? effectiveDays : 0;
      const deductionAmount = deductibleDays * dailySalaryRate;

      return {
        leaveId:         leave.leaveId,
        leaveType:       leave.leaveType,
        daysRequested:   effectiveDays,
        deductibleDays,
        deductionAmount,
      };
    });

    const totalDays       = breakdown.reduce((s, d) => s + d.daysRequested, 0);
    const unpaidDays      = breakdown.reduce((s, d) => s + d.deductibleDays, 0);
    const deductionAmount = breakdown.reduce((s, d) => s + d.deductionAmount, 0);

    return { employeeUid, totalDays, unpaidDays, deductionAmount, breakdown };
  }

  // ──────────────────────────────────────────────────────────────────────────
  // HELPERS
  // ──────────────────────────────────────────────────────────────────────────

  /** Inclusive day count between two ISO date strings */
  calculateDays(startDate: string, endDate: string): number {
    const start = new Date(startDate);
    const end   = new Date(endDate);
    const diffMs = end.getTime() - start.getTime();
    return Math.max(1, Math.floor(diffMs / 86_400_000) + 1);
  }
}
