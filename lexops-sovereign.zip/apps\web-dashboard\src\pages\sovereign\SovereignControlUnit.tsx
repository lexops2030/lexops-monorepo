/**
 * SovereignControlUnit.tsx — وحدة التحكم السيادي
 * Founder-restricted: 4 Sovereignty Keys + Emergency Protocol + Override Log
 */

import { useState } from 'react';
import {
  ShieldOff, BookLock, Sliders, MapPin, Zap,
  AlertTriangle, X, CheckCircle2, Clock, Shield,
} from 'lucide-react';

// ── Sovereign Theme ────────────────────────────────────────────────────────────

const S = {
  bg900:   '#05060d',
  bg800:   '#0b1121',
  bg700:   '#0f1729',
  bg600:   '#162035',
  border:  '#1e2d4a',
  gold:    '#C8A96B',
  goldDim: '#9A7F45',
  red:     '#f87171',
  green:   '#34d399',
  blue:    '#60a5fa',
  purple:  '#a78bfa',
  amber:   '#fbbf24',
  text:    '#e2e8f0',
  muted:   '#64748b',
};

// ── Types ──────────────────────────────────────────────────────────────────────

interface SovereignKey {
  id:          string;
  label:       string;
  labelEn:     string;
  description: string;
  icon:        React.ReactNode;
  color:       string;
  bgColor:     string;
  borderColor: string;
}

interface OverrideLog {
  id:        string;
  key:       string;
  action:    'enabled' | 'disabled';
  by:        string;
  reason:    string;
  timestamp: string;
}

// ── Static mock log ────────────────────────────────────────────────────────────

const INITIAL_LOG: OverrideLog[] = [
  { id: '1', key: 'Geofence Override', action: 'enabled',  by: 'المؤسس', reason: 'صيانة مجدولة — فرع الرياض', timestamp: '2026-04-01 09:14:22' },
  { id: '2', key: 'Ledger Auditor',    action: 'enabled',  by: 'المؤسس', reason: 'تدقيق ربع سنوي C9',         timestamp: '2026-03-31 23:58:01' },
  { id: '3', key: 'Quota Master',      action: 'disabled', by: 'المؤسس', reason: 'انتهاء فترة الاختبار',      timestamp: '2026-03-30 16:42:10' },
  { id: '4', key: 'Kill Switch',       action: 'enabled',  by: 'المؤسس', reason: 'تحديث قاعدة البيانات',      timestamp: '2026-03-28 03:11:55' },
  { id: '5', key: 'Ledger Auditor',    action: 'disabled', by: 'المؤسس', reason: 'انتهاء فترة التدقيق',       timestamp: '2026-03-27 08:30:00' },
];

// ── Toggle Switch ──────────────────────────────────────────────────────────────

function Toggle({
  checked, onChange, color,
}: { checked: boolean; onChange: (v: boolean) => void; color: string }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      style={{
        width:        52,
        height:       28,
        borderRadius: 99,
        background:   checked ? color : S.bg600,
        border:       `1px solid ${checked ? color : S.border}`,
        cursor:       'pointer',
        position:     'relative',
        transition:   'all 0.25s',
        flexShrink:   0,
        boxShadow:    checked ? `0 0 12px ${color}60` : 'none',
      }}
    >
      <div style={{
        position:   'absolute',
        top:        3,
        left:       checked ? 27 : 3,
        width:      20,
        height:     20,
        borderRadius: '50%',
        background: checked ? S.bg900 : S.muted,
        transition: 'left 0.25s',
        boxShadow:  '0 1px 4px rgba(0,0,0,0.5)',
      }} />
    </button>
  );
}

// ── Key Card ───────────────────────────────────────────────────────────────────

function KeyCard({
  cfg, enabled, onToggle,
}: { cfg: SovereignKey; enabled: boolean; onToggle: () => void }) {
  return (
    <div style={{
      background:   enabled ? `${cfg.bgColor}` : S.bg700,
      border:       `1px solid ${enabled ? cfg.borderColor : S.border}`,
      borderRadius: 16,
      padding:      24,
      transition:   'all 0.3s',
      boxShadow:    enabled ? `0 4px 24px ${cfg.color}20` : 'none',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
        <div style={{
          background:   `${cfg.color}20`,
          border:       `1px solid ${cfg.color}40`,
          borderRadius: 10,
          padding:      10,
          display:      'flex',
          alignItems:   'center',
          justifyContent: 'center',
        }}>
          {cfg.icon}
        </div>
        <Toggle checked={enabled} onChange={onToggle} color={cfg.color} />
      </div>

      <h3 style={{ color: S.text, fontSize: 15, fontWeight: 700, margin: '0 0 6px' }}>{cfg.label}</h3>
      <p style={{ color: S.muted, fontSize: 11, margin: '0 0 14px', lineHeight: 1.6 }}>{cfg.labelEn}</p>
      <p style={{ color: enabled ? cfg.color : S.muted, fontSize: 12, lineHeight: 1.6, margin: 0 }}>
        {cfg.description}
      </p>

      <div style={{
        marginTop:    14,
        display:      'inline-flex',
        alignItems:   'center',
        gap:          6,
        background:   enabled ? `${cfg.color}18` : S.bg600,
        border:       `1px solid ${enabled ? cfg.color + '40' : S.border}`,
        borderRadius: 99,
        padding:      '4px 12px',
      }}>
        <div style={{ width: 6, height: 6, borderRadius: '50%', background: enabled ? cfg.color : S.muted }} />
        <span style={{ color: enabled ? cfg.color : S.muted, fontSize: 10, fontWeight: 700, letterSpacing: '0.08em' }}>
          {enabled ? 'ACTIVE' : 'INACTIVE'}
        </span>
      </div>
    </div>
  );
}

// ── Confirm Modal ──────────────────────────────────────────────────────────────

interface ConfirmModalProps {
  entityId: string;
  reason:   string;
  step:     1 | 2;
  onStep2:  () => void;
  onFire:   () => void;
  onClose:  () => void;
}

function ConfirmModal({ entityId, reason, step, onStep2, onFire, onClose }: ConfirmModalProps) {
  return (
    <div style={{
      position:       'fixed',
      inset:          0,
      background:     'rgba(0,0,0,0.75)',
      display:        'flex',
      alignItems:     'center',
      justifyContent: 'center',
      zIndex:         1000,
      backdropFilter: 'blur(4px)',
    }}>
      <div style={{
        background:   S.bg800,
        border:       `1px solid ${S.red}60`,
        borderRadius: 20,
        padding:      36,
        maxWidth:     480,
        width:        '90%',
        boxShadow:    `0 0 60px ${S.red}30`,
      }}>
        {/* Icon */}
        <div style={{ textAlign: 'center', marginBottom: 20 }}>
          <div style={{
            display:        'inline-flex',
            alignItems:     'center',
            justifyContent: 'center',
            width:          64,
            height:         64,
            borderRadius:   '50%',
            background:     `${S.red}20`,
            border:         `2px solid ${S.red}50`,
          }}>
            <AlertTriangle size={28} color={S.red} />
          </div>
        </div>

        <h2 style={{ color: S.red, fontSize: 18, fontWeight: 800, textAlign: 'center', margin: '0 0 8px' }}>
          {step === 1 ? 'تأكيد العزل — المرحلة الأولى' : 'تأكيد نهائي — المرحلة الثانية'}
        </h2>
        <p style={{ color: S.muted, fontSize: 12, textAlign: 'center', margin: '0 0 24px' }}>
          {step === 1 ? 'يرجى مراجعة البيانات قبل المتابعة' : 'هذا الإجراء لا يمكن التراجع عنه'}
        </p>

        {/* Details */}
        <div style={{ background: S.bg700, border: `1px solid ${S.border}`, borderRadius: 12, padding: 16, marginBottom: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
            <span style={{ color: S.muted, fontSize: 12 }}>معرّف المنشأة</span>
            <span style={{ color: S.red, fontSize: 12, fontWeight: 700, fontFamily: 'IBM Plex Mono, monospace' }}>{entityId}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ color: S.muted, fontSize: 12 }}>السبب</span>
            <span style={{ color: S.text, fontSize: 12, fontWeight: 600, maxWidth: 220, textAlign: 'left' }}>{reason || '—'}</span>
          </div>
        </div>

        {step === 2 && (
          <div style={{
            background:   `${S.red}10`,
            border:       `1px solid ${S.red}40`,
            borderRadius: 10,
            padding:      14,
            marginBottom: 20,
            display:      'flex',
            gap:          10,
            alignItems:   'flex-start',
          }}>
            <AlertTriangle size={16} color={S.red} style={{ flexShrink: 0, marginTop: 2 }} />
            <p style={{ color: S.red, fontSize: 12, margin: 0, lineHeight: 1.6 }}>
              سيتم عزل المنشأة فوراً وتعطيل جميع عمليات القراءة والكتابة. سيُسجَّل هذا الإجراء في سجل C9 اللامتغير.
            </p>
          </div>
        )}

        <div style={{ display: 'flex', gap: 12 }}>
          <button onClick={onClose} style={{
            flex:         1,
            background:   S.bg700,
            border:       `1px solid ${S.border}`,
            borderRadius: 10,
            padding:      '12px 0',
            color:        S.muted,
            cursor:       'pointer',
            fontSize:     13,
            fontFamily:   'inherit',
          }}>
            إلغاء
          </button>
          <button
            onClick={step === 1 ? onStep2 : onFire}
            style={{
              flex:         1,
              background:   `linear-gradient(135deg, #dc2626, #b91c1c)`,
              border:       `1px solid ${S.red}`,
              borderRadius: 10,
              padding:      '12px 0',
              color:        '#fff',
              cursor:       'pointer',
              fontSize:     13,
              fontWeight:   700,
              fontFamily:   'inherit',
              boxShadow:    `0 4px 20px ${S.red}40`,
            }}
          >
            {step === 1 ? 'متابعة →' : 'تنفيذ العزل نهائياً'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────

export function SovereignControlUnit() {
  // Sovereignty key states
  const [keys, setKeys] = useState({
    killSwitch:       false,
    ledgerAuditor:    false,
    quotaMaster:      false,
    geofenceOverride: false,
  });

  // Emergency protocol
  const [entityId, setEntityId]         = useState('');
  const [reason,   setReason]           = useState('');
  const [modalStep, setModalStep]       = useState<0 | 1 | 2>(0);
  const [fired,    setFired]            = useState(false);

  // Override log
  const [log, setLog] = useState<OverrideLog[]>(INITIAL_LOG);

  const KEYS: SovereignKey[] = [
    {
      id: 'killSwitch', label: 'مفتاح الإيقاف الكامل', labelEn: 'Kill Switch',
      description: 'يوقف جميع عمليات الكتابة في المنصة على مستوى جميع المنشآت فوراً',
      icon:        <ShieldOff size={20} color={S.red} />,
      color:       S.red, bgColor: '#f8717108', borderColor: '#f8717130',
    },
    {
      id: 'ledgerAuditor', label: 'مدقق سجل C9', labelEn: 'Ledger Auditor',
      description: 'يُفعّل تدفق التدقيق الفوري على سجل C9 اللامتغير عبر جميع المنشآت',
      icon:        <BookLock size={20} color={S.blue} />,
      color:       S.blue, bgColor: '#60a5fa08', borderColor: '#60a5fa30',
    },
    {
      id: 'quotaMaster', label: 'سيد الحصص', labelEn: 'Quota Master',
      description: 'يتحكم في حدود معدل استهلاك API لكل منشأة بشكل منفصل',
      icon:        <Sliders size={20} color={S.amber} />,
      color:       S.amber, bgColor: '#fbbf2408', borderColor: '#fbbf2430',
    },
    {
      id: 'geofenceOverride', label: 'تجاوز الجيوفنس', labelEn: 'Geofence Override',
      description: 'يتجاوز عمليات التحقق الجغرافي مؤقتاً لأغراض الصيانة المجدولة',
      icon:        <MapPin size={20} color={S.purple} />,
      color:       S.purple, bgColor: '#a78bfa08', borderColor: '#a78bfa30',
    },
  ];

  const handleKeyToggle = (id: keyof typeof keys) => {
    const next = !keys[id];
    setKeys(prev => ({ ...prev, [id]: next }));
    const cfg = KEYS.find(k => k.id === id)!;
    const entry: OverrideLog = {
      id:        Date.now().toString(),
      key:       cfg.labelEn,
      action:    next ? 'enabled' : 'disabled',
      by:        'المؤسس',
      reason:    'تغيير يدوي',
      timestamp: new Date().toLocaleString('ar-SA'),
    };
    setLog(prev => [entry, ...prev].slice(0, 5));
  };

  const handleEmergencyFire = () => {
    const entry: OverrideLog = {
      id:        Date.now().toString(),
      key:       'Emergency Isolation',
      action:    'enabled',
      by:        'المؤسس',
      reason:    `عزل طارئ: ${entityId} — ${reason}`,
      timestamp: new Date().toLocaleString('ar-SA'),
    };
    setLog(prev => [entry, ...prev].slice(0, 5));
    setFired(true);
    setModalStep(0);
    setEntityId('');
    setReason('');
    setTimeout(() => setFired(false), 5000);
  };

  return (
    <div dir="rtl" style={{ background: S.bg900, minHeight: '100vh', fontFamily: 'Cairo, IBM Plex Sans Arabic, sans-serif', color: S.text, padding: 32 }}>

      {/* ── Header ───────────────────────────────────────────────────────────── */}
      <div style={{ marginBottom: 36 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
          <div style={{ background: `${S.gold}20`, border: `1px solid ${S.gold}40`, borderRadius: 10, padding: '8px 14px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <Shield size={16} color={S.gold} />
            <span style={{ color: S.gold, fontSize: 11, fontWeight: 700, letterSpacing: '0.1em' }}>FOUNDER ONLY</span>
          </div>
        </div>
        <h1 style={{ fontSize: 28, fontWeight: 800, margin: '0 0 6px', color: S.text }}>وحدة التحكم السيادي</h1>
        <p style={{ color: S.muted, fontSize: 13, margin: 0 }}>Sovereign Control Unit — Restricted Root Access Panel</p>
      </div>

      {/* ── Section: Sovereignty Keys ─────────────────────────────────────────── */}
      <section style={{ marginBottom: 32 }}>
        <h2 style={{ color: S.text, fontSize: 16, fontWeight: 700, margin: '0 0 18px', display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ color: S.gold }}>⬡</span> مفاتيح السيادة
          <span style={{ color: S.muted, fontWeight: 400, fontSize: 12 }}>Sovereignty Keys</span>
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          {KEYS.map(cfg => (
            <KeyCard
              key={cfg.id}
              cfg={cfg}
              enabled={keys[cfg.id as keyof typeof keys]}
              onToggle={() => handleKeyToggle(cfg.id as keyof typeof keys)}
            />
          ))}
        </div>
      </section>

      {/* ── Section: Emergency Protocol ───────────────────────────────────────── */}
      <section style={{ marginBottom: 32 }}>
        <h2 style={{ color: S.text, fontSize: 16, fontWeight: 700, margin: '0 0 18px', display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ color: S.red }}>⚠</span> بروتوكول الطوارئ
          <span style={{ color: S.muted, fontWeight: 400, fontSize: 12 }}>Emergency Protocol</span>
        </h2>

        {fired && (
          <div style={{
            background:   `${S.green}12`,
            border:       `1px solid ${S.green}40`,
            borderRadius: 12,
            padding:      '14px 20px',
            marginBottom: 16,
            display:      'flex',
            alignItems:   'center',
            gap:          12,
          }}>
            <CheckCircle2 size={20} color={S.green} />
            <div>
              <p style={{ color: S.green, fontWeight: 700, fontSize: 14, margin: 0 }}>تم تنفيذ العزل بنجاح</p>
              <p style={{ color: S.muted, fontSize: 11, margin: '2px 0 0' }}>تم تسجيل الحدث في سجل C9 اللامتغير</p>
            </div>
          </div>
        )}

        <div style={{
          background:   `${S.red}08`,
          border:       `2px solid ${S.red}40`,
          borderRadius: 16,
          padding:      28,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
            <div style={{ background: `${S.red}20`, borderRadius: 8, padding: 8 }}>
              <AlertTriangle size={20} color={S.red} />
            </div>
            <div>
              <p style={{ color: S.red, fontWeight: 700, fontSize: 14, margin: 0 }}>عزل طارئ للمنشأة</p>
              <p style={{ color: S.muted, fontSize: 11, margin: 0 }}>يُعطّل جميع عمليات القراءة والكتابة للمنشأة المحددة فوراً</p>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
            <div>
              <label style={{ color: S.muted, fontSize: 11, fontWeight: 600, display: 'block', marginBottom: 8, letterSpacing: '0.06em' }}>
                معرّف المنشأة (Entity ID) *
              </label>
              <input
                value={entityId}
                onChange={e => setEntityId(e.target.value)}
                placeholder="700XXXXXX"
                style={{
                  width:        '100%',
                  background:   S.bg700,
                  border:       `1px solid ${entityId ? S.red + '60' : S.border}`,
                  borderRadius: 10,
                  padding:      '12px 16px',
                  color:        S.text,
                  fontSize:     14,
                  fontFamily:   'IBM Plex Mono, monospace',
                  outline:      'none',
                  boxSizing:    'border-box',
                  transition:   'border-color 0.2s',
                }}
              />
            </div>
            <div>
              <label style={{ color: S.muted, fontSize: 11, fontWeight: 600, display: 'block', marginBottom: 8, letterSpacing: '0.06em' }}>
                سبب العزل *
              </label>
              <input
                value={reason}
                onChange={e => setReason(e.target.value)}
                placeholder="اكتب سبب العزل..."
                style={{
                  width:        '100%',
                  background:   S.bg700,
                  border:       `1px solid ${reason ? S.red + '60' : S.border}`,
                  borderRadius: 10,
                  padding:      '12px 16px',
                  color:        S.text,
                  fontSize:     13,
                  fontFamily:   'inherit',
                  outline:      'none',
                  boxSizing:    'border-box',
                  transition:   'border-color 0.2s',
                }}
              />
            </div>
          </div>

          <button
            disabled={!entityId.trim() || !reason.trim()}
            onClick={() => setModalStep(1)}
            style={{
              width:        '100%',
              background:   (!entityId.trim() || !reason.trim()) ? S.bg700 : 'linear-gradient(135deg, #dc2626, #b91c1c)',
              border:       `1px solid ${(!entityId.trim() || !reason.trim()) ? S.border : S.red}`,
              borderRadius: 12,
              padding:      '16px 0',
              color:        (!entityId.trim() || !reason.trim()) ? S.muted : '#fff',
              cursor:       (!entityId.trim() || !reason.trim()) ? 'not-allowed' : 'pointer',
              fontSize:     15,
              fontWeight:   800,
              fontFamily:   'inherit',
              display:      'flex',
              alignItems:   'center',
              justifyContent: 'center',
              gap:          10,
              transition:   'all 0.2s',
              boxShadow:    (!entityId.trim() || !reason.trim()) ? 'none' : `0 4px 24px ${S.red}40`,
            }}
          >
            <Zap size={18} />
            عزل المنشأة فوراً
          </button>
        </div>
      </section>

      {/* ── Section: Active Overrides Log ─────────────────────────────────────── */}
      <section>
        <h2 style={{ color: S.text, fontSize: 16, fontWeight: 700, margin: '0 0 18px', display: 'flex', alignItems: 'center', gap: 8 }}>
          <Clock size={16} color={S.gold} /> سجل التجاوزات النشطة
          <span style={{ color: S.muted, fontWeight: 400, fontSize: 12 }}>Active Overrides Log</span>
          <span style={{ marginRight: 'auto', background: `${S.gold}20`, border: `1px solid ${S.gold}40`, borderRadius: 99, padding: '2px 10px', color: S.gold, fontSize: 10, fontWeight: 700 }}>
            آخر 5 عمليات
          </span>
        </h2>

        <div style={{
          background:   S.bg700,
          border:       `1px solid ${S.border}`,
          borderRadius: 16,
          overflow:     'hidden',
        }}>
          {log.map((entry, i) => (
            <div key={entry.id} style={{
              padding:      '16px 24px',
              borderBottom: i < log.length - 1 ? `1px solid ${S.border}` : 'none',
              display:      'flex',
              alignItems:   'center',
              gap:          16,
              transition:   'background 0.2s',
            }}>
              {/* Status dot */}
              <div style={{
                width:      10,
                height:     10,
                borderRadius: '50%',
                background: entry.action === 'enabled' ? S.green : S.red,
                flexShrink: 0,
                boxShadow:  `0 0 8px ${entry.action === 'enabled' ? S.green : S.red}60`,
              }} />

              {/* Details */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <span style={{ color: S.text, fontSize: 13, fontWeight: 700 }}>{entry.key}</span>
                  <span style={{
                    background:   entry.action === 'enabled' ? `${S.green}20` : `${S.red}20`,
                    border:       `1px solid ${entry.action === 'enabled' ? S.green + '40' : S.red + '40'}`,
                    borderRadius: 99,
                    padding:      '1px 8px',
                    color:        entry.action === 'enabled' ? S.green : S.red,
                    fontSize:     10,
                    fontWeight:   700,
                  }}>
                    {entry.action === 'enabled' ? 'مُفعَّل' : 'مُعطَّل'}
                  </span>
                </div>
                <p style={{ color: S.muted, fontSize: 11, margin: 0 }}>{entry.reason}</p>
              </div>

              {/* Meta */}
              <div style={{ textAlign: 'left', flexShrink: 0 }}>
                <p style={{ color: S.gold, fontSize: 11, fontWeight: 600, margin: '0 0 2px' }}>{entry.by}</p>
                <p style={{ color: S.muted, fontSize: 10, margin: 0, fontFamily: 'IBM Plex Mono, monospace' }}>{entry.timestamp}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Confirm Modal ─────────────────────────────────────────────────────── */}
      {modalStep > 0 && (
        <ConfirmModal
          entityId={entityId}
          reason={reason}
          step={modalStep as 1 | 2}
          onStep2={() => setModalStep(2)}
          onFire={handleEmergencyFire}
          onClose={() => setModalStep(0)}
        />
      )}
    </div>
  );
}

export default SovereignControlUnit;
