import { Module, forwardRef } from '@nestjs/common';
import { ViolationsRepository } from './violations.repository';
import { RulesEngine } from './rules.engine';
import { ComplianceService } from './compliance.service';
import { ComplianceController } from './compliance.controller';
import { LeavesModule } from '../leaves/leaves.module';
import { DatabaseModule } from '../../database/database.module';

@Module({
  imports: [
    DatabaseModule,                   // Firestore + C9LedgerRepository
    forwardRef(() => LeavesModule),   // LeavesService.calculateLeaveDeductions() + findMyLeaves()
  ],
  providers:   [ViolationsRepository, RulesEngine, ComplianceService],
  controllers: [ComplianceController],
  exports:     [ComplianceService, ViolationsRepository],
})
export class ComplianceModule {}
