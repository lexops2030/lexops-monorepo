export default function LoginPage() {
  return <div className="flex h-screen items-center justify-center"><p className="text-neutral-500">صفحة تسجيل الدخول — قيد الإنشاء</p></div>;
}
