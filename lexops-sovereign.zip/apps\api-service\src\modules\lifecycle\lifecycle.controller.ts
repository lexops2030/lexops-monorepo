import { Controller, Get, Post, Param, Body, Request, Version, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsOptional, IsDateString } from 'class-validator';
import { LifecycleService } from './lifecycle.service';
import { Roles } from '../auth/firebase.guard';
import { TenantScopeGuard } from '../../common/guards';
import { Request as ExpressRequest } from 'express';
import type { LexOpsClaims } from '../auth/firebase.guard';

class ContractCreatedDto {
  @IsDateString() licenseExpiry: string;
  @IsDateString() @IsOptional() commercialRegExpiry?: string;
  @IsDateString() @IsOptional() vatExpiry?: string;
}

class EmployeeContractDto {
  @IsString() @IsNotEmpty() employeeId: string;
  @IsDateString() contractStartDate: string;
  @IsDateString() @IsOptional() contractEndDate?: string;
}

class ProbationStartDto {
  @IsString() @IsNotEmpty() employeeId: string;
  @IsDateString() probationStartDate: string;
}

@ApiTags('Lifecycle Engine')
@ApiBearerAuth('Firebase-JWT')
@Controller('entities/:tenantId/lifecycle')
@UseGuards(TenantScopeGuard)
export class LifecycleController {
  constructor(private readonly lifecycleService: LifecycleService) {}

  @Get('establishment')
  @Version('1')
  @Roles('sovereign', 'entity_admin')
  @ApiOperation({ summary: 'جلب دورة حياة المنشأة' })
  getEstablishment(@Param('tenantId') tenantId: string) {
    return this.lifecycleService.getEstablishmentLifecycle(tenantId);
  }

  @Post('establishment/contract')
  @Version('1')
  @Roles('sovereign')
  @ApiOperation({ summary: 'تفعيل مرحلة العقد للمنشأة + C9 Seal' })
  onContractCreated(
    @Param('tenantId') tenantId: string,
    @Body() dto: ContractCreatedDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.lifecycleService.onContractCreated({ tenantId, ...dto, actorUid: req.user.uid });
  }

  @Post('establishment/check-expiry')
  @Version('1')
  @Roles('sovereign', 'entity_admin')
  @ApiOperation({ summary: 'فحص انتهاء صلاحيات المنشأة وإطلاق التنبيهات' })
  checkExpiry(@Param('tenantId') tenantId: string) {
    return this.lifecycleService.checkExpiryAlerts(tenantId);
  }

  @Post('employee/contract')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'تسجيل عقد موظف جديد + C9 Seal' })
  onEmployeeContract(
    @Param('tenantId') tenantId: string,
    @Body() dto: EmployeeContractDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.lifecycleService.onEmployeeContractCreated({
      tenantId, ...dto, actorUid: req.user.uid,
    });
  }

  @Post('employee/probation')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'بدء فترة التجربة (90 يوم) + تنبيه اليوم 80' })
  onProbationStart(
    @Param('tenantId') tenantId: string,
    @Body() dto: ProbationStartDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.lifecycleService.onProbationStart({
      tenantId, ...dto, actorUid: req.user.uid,
    });
  }

  @Get('employee/:employeeId')
  @Version('1')
  @Roles('entity_admin', 'sovereign', 'employee')
  @ApiOperation({ summary: 'جلب دورة حياة موظف' })
  getEmployeeLifecycle(
    @Param('tenantId') tenantId: string,
    @Param('employeeId') employeeId: string,
  ) {
    return this.lifecycleService.getEmployeeLifecycle(tenantId, employeeId);
  }

  @Get('kpis')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'سجل KPIs الامتثال (آخر 12 شهر)' })
  getKpis(@Param('tenantId') tenantId: string) {
    return this.lifecycleService.getKpiHistory(tenantId);
  }

  @Post('cron/probation-alerts')
  @Version('1')
  @Roles('sovereign')
  @ApiOperation({ summary: '[Cron] فحص وإطلاق تنبيهات اليوم 80 من التجربة' })
  runProbationAlerts() {
    return this.lifecycleService.checkProbationAlerts();
  }
}
