import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Building2, Scale,
  ShieldCheck, Briefcase, LogOut, Menu, X,
  CalendarDays,
} from 'lucide-react';
import { useState } from 'react';
import { getAuth, signOut } from 'firebase/auth';
import { cn } from '../lib/utils';

const navItems = [
  { to: '/dashboard',  icon: LayoutDashboard, label: 'لوحة التحكم' },
  { to: '/attendance', icon: Building2,        label: 'الحضور والانصراف' },
  { to: '/leaves',     icon: CalendarDays,     label: 'الإجازات' },
  { to: '/violations', icon: ShieldCheck,      label: 'المخالفات' },
  { to: '/lexi',       icon: Scale,            label: 'محرك LEXI القانوني' },
  { to: '/sovereign',  icon: ShieldCheck,      label: 'لوحة السيادة' },
  { to: '/freelancer', icon: Briefcase,        label: 'بوابة المستقل' },
];

export default function DashboardLayout() {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleSignOut = async () => {
    await signOut(getAuth());
    navigate('/login');
  };

  return (
    <div className="flex h-screen bg-neutral-50 overflow-hidden" dir="rtl">
      {/* ── Sidebar ── */}
      <aside className={cn(
        'flex flex-col bg-white border-l border-neutral-200 transition-all duration-300',
        sidebarOpen ? 'w-64' : 'w-16',
      )}>
        {/* Logo */}
        <div className="flex h-16 items-center gap-3 px-4 border-b border-neutral-100">
          <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center shrink-0">
            <Scale className="h-4 w-4 text-white" />
          </div>
          {sidebarOpen && (
            <span className="font-bold text-primary text-lg tracking-tight">LexOps</span>
          )}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="mr-auto text-neutral-400 hover:text-neutral-700"
          >
            {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>

        {/* Nav Links */}
        <nav className="flex-1 overflow-y-auto py-4 px-2 space-y-1">
          {navItems.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                cn('sidebar-link', isActive && 'sidebar-link-active')
              }
            >
              <Icon className="h-4 w-4 shrink-0" />
              {sidebarOpen && <span>{label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* Sign Out */}
        <div className="p-3 border-t border-neutral-100">
          <button
            onClick={handleSignOut}
            className="sidebar-link w-full text-red-500 hover:bg-red-50 hover:text-red-600"
          >
            <LogOut className="h-4 w-4 shrink-0" />
            {sidebarOpen && <span>تسجيل الخروج</span>}
          </button>
        </div>
      </aside>

      {/* ── Main Content ── */}
      <main className="flex-1 overflow-y-auto">
        <div className="p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
