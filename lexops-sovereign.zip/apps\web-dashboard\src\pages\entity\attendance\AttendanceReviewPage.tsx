import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  ShieldAlert, CheckCircle2, XCircle,
  MapPin, Clock, Smartphone, ChevronDown,
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';
import { Button } from '../../../components/ui/Button';
import { Input } from '../../../components/ui/Input';
import api from '../../../lib/api';
import { cn } from '../../../lib/utils';

// ── Types ─────────────────────────────────────────────────────────────────────

interface AttendanceRecord {
  recordId: string;
  employeeUid: string;
  branchId: string;
  eventType: 'check_in' | 'check_out';
  status: 'accepted' | 'pending_review' | 'rejected';
  lat: number;
  lng: number;
  accuracy: number;
  distanceMeters: number;
  isMockSuspected: boolean;
  spoofReason: string | null;
  geofenceReason: string;
  velocityMps: number | null;
  serverTimestampMs: number;
  deviceId?: string;
}

interface ReviewFormState {
  recordId: string;
  decision: 'accepted' | 'rejected' | null;
  reason: string;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function StatusBadge({ record }: { record: AttendanceRecord }) {
  const hasSpoofFlag = record.isMockSuspected;

  return (
    <div className="flex flex-wrap gap-2">
      <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 border border-amber-200 px-3 py-1 text-xs font-semibold text-amber-700">
        <Clock className="h-3.5 w-3.5" />
        قيد المراجعة
      </span>
      {hasSpoofFlag && (
        <span className="inline-flex items-center gap-1.5 rounded-full bg-red-50 border border-red-200 px-3 py-1 text-xs font-semibold text-red-700">
          <ShieldAlert className="h-3.5 w-3.5" />
          اشتباه تزوير
        </span>
      )}
    </div>
  );
}

function RecordCard({
  record,
  onReview,
  isExpanded,
  onToggle,
}: {
  record: AttendanceRecord;
  onReview: (form: ReviewFormState) => void;
  isExpanded: boolean;
  onToggle: () => void;
}) {
  const [decision, setDecision] = useState<'accepted' | 'rejected' | null>(null);
  const [reason, setReason] = useState('');

  const timeAgo = formatDistanceToNow(new Date(record.serverTimestampMs), {
    addSuffix: true,
    locale: ar,
  });

  return (
    <div className={cn(
      'rounded-xl border bg-white shadow-card transition-all duration-200',
      record.isMockSuspected ? 'border-red-200' : 'border-amber-200',
    )}>
      {/* ── Summary Row ── */}
      <button
        onClick={onToggle}
        className="flex w-full items-center gap-4 p-5 text-start"
      >
        {/* Event icon */}
        <div className={cn(
          'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
          record.isMockSuspected ? 'bg-red-100' : 'bg-amber-100',
        )}>
          {record.isMockSuspected
            ? <ShieldAlert className="h-5 w-5 text-red-600" />
            : <MapPin className="h-5 w-5 text-amber-600" />
          }
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <StatusBadge record={record} />
          </div>
          <p className="text-xs text-neutral-500 truncate">
            {record.eventType === 'check_in' ? 'حضور' : 'انصراف'} · {timeAgo}
          </p>
          <p className="text-xs text-neutral-400 truncate mt-0.5 font-mono">
            {record.recordId}
          </p>
        </div>

        <ChevronDown className={cn(
          'h-4 w-4 text-neutral-400 shrink-0 transition-transform duration-200',
          isExpanded && 'rotate-180',
        )} />
      </button>

      {/* ── Detail Panel ── */}
      {isExpanded && (
        <div className="border-t border-neutral-100 p-5 space-y-4 animate-fade-in">

          {/* ── Evidence Grid ── */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <InfoTile label="المسافة من الفرع" value={`${record.distanceMeters.toFixed(1)} م`} />
            <InfoTile label="دقة GPS" value={`${record.accuracy} م`} />
            <InfoTile
              label="السرعة المكتشفة"
              value={record.velocityMps != null ? `${record.velocityMps.toFixed(1)} م/ث` : 'غير متاح'}
            />
            <InfoTile label="الإحداثيات" value={`${record.lat.toFixed(5)}, ${record.lng.toFixed(5)}`} />
            <InfoTile label="الجهاز" value={record.deviceId ?? 'غير معروف'} />
          </div>

          {/* ── Spoof / Geofence reasons ── */}
          {record.isMockSuspected && record.spoofReason && (
            <div className="rounded-lg border border-red-200 bg-red-50 p-3">
              <p className="text-xs font-semibold text-red-700 mb-1">سبب الاشتباه بالتزوير</p>
              <p className="text-xs text-red-600">{record.spoofReason}</p>
            </div>
          )}
          <div className="rounded-lg border border-neutral-100 bg-neutral-50 p-3">
            <p className="text-xs font-semibold text-neutral-500 mb-1">تقييم النطاق الجغرافي</p>
            <p className="text-xs text-neutral-600">{record.geofenceReason}</p>
          </div>

          {/* ── Review Actions ── */}
          <div className="pt-2 border-t border-neutral-100">
            <p className="text-sm font-semibold text-neutral-700 mb-3">قرار المراجعة</p>

            <div className="flex gap-2 mb-3">
              <button
                onClick={() => setDecision('accepted')}
                className={cn(
                  'flex-1 flex items-center justify-center gap-2 rounded-lg border py-2.5 text-sm font-semibold transition-colors',
                  decision === 'accepted'
                    ? 'border-green-500 bg-green-50 text-green-700'
                    : 'border-neutral-200 text-neutral-600 hover:border-green-300 hover:bg-green-50/50',
                )}
              >
                <CheckCircle2 className="h-4 w-4" /> قبول
              </button>
              <button
                onClick={() => setDecision('rejected')}
                className={cn(
                  'flex-1 flex items-center justify-center gap-2 rounded-lg border py-2.5 text-sm font-semibold transition-colors',
                  decision === 'rejected'
                    ? 'border-red-400 bg-red-50 text-red-700'
                    : 'border-neutral-200 text-neutral-600 hover:border-red-300 hover:bg-red-50/50',
                )}
              >
                <XCircle className="h-4 w-4" /> رفض
              </button>
            </div>

            <Input
              id={`reason-${record.recordId}`}
              label="سبب القرار"
              placeholder="أدخل مبرر القرار ليُختم في سجل C9..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />

            <Button
              className="mt-3 w-full"
              disabled={!decision || reason.trim().length < 3}
              onClick={() => onReview({ recordId: record.recordId, decision, reason })}
            >
              تأكيد القرار وختم C9
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function InfoTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-neutral-50 border border-neutral-100 px-3 py-2">
      <p className="text-xs text-neutral-400 mb-0.5">{label}</p>
      <p className="text-sm font-semibold text-neutral-800 font-mono truncate">{value}</p>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────

const TENANT_ID = import.meta.env.VITE_DEMO_TENANT_ID ?? 'ENTITY_700';

export default function AttendanceReviewPage() {
  const queryClient = useQueryClient();
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);

  const { data: records = [], isLoading } = useQuery<AttendanceRecord[]>({
    queryKey: ['attendance-pending', TENANT_ID],
    queryFn: () =>
      api.get(`/entities/${TENANT_ID}/attendance/pending-review`).then((r) => r.data),
    refetchInterval: 30_000,
  });

  const reviewMutation = useMutation({
    mutationFn: ({ recordId, decision, reason }: ReviewFormState) =>
      api.patch(`/entities/${TENANT_ID}/attendance/${recordId}/review`, {
        decision, reason,
      }).then((r) => r.data),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['attendance-pending', TENANT_ID] });
      setToast({ msg: data.message, type: 'success' });
      setTimeout(() => setToast(null), 4000);
    },
    onError: () => {
      setToast({ msg: 'حدث خطأ أثناء تسجيل القرار', type: 'error' });
      setTimeout(() => setToast(null), 4000);
    },
  });

  return (
    <div>
      {/* ── Header ── */}
      <div className="mb-8 flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-100">
            <ShieldAlert className="h-6 w-6 text-amber-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">مراجعة الحضور الميداني</h1>
            <p className="text-sm text-neutral-500">
              السجلات التي تحتاج مراجعة إدارية — كل قرار يُختم في سجل C9
            </p>
          </div>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-amber-50 border border-amber-200 px-4 py-1.5 text-sm font-semibold text-amber-700">
          {isLoading ? '...' : records.length} معلق
        </span>
      </div>

      {/* ── Toast ── */}
      {toast && (
        <div className={cn(
          'mb-6 flex items-center gap-3 rounded-xl border px-5 py-4 animate-fade-in',
          toast.type === 'success'
            ? 'border-green-200 bg-green-50'
            : 'border-red-200 bg-red-50',
        )}>
          {toast.type === 'success'
            ? <CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" />
            : <XCircle className="h-5 w-5 text-red-600 shrink-0" />
          }
          <p className={`text-sm font-medium ${toast.type === 'success' ? 'text-green-800' : 'text-red-700'}`}>
            {toast.msg}
          </p>
        </div>
      )}

      {/* ── Records List ── */}
      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
        </div>
      ) : records.length === 0 ? (
        <div className="card-sovereign flex flex-col items-center justify-center py-16 text-center">
          <CheckCircle2 className="h-14 w-14 text-green-400 mb-4" />
          <p className="text-lg font-semibold text-neutral-700">لا توجد سجلات معلقة</p>
          <p className="text-sm text-neutral-400 mt-1">جميع سجلات الحضور تمت مراجعتها</p>
        </div>
      ) : (
        <div className="space-y-4">
          {records.map((record) => (
            <RecordCard
              key={record.recordId}
              record={record}
              isExpanded={expandedId === record.recordId}
              onToggle={() =>
                setExpandedId(expandedId === record.recordId ? null : record.recordId)
              }
              onReview={(form) => reviewMutation.mutate(form)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
