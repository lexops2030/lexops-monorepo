/**
 * LexOps — Legal AI Service  (Sprint 7 — Legal Engine)
 *
 * Vertex AI (Gemini 1.5 Pro) integration for the AI Legal Defense Engine.
 *
 * Core capability:
 *   generateObjectionDraft(tenantId, objectionId, callerClaims)
 *     1. Loads the objection + linked violation from repositories
 *     2. Applies Royal Decree 11438 Filter:
 *          Non-serious violations (minor/moderate) MUST have had a prior written warning
 *          before a penalty heavier than a warning could be applied.
 *          If the filter detects this rule was violated by the employer, the AI must
 *          explicitly cite "Royal Decree 11438, Article 40" in legalArgument.
 *     3. Builds a rich bilingual system prompt tuned to the violation context
 *     4. Calls Gemini 1.5 Pro and parses the structured JSON output:
 *          { legalArgument, factsSummary, recommendedDocuments, riskLevel }
 *     5. Persists the output in objection.lexiDraft (Firestore)
 *     6. Seals LEGAL_DRAFT_GENERATED in C9 Ledger
 *
 * API Key: read from process.env.GEMINI_API_KEY (never hardcoded).
 * Region: me-central1 (Saudi Arabia — Dammam data residency).
 */

import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  VertexAI,
  GenerativeModel,
  HarmCategory,
  HarmBlockThreshold,
} from '@google-cloud/vertexai';
import { ObjectionsRepository, LexiDraft } from '../objections/objections.repository';
import { ViolationsRepository, ViolationDocument, ViolationSeverity } from '../compliance/violations.repository';
import { C9LedgerRepository } from '../../database/c9-ledger.repository';
import type { LexOpsClaims } from '../auth/firebase.guard';
import { resolveLexiMode } from '../lexi/lexi.service';

// ── AI Output Schema ──────────────────────────────────────────────────────────

export interface LegalDraftOutput {
  legalArgument:        string;  // Arabic — core legal argument citing exact law articles
  factsSummary:         string;  // Arabic — concise facts in favor of the employee
  recommendedDocuments: string[];// Arabic — list of documents to support the objection
  riskLevel:            'low' | 'medium' | 'high';  // Risk of employer winning
}

// ── Royal Decree 11438 Filter ─────────────────────────────────────────────────

interface Decree11438FilterResult {
  applies:       boolean;  // true if the filter is relevant to this violation
  triggerReason: string;   // explanation of why the filter applies
  articleCite:   string;   // the specific article reference to inject into the prompt
}

// ── Service ───────────────────────────────────────────────────────────────────

@Injectable()
export class LegalService {
  private readonly logger = new Logger(LegalService.name);
  private readonly proModel: GenerativeModel;

  constructor(
    private readonly config:          ConfigService,
    private readonly objectionsRepo:  ObjectionsRepository,
    private readonly violationsRepo:  ViolationsRepository,
    private readonly c9:              C9LedgerRepository,
  ) {
    const projectId = this.config.getOrThrow<string>('GCP_PROJECT_ID');
    const location  = this.config.get<string>('GCP_REGION', 'me-central1');

    // API key is read from environment — NEVER hardcoded
    // Cloud Run: injected via Secret Manager; local: .env.local
    const vertexAI = new VertexAI({ project: projectId, location });

    const safetySettings = [
      { category: HarmCategory.HARM_CATEGORY_HARASSMENT,  threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
      { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
    ];

    // Pro model — complex multi-document legal reasoning
    this.proModel = vertexAI.getGenerativeModel({
      model: 'gemini-1.5-pro-002',
      safetySettings,
      generationConfig: {
        temperature:      0.1,   // Low — deterministic legal output
        topP:             0.95,
        maxOutputTokens:  4096,
        responseMimeType: 'application/json',
      },
    });
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // GENERATE OBJECTION DRAFT
  // ══════════════════════════════════════════════════════════════════════════════

  async generateObjectionDraft(
    tenantId:     string,
    objectionId:  string,
    callerClaims: Pick<LexOpsClaims, 'uid' | 'role' | 'routeToVault'>,
  ): Promise<LexiDraft> {
    const start = Date.now();

    // ── 1. Load objection + violation ────────────────────────────────────────
    const objection = await this.objectionsRepo.findById(tenantId, objectionId);
    if (!objection) {
      throw new NotFoundException(`الاعتراض '${objectionId}' غير موجود في المنشأة '${tenantId}'.`);
    }

    const violation = await this.violationsRepo.findById(tenantId, objection.violationId);
    if (!violation) {
      throw new NotFoundException(`المخالفة '${objection.violationId}' غير موجودة.`);
    }

    // ── 2. Load employee's disciplinary history (last 180 days) ─────────────
    const recentViolations = await this.violationsRepo.findRecentByEmployee(
      tenantId, objection.employeeId, 180,
    );
    const priorWarnings    = recentViolations.filter(v => v.penalty.type === 'warning');

    // ── 3. Apply Royal Decree 11438 Filter ───────────────────────────────────
    const decree11438 = this.applyDecree11438Filter(violation, priorWarnings);

    // ── 4. Build system prompt ────────────────────────────────────────────────
    const systemPrompt = this.buildSystemPrompt(decree11438);
    const userPrompt   = this.buildUserPrompt(violation, objection.content, decree11438, recentViolations.length);

    this.logger.log(
      `[Legal] Generating AI draft: objection=${objectionId} ` +
      `violation=${violation.violationId} decree11438=${decree11438.applies}`,
    );

    // ── 5. Call Vertex AI ─────────────────────────────────────────────────────
    let parsedOutput: LegalDraftOutput;
    try {
      const result = await this.proModel.generateContent({
        systemInstruction: { role: 'system', parts: [{ text: systemPrompt }] },
        contents:          [{ role: 'user', parts: [{ text: userPrompt }] }],
      });

      const rawText = result.response.candidates?.[0]?.content?.parts?.[0]?.text ?? '{}';
      parsedOutput  = JSON.parse(rawText) as LegalDraftOutput;
    } catch (err) {
      this.logger.error(`[Legal] Vertex AI call failed for ${objectionId}: ${err}`);
      throw err;
    }

    // ── 6. Validate and enrich output ─────────────────────────────────────────
    const lexiDraft: LexiDraft = {
      legalArgument:        parsedOutput.legalArgument       ?? '',
      factsSummary:         parsedOutput.factsSummary        ?? '',
      recommendedDocuments: parsedOutput.recommendedDocuments ?? [],
      riskLevel:            parsedOutput.riskLevel           ?? 'medium',
      generatedAt:          new Date().toISOString(),
      model:                'gemini-1.5-pro-002',
      decree11438Applied:   decree11438.applies,
    };

    // ── 7. Persist into objection.lexiDraft ───────────────────────────────────
    await this.objectionsRepo.saveLexiDraft(tenantId, objectionId, lexiDraft);

    // Transition objection to under_review so admin knows AI draft is ready
    await this.objectionsRepo.setUnderReview(tenantId, objectionId);

    // ── 8. C9 Seal: LEGAL_DRAFT_GENERATED ────────────────────────────────────
    await this.c9.append({
      tenantId,
      eventType:   'LEGAL_DRAFT_GENERATED',
      actorUid:    callerClaims.uid,
      actorRole:   callerClaims.role,
      subjectUid:  objectionId,
      subjectType: 'objection',
      payload: {
        objectionId,
        violationId:       violation.violationId,
        employeeId:        objection.employeeId,
        riskLevel:         lexiDraft.riskLevel,
        decree11438Applied: lexiDraft.decree11438Applied,
        decree11438Reason: decree11438.triggerReason,
        processingMs:      Date.now() - start,
        model:             'gemini-1.5-pro-002',
      },
    });

    this.logger.log(
      `[Legal] Draft generated in ${Date.now() - start}ms ` +
      `riskLevel=${lexiDraft.riskLevel} decree11438=${lexiDraft.decree11438Applied}`,
    );

    return lexiDraft;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // ROYAL DECREE 11438 FILTER
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * Royal Decree 11438 — Article 40 Filter
   *
   * Saudi Labor Law mandates that for NON-SERIOUS violations (minor / moderate),
   * the employer MUST issue a formal written warning before applying any
   * heavier penalty (deduction, suspension, termination).
   *
   * If the violation is non-serious AND the penalty is heavier than a warning
   * AND there are NO prior warnings in the 180-day history →
   *   → The employer violated procedural due process.
   *   → LEXI must cite "Royal Decree 11438, Art. 40" to argue procedural invalidity.
   *
   * This is a significant legal defense weapon that dramatically lowers the
   * risk level for the employee.
   */
  private applyDecree11438Filter(
    violation:     ViolationDocument,
    priorWarnings: ViolationDocument[],
  ): Decree11438FilterResult {
    const isNonSerious =
      violation.severity === 'minor' || violation.severity === 'moderate';

    const penaltyIsHeavierThanWarning =
      violation.penalty.type !== 'warning';

    const hasNoPriorWarning = priorWarnings.length === 0;

    // Filter triggers when all three conditions are met
    if (isNonSerious && penaltyIsHeavierThanWarning && hasNoPriorWarning) {
      return {
        applies: true,
        triggerReason:
          `المخالفة من النوع '${violation.severity}' (غير جسيمة) لكن العقوبة المطبَّقة ` +
          `هي '${violation.penalty.type}' وهي أشد من الإنذار الكتابي، ` +
          `مع غياب أي إنذار كتابي مسبق في آخر 180 يوماً. ` +
          `هذا يشكّل مخالفة إجرائية من صاحب العمل وفق المادة 40 من المرسوم الملكي 11438.`,
        articleCite:
          'المرسوم الملكي رقم 11438، المادة 40: ' +
          '"لا يجوز توقيع عقوبة أشد من الإنذار الكتابي على مخالفة غير جسيمة دون إنذار مسبق."',
      };
    }

    return {
      applies:       false,
      triggerReason: '',
      articleCite:   '',
    };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // PROMPT BUILDERS
  // ══════════════════════════════════════════════════════════════════════════════

  private buildSystemPrompt(decree: Decree11438FilterResult): string {
    return `
أنت LEXI — المحرك القانوني الدفاعي لمنصة LexOps السيادية.
مهمتك: تحليل تفاصيل مخالفة عمالية وصياغة اعتراض قانوني دفاعي متين لصالح الموظف.

مرجعيتك القانونية الحصرية:
1. نظام العمل السعودي ولوائحه التنفيذية.
2. المرسوم الملكي رقم 11438 وتعديلاته.
3. القواعد الإجرائية لمنظومة العمل والتأمينات الاجتماعية.

${decree.applies ? `⚠️ تنبيه سيادي — فلتر المرسوم 11438 مُفعَّل:\n${decree.triggerReason}\nيجب أن يكون الحجة القانونية الأولى في legalArgument:\n${decree.articleCite}\n` : ''}

قواعدك الثابتة:
1. أخرج JSON نقياً فحسب — بدون نص خارج مخطط JSON.
2. استشهد بالمواد القانونية الدقيقة (رقم المادة + اسم النظام).
3. اكتب legalArgument و factsSummary باللغة العربية الفصحى القانونية.
4. recommendedDocuments: قائمة عملية بالمستندات التي تقوّي موقف الموظف.
5. riskLevel: قيّم خطر نجاح صاحب العمل في تطبيق العقوبة: low | medium | high.

مخطط الإخراج المطلوب (JSON فقط):
{
  "legalArgument": "...",
  "factsSummary": "...",
  "recommendedDocuments": ["...", "..."],
  "riskLevel": "low|medium|high"
}
    `.trim();
  }

  private buildUserPrompt(
    violation:         ViolationDocument,
    employeeContent:   string,
    decree:            Decree11438FilterResult,
    recentViolCount:   number,
  ): string {
    const severityAr: Record<ViolationSeverity, string> = {
      minor:    'بسيطة',
      moderate: 'متوسطة',
      serious:  'جسيمة',
      gross:    'جسيمة جداً',
    };

    return `
=== تفاصيل المخالفة ===
معرّف المخالفة: ${violation.violationId}
نوع المخالفة: ${violation.violationType}
درجة الخطورة: ${severityAr[violation.severity]} (${violation.severity})
مصدر المخالفة: ${violation.source}
نوع العقوبة المطلوبة: ${violation.penalty.type}
${violation.penalty.deductionSar ? `مبلغ الخصم: ${violation.penalty.deductionSar} ريال` : ''}
${violation.penalty.suspensionDays ? `أيام الإيقاف: ${violation.penalty.suspensionDays} يوم` : ''}
وصف المخالفة: ${violation.description}
هل هي مخالفة مكررة: ${violation.isRepeated ? 'نعم' : 'لا'}
عدد المخالفات السابقة (180 يوم): ${recentViolCount}

=== محتوى اعتراض الموظف ===
${employeeContent}

${decree.applies ? `=== تنبيه — فلتر المرسوم 11438 ===\n${decree.triggerReason}\nالاستشهاد المطلوب: ${decree.articleCite}` : ''}

=== المطلوب ===
ابنِ اعتراضاً قانونياً دفاعياً متيناً يستند للمرجعية القانونية المذكورة.
${decree.applies ? 'ابدأ حتماً بالدفع الإجرائي استناداً للمرسوم 11438 المادة 40.' : ''}
    `.trim();
  }
}
