/**
 * LexOps — Payroll Service
 *
 * Implements:
 *   1. generateEntityPayroll(tenantId, month) — Saudi Labor Law master formula
 *   2. generateIndependentInvoice(uid, month) — Pay-per-action stamped tax invoice
 *   3. approvePayroll / closePayroll         — Sovereign closing gate
 *   4. addAdjustment                         — Post-closing adjustments with carry-forward
 *
 * Saudi Labor Law formula (Article 87 + Royal Decree 11438):
 *   dailySalary      = baseSalary / 30
 *   hourlyRate       = dailySalary / 8
 *   absenceDeduction = absenceDays        * dailySalary
 *   lateDeduction    = floor(lateMin/60)  * (dailySalary / 2)
 *   leaveDeduction   = unpaidLeaveDays    * dailySalary
 *   overtimeAmount   = overtimeHours      * hourlyRate * 1.5
 *   netSalary        = baseSalary + overtimeAmount
 *                      - (absenceDeduction + lateDeduction + leaveDeduction)
 */

import {
  Injectable, Logger,
  ConflictException, NotFoundException,
} from '@nestjs/common';
import { getFirestore } from 'firebase-admin/firestore';
import {
  PayrollRepository,
  PayrollRun,
  PayrollItem,
  PayrollItemBreakdown,
  PayrollAdjustment,
  IndependentInvoice,
} from './payroll.repository';
import { C9LedgerRepository } from '../../database/c9-ledger.repository';
import { LeavesService } from '../leaves/leaves.service';

// ── Types ─────────────────────────────────────────────────────────────────────

export interface GenerateEntityPayrollInput {
  tenantId:    string;
  month:       string;  // 'YYYY-MM'
  generatedBy: string;  // actor UID
}

export interface GenerateInvoiceInput {
  uid:             string;
  month:           string;
  documentedHours: number;  // Geofenced hours pulled from attendance
  hourlyRate:      number;  // Contractual rate in SAR
  vatRate?:        number;  // Default 0.15 (15% KSA VAT)
}

export interface AddAdjustmentInput {
  tenantId:    string;
  runId:       string;
  employeeUid: string;
  amount:      number;   // positive = bonus, negative = deduction
  reason:      string;
  addedBy:     string;
  carryForward: boolean;
}

/** Raw employee data fetched from Firestore for payroll computation */
interface EmployeePayrollData {
  employeeUid:  string;
  employeeName: string;
  nationalId:   string;
  branchId:     string;
  position:     string;
  baseSalary:   number;
  status:       string;
}

/** Aggregated attendance stats for a month */
interface AttendanceMonthStats {
  absenceDays:  number;
  lateMinutes:  number;
  overtimeHours: number;
}

// ── Service ───────────────────────────────────────────────────────────────────

@Injectable()
export class PayrollService {
  private readonly logger = new Logger(PayrollService.name);
  private db = getFirestore();

  constructor(
    private readonly payrollRepo: PayrollRepository,
    private readonly c9: C9LedgerRepository,
    private readonly leavesService: LeavesService,
  ) {}

  // ══════════════════════════════════════════════════════════════════════════════
  // 1. ENTITY PAYROLL — Saudi Labor Law Master Formula
  // ══════════════════════════════════════════════════════════════════════════════

  async generateEntityPayroll(input: GenerateEntityPayrollInput): Promise<PayrollRun> {
    const { tenantId, month, generatedBy } = input;

    this.logger.log(`[Payroll] Generating run for tenant=${tenantId} month=${month}`);

    // ── Fetch active employees ───────────────────────────────────────────────
    const employees = await this.fetchActiveEmployees(tenantId);
    if (employees.length === 0) {
      throw new ConflictException(
        `لا يوجد موظفون نشطون في المنشأة '${tenantId}' لتوليد المسير.`,
      );
    }

    // ── Fetch carry-forward adjustments from previous month ─────────────────
    const prevMonth       = this.previousMonth(month);
    const carryForwards   = await this.payrollRepo.fetchCarryForwardAdjustments(tenantId, prevMonth);
    const carryMap        = this.buildCarryMap(carryForwards);

    // ── Build month date range ───────────────────────────────────────────────
    const { monthStart, monthEnd } = this.monthRange(month);

    // ── Create the run in draft ──────────────────────────────────────────────
    const run = await this.payrollRepo.createRun(tenantId, {
      tenantId,
      month,
      status:         'draft',
      totalNetSalary: 0,
      employeeCount:  employees.length,
      generatedBy,
    });

    // ── Process each employee ────────────────────────────────────────────────
    let totalNet = 0;

    for (const emp of employees) {
      const item = await this.computePayrollItem(
        tenantId, emp, monthStart, monthEnd, carryMap[emp.employeeUid] ?? [],
      );
      await this.payrollRepo.upsertItem(tenantId, run.runId, item);
      totalNet += item.breakdown.netSalary;
    }

    // ── Update run totals ────────────────────────────────────────────────────
    await this.db
      .collection('entities').doc(tenantId)
      .collection('payroll_runs').doc(run.runId)
      .update({ totalNetSalary: Math.round(totalNet * 100) / 100 });

    // ── C9 Seal: PAYROLL_GENERATED ────────────────────────────────────────────
    await this.c9.append({
      tenantId,
      eventType:   'PAYROLL_GENERATED',
      actorUid:    generatedBy,
      actorRole:   'entity_admin',
      subjectUid:  run.runId,
      subjectType: 'payroll_run',
      payload: {
        runId:         run.runId,
        month,
        employeeCount: employees.length,
        totalNetSalary: Math.round(totalNet * 100) / 100,
        carryForwardCount: carryForwards.length,
      },
    });

    this.logger.log(
      `[Payroll] Run ${run.runId} generated — ${employees.length} employees, ` +
      `total net: ${Math.round(totalNet)} SAR`,
    );

    return { ...run, totalNetSalary: Math.round(totalNet * 100) / 100, employeeCount: employees.length };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 2. INDEPENDENT WORKER INVOICE — Pay-per-Action, Stamped Tax Invoice
  // ══════════════════════════════════════════════════════════════════════════════

  async generateIndependentInvoice(input: GenerateInvoiceInput): Promise<IndependentInvoice> {
    const { uid, month, documentedHours, hourlyRate, vatRate = 0.15 } = input;

    // Guard: no duplicate invoice for same month
    const existing = await this.payrollRepo.findInvoiceByMonth(uid, month);
    if (existing) {
      throw new ConflictException(
        `فاتورة ضريبية مسبقة لشهر ${month} للمستخدم ${uid} (${existing.invoiceId}).`,
      );
    }

    // ── Formula: Total_Pay = Documented_Geofenced_Hours * Contractual_Hourly_Rate
    const totalPay    = Math.round(documentedHours * hourlyRate * 100) / 100;
    const vatAmount   = Math.round(totalPay * vatRate * 100) / 100;
    const totalWithVat = Math.round((totalPay + vatAmount) * 100) / 100;

    const invoice = await this.payrollRepo.createInvoice(uid, {
      uid,
      month,
      documentedHours,
      hourlyRate,
      totalPay,
      vatRate,
      vatAmount,
      totalWithVat,
      status: 'draft',
    });

    // Stamp immediately — tax invoice is sealed upon creation
    await this.payrollRepo.stampInvoice(uid, invoice.invoiceId);

    // ── C9 Seal: INDEPENDENT_INVOICE_GENERATED ────────────────────────────────
    await this.c9.append({
      tenantId:    `IND_${uid}`,
      eventType:   'INDEPENDENT_INVOICE_GENERATED',
      actorUid:    uid,
      actorRole:   'freelancer',
      subjectUid:  invoice.invoiceId,
      subjectType: 'independent_invoice',
      payload: {
        invoiceId:      invoice.invoiceId,
        month,
        documentedHours,
        hourlyRate,
        totalPay,
        vatRate,
        vatAmount,
        totalWithVat,
      },
    });

    this.logger.log(
      `[Payroll] Invoice ${invoice.invoiceId} stamped for uid=${uid} ` +
      `— ${documentedHours}h * ${hourlyRate} SAR/h = ${totalPay} SAR (+VAT: ${totalWithVat})`,
    );

    return { ...invoice, status: 'stamped' };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 3. SOVEREIGN CLOSING & APPROVAL
  // ══════════════════════════════════════════════════════════════════════════════

  async approvePayroll(
    tenantId: string,
    runId: string,
    approvedBy: string,
  ): Promise<{ message: string; run: PayrollRun | null }> {
    await this.payrollRepo.approveRun(tenantId, runId, approvedBy);

    await this.c9.append({
      tenantId,
      eventType:   'PAYROLL_APPROVED',
      actorUid:    approvedBy,
      actorRole:   'entity_admin',
      subjectUid:  runId,
      subjectType: 'payroll_run',
      payload: { runId, action: 'approved' },
    });

    const run = await this.payrollRepo.findRunById(tenantId, runId);
    return { message: `تم اعتماد مسير الرواتب '${runId}' وختمه في C9.`, run };
  }

  /**
   * Close payroll — no further item mutations after this point.
   * The repository enforces immutability at the code level.
   */
  async closePayroll(
    tenantId: string,
    runId: string,
    closedBy: string,
  ): Promise<{ message: string; run: PayrollRun | null }> {
    await this.payrollRepo.closeRun(tenantId, runId, closedBy);

    await this.c9.append({
      tenantId,
      eventType:   'PAYROLL_CLOSED',
      actorUid:    closedBy,
      actorRole:   'entity_admin',
      subjectUid:  runId,
      subjectType: 'payroll_run',
      payload: {
        runId,
        action: 'closed',
        note:   'Immutability enforced — no further item mutations allowed.',
      },
    });

    const run = await this.payrollRepo.findRunById(tenantId, runId);
    return {
      message: `تم إغلاق مسير الرواتب '${runId}' نهائياً. ` +
               `البنود محمية ضد أي تعديل. استخدم نقطة التسويات للتعديل على الشهر القادم.`,
      run,
    };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 4. POST-CLOSING ADJUSTMENTS
  // ══════════════════════════════════════════════════════════════════════════════

  async addAdjustment(input: AddAdjustmentInput): Promise<PayrollAdjustment> {
    const adj = await this.payrollRepo.addAdjustment(input.tenantId, input.runId, {
      employeeUid:  input.employeeUid,
      amount:       input.amount,
      reason:       input.reason,
      addedBy:      input.addedBy,
      carryForward: input.carryForward,
    });

    await this.c9.append({
      tenantId:    input.tenantId,
      eventType:   'PAYROLL_ADJUSTMENT_ADDED',
      actorUid:    input.addedBy,
      actorRole:   'entity_admin',
      subjectUid:  input.runId,
      subjectType: 'payroll_run',
      payload: {
        adjustmentId: adj.adjustmentId,
        runId:        input.runId,
        employeeUid:  input.employeeUid,
        amount:       input.amount,
        reason:       input.reason,
        carryForward: input.carryForward,
      },
    });

    return adj;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // QUERIES
  // ══════════════════════════════════════════════════════════════════════════════

  listRuns(tenantId: string)                       { return this.payrollRepo.listRuns(tenantId); }
  getRun(tenantId: string, runId: string)          { return this.payrollRepo.findRunById(tenantId, runId); }
  listItems(tenantId: string, runId: string)       { return this.payrollRepo.listItems(tenantId, runId); }
  listAdjustments(tenantId: string, runId: string) { return this.payrollRepo.listAdjustments(tenantId, runId); }
  listInvoices(uid: string)                        { return this.payrollRepo.listInvoices(uid); }

  // ══════════════════════════════════════════════════════════════════════════════
  // PRIVATE HELPERS
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * Core Saudi Labor Law computation for a single employee.
   *
   * Formula (Art. 87 + Royal Decree 11438):
   *   dailySalary      = baseSalary / 30
   *   hourlyRate       = dailySalary / 8
   *   absenceDeduction = absenceDays        * dailySalary
   *   lateDeduction    = floor(lateMin/60)  * (dailySalary / 2)
   *   leaveDeduction   = unpaidLeaveDays    * dailySalary
   *   overtimeAmount   = overtimeHours      * hourlyRate * 1.5
   *   netSalary        = baseSalary + overtimeAmount
   *                      - absenceDeduction - lateDeduction - leaveDeduction
   *                      + carryForwardAdjustments
   */
  private async computePayrollItem(
    tenantId:     string,
    emp:          EmployeePayrollData,
    monthStart:   string,
    monthEnd:     string,
    carries:      PayrollAdjustment[],
  ): Promise<PayrollItem> {
    // ── Attendance stats ─────────────────────────────────────────────────────
    const stats = await this.fetchAttendanceStats(tenantId, emp.employeeUid, monthStart, monthEnd);

    // ── Leave deductions ─────────────────────────────────────────────────────
    const dailySalary  = emp.baseSalary / 30;
    const leaveData    = await this.leavesService.calculateLeaveDeductions(
      tenantId, emp.employeeUid, monthStart, monthEnd, dailySalary,
    );

    // ── Apply formula ────────────────────────────────────────────────────────
    const hourlyRate       = dailySalary / 8;
    const absenceDeduction = stats.absenceDays    * dailySalary;
    const lateDeduction    = Math.floor(stats.lateMinutes / 60) * (dailySalary / 2);
    const leaveDeduction   = leaveData.deductionAmount;
    const overtimeAmount   = stats.overtimeHours  * hourlyRate * 1.5;
    const grossSalary      = emp.baseSalary + overtimeAmount;
    const totalDeductions  = absenceDeduction + lateDeduction + leaveDeduction;

    // ── Carry-forward adjustments ────────────────────────────────────────────
    const carryAmount = carries.reduce((sum, c) => sum + c.amount, 0);

    const netSalary = Math.max(
      0,
      Math.round((grossSalary - totalDeductions + carryAmount) * 100) / 100,
    );

    const breakdown: PayrollItemBreakdown = {
      baseSalary:      emp.baseSalary,
      dailySalary:     Math.round(dailySalary * 100) / 100,
      hourlyRate:      Math.round(hourlyRate * 100) / 100,
      absenceDays:     stats.absenceDays,
      absenceDeduction: Math.round(absenceDeduction * 100) / 100,
      lateMinutes:     stats.lateMinutes,
      lateDeduction:   Math.round(lateDeduction * 100) / 100,
      unpaidLeaveDays: leaveData.unpaidDays,
      leaveDeduction:  Math.round(leaveDeduction * 100) / 100,
      overtimeHours:   stats.overtimeHours,
      overtimeAmount:  Math.round(overtimeAmount * 100) / 100,
      grossSalary:     Math.round(grossSalary * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      netSalary,
    };

    return {
      employeeUid:  emp.employeeUid,
      employeeName: emp.employeeName,
      nationalId:   emp.nationalId,
      branchId:     emp.branchId,
      position:     emp.position,
      breakdown,
      generatedAt:  { toDate: () => new Date() } as FirebaseFirestore.Timestamp,
    };
  }

  /** Fetch all active employees in the entity */
  private async fetchActiveEmployees(tenantId: string): Promise<EmployeePayrollData[]> {
    const snap = await this.db
      .collection('entities').doc(tenantId)
      .collection('employees')
      .where('status', '==', 'active')
      .get();

    return snap.docs.map(d => {
      const data = d.data();
      return {
        employeeUid:  data['uid']          as string,
        employeeName: data['name']         as string,
        nationalId:   data['nationalId']   as string,
        branchId:     data['branchId']     as string,
        position:     data['position']     as string,
        baseSalary:   (data['baseSalary']  as number) ?? 0,
        status:       data['status']       as string,
      };
    });
  }

  /**
   * Aggregate attendance stats for a given employee within a month.
   * Reads from /entities/{tenantId}/attendance where status='accepted'.
   *
   * absenceDays  = working days in month - days with at least one accepted check-in
   * lateMinutes  = sum of lateMinutes on accepted records
   * overtimeHours = sum of overtimeMinutes / 60 on accepted records
   */
  private async fetchAttendanceStats(
    tenantId:    string,
    employeeUid: string,
    monthStart:  string,
    monthEnd:    string,
  ): Promise<AttendanceMonthStats> {
    const snap = await this.db
      .collection('entities').doc(tenantId)
      .collection('attendance')
      .where('employeeUid', '==', employeeUid)
      .where('status', '==', 'accepted')
      .where('eventType', '==', 'check_in')
      .get();

    // Filter by month client-side (Firestore inequality on 2 fields requires composite index)
    const records = snap.docs
      .map(d => d.data())
      .filter(d => {
        const dateStr = new Date(d['serverTimestampMs'] as number).toISOString().slice(0, 10);
        return dateStr >= monthStart && dateStr <= monthEnd;
      });

    // Count unique working days present
    const presentDays = new Set(
      records.map(d =>
        new Date(d['serverTimestampMs'] as number).toISOString().slice(0, 10),
      ),
    ).size;

    const workingDays  = this.countWorkingDays(monthStart, monthEnd);
    const absenceDays  = Math.max(0, workingDays - presentDays);
    const lateMinutes  = records.reduce((s, d) => s + ((d['lateMinutes']   as number) ?? 0), 0);
    const overtimeHours = records.reduce((s, d) => s + ((d['overtimeMinutes'] as number) ?? 0), 0) / 60;

    return { absenceDays, lateMinutes, overtimeHours: Math.round(overtimeHours * 100) / 100 };
  }

  /** Count Mon–Fri working days in [start, end] inclusive */
  private countWorkingDays(startDate: string, endDate: string): number {
    const start  = new Date(startDate);
    const end    = new Date(endDate);
    let count    = 0;
    const cursor = new Date(start);
    while (cursor <= end) {
      const day = cursor.getDay(); // 0=Sun, 5=Fri, 6=Sat
      // Saudi weekend is Fri-Sat
      if (day !== 5 && day !== 6) count++;
      cursor.setDate(cursor.getDate() + 1);
    }
    return count;
  }

  private monthRange(month: string): { monthStart: string; monthEnd: string } {
    const [y, m]   = month.split('-').map(Number);
    const monthStart = `${month}-01`;
    const lastDay    = new Date(y, m, 0).getDate(); // last day of month
    const monthEnd   = `${month}-${String(lastDay).padStart(2, '0')}`;
    return { monthStart, monthEnd };
  }

  private previousMonth(month: string): string {
    const [y, m] = month.split('-').map(Number);
    const d      = new Date(y, m - 2, 1); // subtract one month
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }

  private buildCarryMap(adjustments: PayrollAdjustment[]): Record<string, PayrollAdjustment[]> {
    return adjustments.reduce<Record<string, PayrollAdjustment[]>>((map, adj) => {
      if (!map[adj.employeeUid]) map[adj.employeeUid] = [];
      map[adj.employeeUid].push(adj);
      return map;
    }, {});
  }
}
