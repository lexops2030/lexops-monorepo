/**
 * LexOps — Lifecycle Service
 *
 * Manages establishment and employee lifecycle transitions.
 * Implements:
 *   - onContractCreated()   → sets phase to 'contract', initialises lifecycle doc
 *   - onProbationStart()    → sets 90-day timer, schedules day-80 alert
 *   - checkProbationAlerts()→ called by a cron / Cloud Scheduler to fire day-80 alerts
 *   - onLicenseExpirySoon() → alerts at 30-day & 7-day thresholds
 */

import { Injectable, Logger } from '@nestjs/common';
import {
  LifecycleRepository,
  EmployeeLifecycle,
  EstablishmentLifecycle,
  LifecycleAlert,
} from './lifecycle.repository';
import { C9LedgerRepository } from '../../database/c9-ledger.repository';
import { randomUUID } from 'crypto';

// ── Config ────────────────────────────────────────────────────────────────────

const PROBATION_DAYS       = 90;
const PROBATION_ALERT_DAY  = 80;   // fire alert when ≤ 10 days remain
const LICENSE_ALERT_DAYS   = [30, 7];

@Injectable()
export class LifecycleService {
  private readonly logger = new Logger(LifecycleService.name);

  constructor(
    private readonly lifecycleRepo: LifecycleRepository,
    private readonly c9: C9LedgerRepository,
  ) {}

  // ══════════════════════════════════════════════════════════════════════════════
  // ESTABLISHMENT LIFECYCLE
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * Initialise or update an establishment's lifecycle record.
   * Transitions phase → 'contract' and sets expiry dates.
   */
  async onContractCreated(params: {
    tenantId:             string;
    licenseExpiry:        string;
    commercialRegExpiry?: string;
    vatExpiry?:           string;
    actorUid:             string;
  }): Promise<EstablishmentLifecycle | null> {
    await this.lifecycleRepo.upsertEstablishment(params.tenantId, {
      phase:               'contract',
      licenseExpiry:       params.licenseExpiry,
      commercialRegExpiry: params.commercialRegExpiry,
      vatExpiry:           params.vatExpiry,
    });

    await this.c9.append({
      tenantId:    params.tenantId,
      eventType:   'LIFECYCLE_CONTRACT_CREATED',
      actorUid:    params.actorUid,
      actorRole:   'sovereign',
      subjectUid:  params.tenantId,
      subjectType: 'establishment',
      payload: {
        licenseExpiry:       params.licenseExpiry,
        commercialRegExpiry: params.commercialRegExpiry,
        vatExpiry:           params.vatExpiry,
        newPhase:            'contract',
      },
    });

    this.logger.log(`[Lifecycle] Establishment ${params.tenantId} → phase:contract`);
    return this.lifecycleRepo.getEstablishment(params.tenantId);
  }

  /**
   * Transition an establishment to 'operational' phase.
   */
  async onEstablishmentActivated(tenantId: string, actorUid: string): Promise<void> {
    await this.lifecycleRepo.upsertEstablishment(tenantId, { phase: 'operational' });
    await this.c9.append({
      tenantId,
      eventType:   'LIFECYCLE_ESTABLISHMENT_ACTIVATED',
      actorUid,
      actorRole:   'sovereign',
      subjectUid:  tenantId,
      subjectType: 'establishment',
      payload: { newPhase: 'operational' },
    });
  }

  /**
   * Check all establishment license/registration expiry dates and
   * push bilingual alerts at 30-day and 7-day thresholds.
   * Designed to be called by a Cloud Scheduler cron (daily).
   */
  async checkExpiryAlerts(tenantId: string): Promise<LifecycleAlert[]> {
    const lifecycle = await this.lifecycleRepo.getEstablishment(tenantId);
    if (!lifecycle) return [];

    const today     = new Date();
    const firedAlerts: LifecycleAlert[] = [];

    const expiryFields: { key: keyof typeof lifecycle; label: string }[] = [
      { key: 'licenseExpiry',        label: 'الترخيص التجاري' },
      { key: 'commercialRegExpiry',  label: 'السجل التجاري'   },
      { key: 'vatExpiry',            label: 'شهادة ضريبة القيمة المضافة' },
    ];

    for (const { key, label } of expiryFields) {
      const dateStr = lifecycle[key] as string | undefined;
      if (!dateStr) continue;

      const expiryDate  = new Date(dateStr);
      const daysRemaining = Math.ceil(
        (expiryDate.getTime() - today.getTime()) / 86_400_000,
      );

      if (LICENSE_ALERT_DAYS.includes(daysRemaining)) {
        const alert: LifecycleAlert = {
          alertType:    `${key}_expiry_${daysRemaining}d`,
          message:
            `تنبيه: ${label} سينتهي خلال ${daysRemaining} يوماً ` +
            `(${dateStr}). يُرجى التجديد فوراً لتجنب المخالفات.\n` +
            `Alert: ${label} expires in ${daysRemaining} days (${dateStr}). Renew immediately.`,
          triggeredAt:  { toDate: () => new Date() } as FirebaseFirestore.Timestamp,
          isRead:       false,
          targetDate:   dateStr,
          daysRemaining,
        };

        await this.lifecycleRepo.pushEstablishmentAlert(tenantId, alert);
        firedAlerts.push(alert);

        this.logger.warn(
          `[Lifecycle] ${tenantId} — ${label} expires in ${daysRemaining} days`,
        );
      }
    }

    return firedAlerts;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // EMPLOYEE LIFECYCLE
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * onContractCreated for an employee.
   * Sets phase = 'contract', persists contractStartDate.
   */
  async onEmployeeContractCreated(params: {
    tenantId:          string;
    employeeId:        string;
    contractStartDate: string;
    contractEndDate?:  string;
    actorUid:          string;
  }): Promise<void> {
    await this.lifecycleRepo.upsertEmployee(params.tenantId, params.employeeId, {
      phase:             'contract',
      contractStartDate: params.contractStartDate,
      contractEndDate:   params.contractEndDate,
    });

    await this.c9.append({
      tenantId:    params.tenantId,
      eventType:   'LIFECYCLE_EMPLOYEE_CONTRACT_CREATED',
      actorUid:    params.actorUid,
      actorRole:   'entity_admin',
      subjectUid:  params.employeeId,
      subjectType: 'employee_lifecycle',
      payload: {
        contractStartDate: params.contractStartDate,
        contractEndDate:   params.contractEndDate,
        newPhase:          'contract',
      },
    });
  }

  /**
   * onProbationStart — transitions employee to 'probation' phase.
   * Calculates probationEndDate = startDate + 90 days.
   * Stores the end date; the day-80 alert fires via checkProbationAlerts().
   */
  async onProbationStart(params: {
    tenantId:           string;
    employeeId:         string;
    probationStartDate: string;
    actorUid:           string;
  }): Promise<{ probationEndDate: string }> {
    const start = new Date(params.probationStartDate);
    const end   = new Date(start);
    end.setDate(end.getDate() + PROBATION_DAYS);
    const probationEndDate = end.toISOString().slice(0, 10);

    await this.lifecycleRepo.upsertEmployee(params.tenantId, params.employeeId, {
      phase:              'probation',
      probationStartDate: params.probationStartDate,
      probationEndDate,
      probationAlertSent: false,
    });

    await this.c9.append({
      tenantId:    params.tenantId,
      eventType:   'LIFECYCLE_PROBATION_STARTED',
      actorUid:    params.actorUid,
      actorRole:   'entity_admin',
      subjectUid:  params.employeeId,
      subjectType: 'employee_lifecycle',
      payload: {
        probationStartDate: params.probationStartDate,
        probationEndDate,
        alertDay:           PROBATION_ALERT_DAY,
        newPhase:           'probation',
      },
    });

    this.logger.log(
      `[Lifecycle] Employee ${params.employeeId} probation: ` +
      `${params.probationStartDate} → ${probationEndDate}`,
    );

    return { probationEndDate };
  }

  /**
   * checkProbationAlerts — scans all employees with probation ending
   * in the next (PROBATION_DAYS - PROBATION_ALERT_DAY) = 10 days.
   * Pushes a day-80 alert and marks alertSent = true.
   * Call from Cloud Scheduler daily at midnight.
   */
  async checkProbationAlerts(): Promise<{ fired: number; employees: string[] }> {
    const today     = new Date();
    const alertDate = new Date(today);
    alertDate.setDate(alertDate.getDate() + (PROBATION_DAYS - PROBATION_ALERT_DAY));

    const dateStr       = alertDate.toISOString().slice(0, 10);
    const dueEmployees  = await this.lifecycleRepo
      .findEmployeesWithProbationEndingBetween(dateStr, dateStr);

    const fired: string[] = [];

    for (const emp of dueEmployees) {
      const daysRemaining = PROBATION_DAYS - PROBATION_ALERT_DAY;

      const alert: LifecycleAlert = {
        alertType:    'probation_end_warning',
        message:
          `تنبيه: تنتهي فترة التجربة للموظف ${emp.employeeId} خلال ${daysRemaining} أيام ` +
          `(${emp.probationEndDate}). يُرجى اتخاذ قرار التثبيت أو الإنهاء.\n` +
          `Alert: Probation for employee ${emp.employeeId} ends in ${daysRemaining} days ` +
          `(${emp.probationEndDate}). Confirm employment or initiate termination.`,
        triggeredAt:  { toDate: () => new Date() } as FirebaseFirestore.Timestamp,
        isRead:       false,
        targetDate:   emp.probationEndDate,
        daysRemaining,
      };

      await this.lifecycleRepo.pushEmployeeAlert(emp.tenantId, emp.employeeId, alert);
      await this.lifecycleRepo.markProbationAlertSent(emp.tenantId, emp.employeeId);

      await this.c9.append({
        tenantId:    emp.tenantId,
        eventType:   'LIFECYCLE_PROBATION_ALERT_FIRED',
        actorUid:    'system',
        actorRole:   'sovereign',
        subjectUid:  emp.employeeId,
        subjectType: 'employee_lifecycle',
        payload: { probationEndDate: emp.probationEndDate, daysRemaining },
      });

      fired.push(emp.employeeId);
      this.logger.warn(
        `[Lifecycle] Day-${PROBATION_ALERT_DAY} alert fired: ` +
        `tenant=${emp.tenantId} employee=${emp.employeeId}`,
      );
    }

    return { fired: fired.length, employees: fired };
  }

  // ── Getters ──────────────────────────────────────────────────────────────────

  getEstablishmentLifecycle(tenantId: string) {
    return this.lifecycleRepo.getEstablishment(tenantId);
  }

  getEmployeeLifecycle(tenantId: string, employeeId: string) {
    return this.lifecycleRepo.getEmployee(tenantId, employeeId);
  }

  getKpiHistory(tenantId: string) {
    return this.lifecycleRepo.getKpiHistory(tenantId);
  }
}
