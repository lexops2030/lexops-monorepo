import { Module } from '@nestjs/common';
import { LegalService } from './legal.service';
import { LegalController } from './legal.controller';
import { ObjectionsModule } from '../objections/objections.module';
import { ComplianceModule } from '../compliance/compliance.module';
import { DatabaseModule } from '../../database/database.module';

@Module({
  imports: [
    DatabaseModule,      // C9LedgerRepository
    ObjectionsModule,    // ObjectionsRepository (findById, saveLexiDraft, setUnderReview)
    ComplianceModule,    // ViolationsRepository (findById, findRecentByEmployee)
  ],
  providers:   [LegalService],
  controllers: [LegalController],
  exports:     [LegalService],
})
export class LegalModule {}
