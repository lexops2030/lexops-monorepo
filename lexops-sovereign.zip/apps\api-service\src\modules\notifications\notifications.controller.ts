/**
 * LexOps — Notifications Controller  (Sprint 8)
 *
 * REST Endpoints:
 *
 * ENTITY (TenantScopeGuard enforced):
 *   GET    /v1/entities/:tenantId/notifications           → tenant notification log (admin)
 *   GET    /v1/entities/:tenantId/notifications/my        → caller's own notifications
 *   POST   /v1/entities/:tenantId/notifications/dispatch  → manual dispatch (sovereign/admin)
 *
 * INDEPENDENT WORKER (routeToVault enforced):
 *   GET    /v1/independent/notifications                  → personal vault notification log
 *   POST   /v1/independent/notifications/legal-alert      → fire legal alert (test/admin)
 *   POST   /v1/independent/notifications/lexi-tip         → push LEXI tip
 */

import {
  Controller, Get, Post,
  Param, Body, Request, Version, UseGuards,
  HttpCode, HttpStatus, ForbiddenException,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import {
  IsString, IsNotEmpty, IsOptional, IsIn,
  IsEmail, IsNumber,
} from 'class-validator';
import { NotificationsService } from './notifications.service';
import { IndependentNotificationsService } from './independent-notifications.service';
import { NotifEventType } from './notifications.repository';
import {
  FirebaseAuthGuard, TenantScopeGuard, Roles, LexOpsClaims,
} from '../auth/firebase.guard';
import { Request as ExpressRequest } from 'express';

// ── DTOs ─────────────────────────────────────────────────────────────────────

class ManualDispatchDto {
  @IsString() @IsNotEmpty()
  recipientUid: string;

  @IsString() @IsOptional()
  recipientEmail?: string;

  @IsString() @IsOptional()
  recipientPhone?: string;

  @IsString() @IsOptional()
  fcmToken?: string;

  @IsString() @IsNotEmpty()
  eventType: NotifEventType;

  @IsString() @IsNotEmpty()
  titleTemplate: string;

  @IsString() @IsNotEmpty()
  bodyTemplate: string;
}

class LegalAlertDto {
  @IsString() @IsOptional()
  phone?: string;

  @IsString() @IsOptional()
  fcmToken?: string;

  @IsIn(['violation_added', 'objection_accepted', 'objection_rejected', 'trust_score_changed'])
  alertType: 'violation_added' | 'objection_accepted' | 'objection_rejected' | 'trust_score_changed';
}

class LexiTipDto {
  @IsString() @IsNotEmpty()
  fcmToken: string;

  @IsString() @IsNotEmpty()
  tip: string;

  @IsNumber()
  trustScore: number;
}

// ── Entity Notifications Controller ───────────────────────────────────────────

@ApiTags('Notifications — منظومة الإشعارات')
@ApiBearerAuth('Firebase-JWT')
@Controller('entities/:tenantId/notifications')
@UseGuards(FirebaseAuthGuard, TenantScopeGuard)
export class NotificationsController {
  constructor(private readonly notifService: NotificationsService) {}

  @Get()
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'سجل الإشعارات الكامل للمنشأة (Admin Board)' })
  getTenantLog(@Param('tenantId') tenantId: string) {
    return this.notifService.getTenantNotificationLog(tenantId);
  }

  @Get('my')
  @Version('1')
  @Roles('employee', 'entity_admin', 'sovereign')
  @ApiOperation({ summary: 'إشعاراتي الشخصية' })
  getMyNotifications(
    @Param('tenantId') tenantId: string,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.notifService.getMyNotifications(tenantId, req.user.uid);
  }

  @Post('dispatch')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'إرسال إشعار يدوي (Admin/Sovereign) — مختوم في C9',
    description: 'يُستخدم لاختبار مسارات الإشعار أو إرسال تنبيهات طارئة.',
  })
  dispatch(
    @Param('tenantId') tenantId: string,
    @Body() dto: ManualDispatchDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.notifService.dispatch({
      tenantId,
      recipientUid:   dto.recipientUid,
      recipientEmail: dto.recipientEmail,
      recipientPhone: dto.recipientPhone,
      fcmToken:       dto.fcmToken,
      eventType:      dto.eventType,
      titleTemplate:  dto.titleTemplate,
      bodyTemplate:   dto.bodyTemplate,
      fullPayload:    { manualDispatch: true, dispatchedBy: req.user.uid },
      actorUid:       req.user.uid,
    });
  }
}

// ── Independent Worker Notifications Controller ───────────────────────────────

@ApiTags('Notifications — العامل المستقل')
@ApiBearerAuth('Firebase-JWT')
@Controller('independent/notifications')
@UseGuards(FirebaseAuthGuard)
export class IndependentNotificationsController {
  constructor(
    private readonly indNotifService: IndependentNotificationsService,
  ) {}

  @Get()
  @Version('1')
  @Roles('freelancer')
  @ApiOperation({ summary: 'سجل إشعاراتي من الخزانة الشخصية (IND_)' })
  getMyNotifications(
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    if (!req.user.routeToVault) {
      throw new ForbiddenException('مخصص للعمال المستقلين فقط (IND_).');
    }
    return this.indNotifService.getMyNotifications(req.user.uid);
  }

  @Post('legal-alert')
  @Version('1')
  @Roles('freelancer')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'إرسال تنبيه قانوني حرج (SMS + Push) للعامل المستقل' })
  sendLegalAlert(
    @Body() dto: LegalAlertDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    if (!req.user.routeToVault) {
      throw new ForbiddenException('مخصص للعمال المستقلين فقط.');
    }
    return this.indNotifService.sendLegalAlert({
      uid:       req.user.uid,
      phone:     dto.phone,
      fcmToken:  dto.fcmToken,
      alertType: dto.alertType,
    });
  }

  @Post('lexi-tip')
  @Version('1')
  @Roles('freelancer')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'إرسال نصيحة LEXI اليومية التفاعلية (Push فقط)' })
  sendLexiTip(
    @Body() dto: LexiTipDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    if (!req.user.routeToVault) {
      throw new ForbiddenException('مخصص للعمال المستقلين فقط.');
    }
    return this.indNotifService.sendLexiTip({
      uid:        req.user.uid,
      fcmToken:   dto.fcmToken,
      tip:        dto.tip,
      trustScore: dto.trustScore,
    });
  }
}
