export default function FreelancerPortal() {
  return <div className="card-sovereign"><p className="text-neutral-500">بوابة المستقل — Sprint 4</p></div>;
}
