export default function LexiPage() {
  return <div className="card-sovereign"><p className="text-neutral-500">محرك LEXI القانوني — Sprint 3</p></div>;
}
