# ─────────────────────────────────────────────────────────
#  خطوات نشر LexOps على Vercel — دليل سريع
# ─────────────────────────────────────────────────────────

## الطريقة 1: واجهة Vercel (الأسهل — بدون terminal)

1. افتح https://vercel.com وسجّل الدخول
2. اضغط "Add New Project" ثم اربط مستودع GitHub الخاص بك
3. في إعدادات المشروع:
   - Root Directory: apps/web-dashboard
   - Framework Preset: Vite (يُكتشف تلقائياً)
   - Build Command: npm run build
   - Output Directory: dist
4. أضف المتغيرات التالية في قسم "Environment Variables":
   VITE_API_URL               = https://your-cloud-run-url.run.app
   VITE_FIREBASE_API_KEY      = (من Firebase Console)
   VITE_FIREBASE_AUTH_DOMAIN  = your-project.firebaseapp.com
   VITE_FIREBASE_PROJECT_ID   = your-project-id
   VITE_FIREBASE_APP_ID       = (من Firebase Console)
5. اضغط Deploy — ستحصل على رابط خلال 2-3 دقائق

---

## الطريقة 2: Vercel CLI (من terminal)

# تثبيت Vercel CLI
npm install -g vercel

# الانتقال لمجلد الـ Frontend
cd apps/web-dashboard

# تسجيل الدخول
vercel login

# نشر مباشر (Preview)
vercel

# نشر للـ Production
vercel --prod

---

## الطريقة 3: GitHub Actions (CI/CD تلقائي)

انظر ملف: .github/workflows/deploy-frontend.yml
(سيتم إنشاؤه عند الطلب)

---

## متغيرات Vercel السرية (Environment Secrets)

أضف هذه القيم في: Vercel Dashboard > Project > Settings > Environment Variables

| المتغير                    | المصدر                              |
|----------------------------|--------------------------------------|
| VITE_API_URL               | Google Cloud Run — Service URL       |
| VITE_FIREBASE_API_KEY      | Firebase Console > Project Settings  |
| VITE_FIREBASE_AUTH_DOMAIN  | Firebase Console > Project Settings  |
| VITE_FIREBASE_PROJECT_ID   | Firebase Console > Project Settings  |
| VITE_FIREBASE_APP_ID       | Firebase Console > Project Settings  |

⚠ لا تضع هذه القيم في ملفات الكود مطلقاً
