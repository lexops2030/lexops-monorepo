import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  VertexAI,
  GenerativeModel,
  HarmCategory,
  HarmBlockThreshold,
} from '@google-cloud/vertexai';
import type { LexOpsClaims, LexOpsRole } from '../auth/firebase.guard';

// ── LEXI Decision Output Shape ────────────────────────────────────────────────

export interface LexiDecision {
  verdict: 'justified' | 'unjustified' | 'partial' | 'escalate';
  legalBasis: string[];
  penaltyRecommendation: string | null;
  objectionDraft: string | null;
  confidence: number;
  summary: { ar: string; en: string };
  metadata: {
    model: string;
    processingMs: number;
    tenantId: string;
    caseRef: string;
    lexiMode: LexiMode;
  };
}

// ── LEXI Persona Modes ────────────────────────────────────────────────────────

export type LexiMode =
  | 'system_guardian'     // Level 0  — Sovereign: global insights, big-data analytics
  | 'operational_advisor' // Level 1  — Entity Admin: entity-specific compliance
  | 'support_assistant'   // Level 2  — Linked Employee: rights & attendance guidance
  | 'personal_advocate';  // Level 2-I — Independent Worker: personal vault protection

/**
 * Resolve which LEXI mode should be activated based on JWT claims.
 *
 * Matrix:
 *  sovereign      → system_guardian
 *  entity_admin   → operational_advisor
 *  employee       → support_assistant
 *  freelancer     → personal_advocate  (IND_ tenants — data isolation enforced)
 */
export function resolveLexiMode(claims: Pick<LexOpsClaims, 'role' | 'routeToVault'>): LexiMode {
  if (claims.role === 'sovereign')     return 'system_guardian';
  if (claims.role === 'entity_admin')  return 'operational_advisor';
  if (claims.role === 'freelancer' || claims.routeToVault) return 'personal_advocate';
  return 'support_assistant';
}

// ── System Prompts per Mode ───────────────────────────────────────────────────

const SYSTEM_PROMPTS: Record<LexiMode, string> = {

  system_guardian: `
أنت LEXI في وضع "الحارس السيادي" — الذكاء الاصطناعي القانوني الأعلى لمنصة LexOps.
مهمتك: تحليل البيانات الكلية عبر جميع المنشآت وتقديم رؤى استراتيجية شاملة للمستخدم السيادي.
صلاحياتك: الوصول الكامل لجميع البيانات، الكشف عن أنماط الامتثال، تحليل مخاطر المنظومة.
أسلوبك: تنفيذي، تحليلي، ثنائي اللغة (عربي/إنجليزي).
أخرج دائماً JSON نقياً يطابق المخطط المطلوب.
  `.trim(),

  operational_advisor: `
أنت LEXI في وضع "المستشار التشغيلي" — محرك الامتثال القانوني لمدير المنشأة.
مهمتك: تحليل الحالات العمالية لمنشأة بعينها واقتراح قرارات دفاعية مستندة لنظام العمل السعودي.
صلاحياتك: بيانات منشأتك فقط — لا تتجاوز حدود الـ tenantId.
تخصصاتك: صياغة اعتراضات قانونية، تقييم مخاطر الامتثال، توصيات العقوبات التدريجية.
استند دائماً لنظام العمل السعودي والمرسوم الملكي رقم 11438.
أخرج JSON نقياً يطابق المخطط المطلوب.
  `.trim(),

  support_assistant: `
أنت LEXI في وضع "المساعد الداعم" — مرشد حقوق الموظف المرتبط بمنشأة.
مهمتك: مساعدة الموظف على فهم حقوقه العمالية، شرح سجلات حضوره وإجازاته، وتوجيهه للإجراءات الصحيحة.
قيودك: لا تُصدر قرارات إدارية، لا تعدّل سجلات، لا تكشف بيانات زملائه.
أسلوبك: واضح، مُيسَّر، داعم، باللغة العربية بالدرجة الأولى.
أخرج JSON نقياً يطابق المخطط المطلوب.
  `.trim(),

  personal_advocate: `
أنت LEXI في وضع "المحامي الشخصي" — حامي حقوق العامل المستقل في LexOps.
مهمتك: تعظيم القيمة القانونية للعامل المستقل، حماية خزانته الشخصية، وصياغة اعتراضاته.
قيود صارمة:
  1. لا تشارك أي بيانات مع المنشآت ما لم يكن dataConsentGiven = true صراحةً.
  2. كل تحليل يخدم مصلحة العامل المستقل فقط، وليس المنشأة.
  3. اذكر دائماً trust_score الحالي وكيف يؤثر على موقف المستخدم القانوني.
أسلوبك: مناصري، مُحفِّز، عملي، ثنائي اللغة.
أخرج JSON نقياً يطابق المخطط المطلوب.
  `.trim(),
};

// ── LEXI AI Service ───────────────────────────────────────────────────────────

@Injectable()
export class LexiService {
  private readonly logger = new Logger(LexiService.name);
  private readonly vertexAI: VertexAI;
  private readonly proModel: GenerativeModel;
  private readonly flashModel: GenerativeModel;

  constructor(private readonly config: ConfigService) {
    const projectId = this.config.getOrThrow<string>('GCP_PROJECT_ID');
    const location  = this.config.get<string>('GCP_REGION', 'me-central1');

    this.vertexAI = new VertexAI({ project: projectId, location });

    const safetySettings = [
      { category: HarmCategory.HARM_CATEGORY_HARASSMENT,  threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
      { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
    ];

    this.proModel = this.vertexAI.getGenerativeModel({
      model: 'gemini-1.5-pro-002',
      safetySettings,
      generationConfig: {
        temperature: 0.1,
        topP: 0.95,
        maxOutputTokens: 2048,
        responseMimeType: 'application/json',
      },
    });

    this.flashModel = this.vertexAI.getGenerativeModel({
      model: 'gemini-1.5-flash-002',
      safetySettings,
      generationConfig: {
        temperature: 0.1,
        topP: 0.95,
        maxOutputTokens: 1024,
        responseMimeType: 'application/json',
      },
    });
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // LEXI CONTEXT SWITCHING — Core Analysis
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * Analyze a violation/excuse using the persona-appropriate LEXI mode.
   *
   * The caller passes `callerClaims` from the JWT; mode is resolved automatically.
   * This is the single entry point — no more hardcoded system prompts.
   */
  async analyzeViolation(params: {
    caseType:       'absence' | 'lateness' | 'misconduct' | 'termination' | 'grievance';
    employeeExcuse: string;
    evidenceSummary?:  string;
    priorViolations?:  number;
    tenantId:       string;
    caseRef:        string;
    useFlash?:      boolean;
    callerClaims:   Pick<LexOpsClaims, 'role' | 'routeToVault' | 'trust_score'>;
  }): Promise<LexiDecision> {
    const start     = Date.now();
    const lexiMode  = resolveLexiMode(params.callerClaims);
    const model     = params.useFlash ? this.flashModel : this.proModel;
    const modelName = params.useFlash ? 'gemini-1.5-flash-002' : 'gemini-1.5-pro-002';

    const systemPrompt = SYSTEM_PROMPTS[lexiMode];

    // Build context-aware user prompt
    let userPrompt = `
نوع المخالفة: ${params.caseType}
عذر الموظف: ${params.employeeExcuse}
${params.evidenceSummary   ? `ملخص الأدلة: ${params.evidenceSummary}` : ''}
${params.priorViolations !== undefined ? `المخالفات السابقة: ${params.priorViolations}` : ''}
رقم المنشأة: ${params.tenantId}
رقم الحالة: ${params.caseRef}
    `.trim();

    // Augment prompt for personal_advocate with trust_score context
    if (lexiMode === 'personal_advocate' && params.callerClaims.trust_score !== null) {
      userPrompt += `\nدرجة الثقة الحالية للعامل: ${params.callerClaims.trust_score}/10`;
      userPrompt += `\nتذكر: لا تشارك أي بيانات مع الجهة المشغِّلة بدون موافقة صريحة.`;
    }

    // Augment prompt for system_guardian with cross-entity analytics hint
    if (lexiMode === 'system_guardian') {
      userPrompt += `\n[وضع سيادي] بإمكانك الإشارة لأنماط ممتدة عبر المنشآت إن وُجدت.`;
    }

    this.logger.log(`[LEXI] mode=${lexiMode} caseRef=${params.caseRef}`);

    try {
      const result = await model.generateContent({
        systemInstruction: { role: 'system', parts: [{ text: systemPrompt }] },
        contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
      });

      const rawText  = result.response.candidates?.[0]?.content?.parts?.[0]?.text ?? '{}';
      const parsed   = JSON.parse(rawText) as Omit<LexiDecision, 'metadata'>;

      return {
        ...parsed,
        metadata: {
          model: modelName,
          processingMs: Date.now() - start,
          tenantId: params.tenantId,
          caseRef: params.caseRef,
          lexiMode,
        },
      };
    } catch (err) {
      this.logger.error(`LEXI analysis failed for case ${params.caseRef}`, err);
      throw err;
    }
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // LIFECYCLE ALERTS (Flash — mode-aware)
  // ══════════════════════════════════════════════════════════════════════════════

  async generateLifecycleAlert(params: {
    alertType:     'license_expiry' | 'probation_end' | 'contract_renewal' | 'iqama_expiry';
    daysRemaining: number;
    entityName:    string;
    tenantId:      string;
    callerClaims?: Pick<LexOpsClaims, 'role' | 'routeToVault'>;
  }): Promise<{ ar: string; en: string; lexiMode: LexiMode }> {
    const lexiMode = params.callerClaims
      ? resolveLexiMode(params.callerClaims)
      : 'operational_advisor';

    const systemPrompt = SYSTEM_PROMPTS[lexiMode];

    const prompt = `
أنت LEXI. اكتب تنبيهاً تنفيذياً ثنائي اللغة (عربي/إنجليزي) حول:
نوع التنبيه: ${params.alertType}
الأيام المتبقية: ${params.daysRemaining}
اسم المنشأة: ${params.entityName}

أخرج JSON فقط: { "ar": "...", "en": "..." }
    `.trim();

    const result = await this.flashModel.generateContent({
      systemInstruction: { role: 'system', parts: [{ text: systemPrompt }] },
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
    });

    const raw    = result.response.candidates?.[0]?.content?.parts?.[0]?.text ?? '{"ar":"","en":""}';
    const parsed = JSON.parse(raw) as { ar: string; en: string };

    return { ...parsed, lexiMode };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // SOVEREIGN MODE — Global Analytics Insight
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * Generate a cross-entity compliance insight for the Sovereign dashboard.
   * Only callable by sovereign role (enforced at controller level).
   */
  async generateGlobalInsight(params: {
    topic:       'compliance_summary' | 'risk_hotspots' | 'attendance_trends' | 'leave_patterns';
    dataContext: string;  // JSON-serialized aggregate stats from the caller
  }): Promise<{ ar: string; en: string; recommendations: string[] }> {
    const prompt = `
[وضع الحارس السيادي]
الموضوع: ${params.topic}
البيانات الكلية:
${params.dataContext}

أخرج JSON: { "ar": "...", "en": "...", "recommendations": ["..."] }
    `.trim();

    const result = await this.proModel.generateContent({
      systemInstruction: { role: 'system', parts: [{ text: SYSTEM_PROMPTS.system_guardian }] },
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
    });

    const raw = result.response.candidates?.[0]?.content?.parts?.[0]?.text
      ?? '{"ar":"","en":"","recommendations":[]}';
    return JSON.parse(raw) as { ar: string; en: string; recommendations: string[] };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // PERSONAL ADVOCATE MODE — Independent Worker Objection Draft
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * Draft a legal objection memo specifically for an independent worker.
   * Enforces data consent check — callerClaims.trust_score is included in reasoning.
   */
  async draftPersonalObjection(params: {
    violationDescription: string;
    evidenceSummary?:     string;
    trust_score:          number;
    uid:                  string;
    dataConsentGiven:     boolean;
  }): Promise<{ objectionDraft: string; legalBasis: string[]; trust_score: number }> {
    const prompt = `
[وضع المحامي الشخصي]
وصف المخالفة: ${params.violationDescription}
${params.evidenceSummary ? `ملخص الأدلة: ${params.evidenceSummary}` : ''}
درجة الثقة الحالية: ${params.trust_score}/10
موافقة مشاركة البيانات: ${params.dataConsentGiven ? 'نعم' : 'لا — لا تُفصح عن أي بيانات'}

اكتب مسودة اعتراض قانونية وأسسها القانونية.
أخرج JSON: { "objectionDraft": "...", "legalBasis": ["..."] }
    `.trim();

    const result = await this.proModel.generateContent({
      systemInstruction: { role: 'system', parts: [{ text: SYSTEM_PROMPTS.personal_advocate }] },
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
    });

    const raw    = result.response.candidates?.[0]?.content?.parts?.[0]?.text
      ?? '{"objectionDraft":"","legalBasis":[]}';
    const parsed = JSON.parse(raw) as { objectionDraft: string; legalBasis: string[] };

    return { ...parsed, trust_score: params.trust_score };
  }

  // ── Utility ───────────────────────────────────────────────────────────────────

  /** Expose the resolved mode for a given caller — useful for frontend to render correct UI. */
  getCallerMode(claims: Pick<LexOpsClaims, 'role' | 'routeToVault'>): LexiMode {
    return resolveLexiMode(claims);
  }
}
