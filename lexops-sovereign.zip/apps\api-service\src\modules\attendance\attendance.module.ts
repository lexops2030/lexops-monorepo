import { Module, forwardRef } from '@nestjs/common';
import { GeofenceService } from './geofence.service';
import { AntiSpoofService } from './spoof.service';
import { AttendanceRepository } from './attendance.repository';
import { AttendanceService } from './attendance.service';
import { AttendanceController } from './attendance.controller';
import { BranchesModule } from '../branches/branches.module';
import { LeavesModule } from '../leaves/leaves.module';

@Module({
  imports: [
    BranchesModule,
    forwardRef(() => LeavesModule), // circular guard — LeavesModule may import AttendanceModule later
  ],
  providers: [
    GeofenceService,
    AntiSpoofService,
    AttendanceRepository,
    AttendanceService,
  ],
  controllers: [AttendanceController],
  exports: [GeofenceService, AntiSpoofService, AttendanceService],
})
export class AttendanceModule {}
