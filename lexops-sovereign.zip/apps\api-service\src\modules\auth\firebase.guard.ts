/**
 * LexOps — Fortress 700 Identity Protocol  (v2)
 *
 * Validates Firebase JWT tokens and extracts sovereign custom claims:
 *   - role    : 'sovereign' | 'entity_admin' | 'employee' | 'freelancer'
 *   - tenantId: The commercial Entity ID (700-series) OR 'IND_{uid}' for independent workers
 *   - level   : numeric access level (1–4)
 *
 * v2 additions:
 *   - IND_ Routing Gate  — detects independent-worker tenants (tenantId starts with 'IND_')
 *     and sets routeToVault = true so downstream services redirect to personal_vault.
 *   - trust_score        — carried through from Firebase custom claims for independent workers.
 *   - level_2_independent role alias mapped to 'freelancer' internally.
 */

import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
  ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import * as admin from 'firebase-admin';
import { Request } from 'express';

// ── Custom Claims Shape ───────────────────────────────────────────────────────

export type LexOpsRole = 'sovereign' | 'entity_admin' | 'employee' | 'freelancer';

/**
 * Extended claims attached to every authenticated request.
 *
 * routeToVault — set to true when the user is an Independent Worker (IND_ prefix).
 *   Downstream controllers/services must check this flag and redirect queries to
 *   /users/{uid}/personal_vault instead of /entities/{tenantId}/...
 *
 * trust_score — 0–10; meaningful only when routeToVault is true. Read-only here;
 *   mutations go through PersonalVaultRepository.adjustTrustScore().
 */
export interface LexOpsClaims {
  uid: string;
  email: string | undefined;
  role: LexOpsRole;
  tenantId: string | null;       // Entity 700-series ID or 'IND_{uid}'
  level: 1 | 2 | 3 | 4;         // 1=sovereign, 2=admin, 3=employee, 4=freelancer
  entityName?: string;

  // ── Independent Worker extensions ──────────────────────────────────────────
  routeToVault: boolean;         // true → queries must go to personal_vault
  trust_score:  number | null;   // 0–10, null for non-independent workers
}

// ── Decorator helpers ─────────────────────────────────────────────────────────

export const ROLES_KEY    = 'roles';
export const SKIP_AUTH_KEY = 'skipAuth';

import { SetMetadata } from '@nestjs/common';
export const Roles    = (...roles: LexOpsRole[]) => SetMetadata(ROLES_KEY, roles);
export const SkipAuth = ()                       => SetMetadata(SKIP_AUTH_KEY, true);

// ── IND_ detection helper ─────────────────────────────────────────────────────

export function isIndependentWorker(tenantId: string | null): boolean {
  return typeof tenantId === 'string' && tenantId.startsWith('IND_');
}

// ── Guard ─────────────────────────────────────────────────────────────────────

@Injectable()
export class FirebaseAuthGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    // Allow explicitly public routes
    const skipAuth = this.reflector.getAllAndOverride<boolean>(SKIP_AUTH_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (skipAuth) return true;

    const request = context.switchToHttp().getRequest<Request>();
    const token   = this.extractToken(request);

    if (!token) {
      throw new UnauthorizedException('Missing Bearer token');
    }

    // ── Verify Firebase JWT ─────────────────────────────────────────────────
    let decodedToken: admin.auth.DecodedIdToken;
    try {
      decodedToken = await admin.auth().verifyIdToken(token, true); // checkRevoked=true
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Token verification failed';
      throw new UnauthorizedException(`Invalid or expired token: ${message}`);
    }

    // ── Extract & Validate Custom Claims ────────────────────────────────────
    const claims = this.extractClaims(decodedToken);

    // ── Fortress 700 Isolation Check ────────────────────────────────────────
    // Non-sovereign users must have a tenantId (either entity ID or IND_ prefix)
    if (claims.role !== 'sovereign' && !claims.tenantId) {
      throw new ForbiddenException(
        'Fortress 700: tenantId claim is missing. Access denied.',
      );
    }

    // ── IND_ Routing Gate ────────────────────────────────────────────────────
    // Independent workers carry tenantId = 'IND_{uid}'.
    // Flag is set on claims; route enforcement happens in controllers/services.
    if (claims.routeToVault) {
      // Ensure the IND_ prefix matches the authenticated uid to prevent impersonation
      const expectedPrefix = `IND_${claims.uid}`;
      if (claims.tenantId !== expectedPrefix) {
        throw new ForbiddenException(
          `IND_ routing mismatch: tenantId '${claims.tenantId}' does not match uid '${claims.uid}'.`,
        );
      }
    }

    // ── Role-based access control ────────────────────────────────────────────
    const requiredRoles = this.reflector.getAllAndOverride<LexOpsRole[]>(
      ROLES_KEY,
      [context.getHandler(), context.getClass()],
    );

    if (requiredRoles && requiredRoles.length > 0) {
      if (!requiredRoles.includes(claims.role)) {
        throw new ForbiddenException(
          `Role '${claims.role}' is not authorized. Required: [${requiredRoles.join(', ')}]`,
        );
      }
    }

    // ── Attach claims to request ─────────────────────────────────────────────
    (request as Request & { user: LexOpsClaims }).user = claims;

    return true;
  }

  private extractToken(request: Request): string | null {
    const authHeader = request.headers['authorization'];
    if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
    return authHeader.slice(7);
  }

  private extractClaims(decoded: admin.auth.DecodedIdToken): LexOpsClaims {
    // Support 'level_2_independent' as an alias for 'freelancer'
    const rawRole  = decoded['role'] as string | undefined;
    const role: LexOpsRole =
      rawRole === 'level_2_independent' ? 'freelancer'
      : (rawRole as LexOpsRole) ?? 'employee';

    const tenantId   = (decoded['tenantId'] as string | null) ?? null;
    const level      = (decoded['level']    as 1 | 2 | 3 | 4) ?? 3;
    const trust_score = (decoded['trust_score'] as number | null) ?? null;

    const validRoles: LexOpsRole[] = ['sovereign', 'entity_admin', 'employee', 'freelancer'];
    if (!validRoles.includes(role)) {
      throw new ForbiddenException(`Unknown role in token claims: '${role}'`);
    }

    const routeToVault = isIndependentWorker(tenantId);

    return {
      uid:        decoded.uid,
      email:      decoded.email,
      role,
      tenantId,
      level,
      entityName: decoded['entityName'] as string | undefined,
      routeToVault,
      trust_score: routeToVault ? (trust_score ?? 5) : null,
    };
  }
}

// ── TenantScopeGuard ─────────────────────────────────────────────────────────
// Verifies that the :tenantId route param matches the user's own tenantId.
// Sovereign bypasses this check. Independent workers are allowed to access
// only routes where :tenantId === their own IND_ tenantId.

@Injectable()
export class TenantScopeGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request  = context.switchToHttp().getRequest<Request & { user: LexOpsClaims }>();
    const { user } = request;

    if (!user) {
      throw new UnauthorizedException('User not authenticated');
    }

    // Sovereign has cross-entity read access
    if (user.role === 'sovereign') return true;

    const paramTenantId = (request.params as { tenantId?: string }).tenantId;
    if (!paramTenantId) return true; // No tenantId param on this route

    if (user.tenantId !== paramTenantId) {
      throw new ForbiddenException(
        `Fortress 700: tenant isolation breach. ` +
        `Authenticated tenant '${user.tenantId}' cannot access tenant '${paramTenantId}'.`,
      );
    }

    return true;
  }
}
