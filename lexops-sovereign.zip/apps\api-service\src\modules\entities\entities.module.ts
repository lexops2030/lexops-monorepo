import { Module } from '@nestjs/common';
import { EntitiesRepository } from './entities.repository';
import { EntitiesController } from './entities.controller';
import { EntitiesService } from './entities.service';

@Module({
  providers: [EntitiesRepository, EntitiesService],
  controllers: [EntitiesController],
  exports: [EntitiesRepository, EntitiesService],
})
export class EntitiesModule {}
