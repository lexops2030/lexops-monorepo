/**
 * LexOps — Notifications Service  (Sprint 8)
 *
 * Multi-channel delivery engine with:
 *
 * 1. Sovereign Routing Matrix (event severity → channel):
 *    GEOFENCE_BREACH                → Push
 *    DOCUMENT_EXPIRY_90D            → Email
 *    DOCUMENT_EXPIRY_FINAL_3D       → SMS + Push
 *    FAKE_GPS_DETECTED              → SMS + Push
 *    LEXI_DAILY_REPORT              → Email
 *    PROBATION_ALERT                → Email + Push
 *    PAYROLL_CLOSED                 → Push
 *    OBJECTION_STATUS_UPDATE        → Push
 *    VIOLATION_AUTO_GENERATED       → Email + Push
 *
 * 2. Notification Privacy (Sovereign Rule):
 *    Sensitive fields (ID numbers, salaries, violation details) are
 *    MASKED in the lock-screen preview (maskedTitle / maskedBody).
 *    The full payload is stored server-side in Firestore only.
 *
 * 3. C9 Ledger Integration:
 *    Every dispatched notification appends a record to C9 with its
 *    providerRefId as undeniable legal proof of delivery attempt.
 *
 * Providers are mocked/placeholder — replace with real SDK calls:
 *   SMS   → Twilio (process.env.TWILIO_*)
 *   Email → SendGrid (process.env.SENDGRID_API_KEY)
 *   Push  → Firebase Cloud Messaging Admin SDK
 */

import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { getMessaging } from 'firebase-admin/messaging';
import {
  NotificationsRepository,
  NotifChannel,
  NotifEventType,
  NotifSeverity,
  NotificationRecord,
} from './notifications.repository';
import { C9LedgerRepository } from '../../database/c9-ledger.repository';
import { randomUUID } from 'crypto';

// ── Routing Matrix ────────────────────────────────────────────────────────────

interface RoutingRule {
  channels:  NotifChannel[];
  severity:  NotifSeverity;
}

const ROUTING_MATRIX: Record<NotifEventType, RoutingRule> = {
  GEOFENCE_BREACH:             { channels: ['push'],          severity: 'warning'  },
  DOCUMENT_EXPIRY_90D:         { channels: ['email'],         severity: 'info'     },
  DOCUMENT_EXPIRY_FINAL_3D:    { channels: ['sms', 'push'],   severity: 'critical' },
  FAKE_GPS_DETECTED:           { channels: ['sms', 'push'],   severity: 'critical' },
  LEXI_DAILY_REPORT:           { channels: ['email'],         severity: 'info'     },
  PROBATION_ALERT:             { channels: ['email', 'push'], severity: 'warning'  },
  PAYROLL_CLOSED:              { channels: ['push'],          severity: 'info'     },
  OBJECTION_STATUS_UPDATE:     { channels: ['push'],          severity: 'info'     },
  VIOLATION_AUTO_GENERATED:    { channels: ['email', 'push'], severity: 'warning'  },
  INDEPENDENT_OTP:             { channels: ['sms'],           severity: 'critical' },
  INDEPENDENT_LEGAL_ALERT:     { channels: ['sms', 'push'],   severity: 'critical' },
  INDEPENDENT_LEXI_TIP:        { channels: ['push'],          severity: 'info'     },
  GENESIS_SEAL:                { channels: ['email'],         severity: 'info'     },
};

// ── Privacy mask rules — fields to NEVER expose on lock-screen ────────────────

const SENSITIVE_KEYS = [
  'nationalId', 'netSalary', 'baseSalary', 'deductionAmount',
  'hmacHash', 'violationDetails', 'legalArgument', 'objectionContent',
];

// ── Dispatch input ─────────────────────────────────────────────────────────────

export interface DispatchInput {
  tenantId:      string;
  recipientUid:  string;
  recipientPhone?: string;     // E.164 format — required for SMS
  recipientEmail?: string;     // required for Email
  fcmToken?:     string;       // required for Push
  eventType:     NotifEventType;
  /** Public-safe title (shown on lock-screen after masking) */
  titleTemplate: string;
  /** Public-safe body (shown on lock-screen after masking) */
  bodyTemplate:  string;
  /** Full sensitive payload — stored server-side, never sent raw to device */
  fullPayload:   Record<string, unknown>;
  actorUid?:     string;
}

export interface DispatchResult {
  notifId:       string;
  eventType:     NotifEventType;
  channels:      NotifChannel[];
  status:        'sent' | 'partial' | 'failed';
  providerRefs:  Record<NotifChannel, string>;
}

// ── Service ───────────────────────────────────────────────────────────────────

@Injectable()
export class NotificationsService {
  private readonly logger = new Logger(NotificationsService.name);

  constructor(
    private readonly repo:    NotificationsRepository,
    private readonly c9:      C9LedgerRepository,
    private readonly config:  ConfigService,
  ) {}

  // ══════════════════════════════════════════════════════════════════════════════
  // MAIN DISPATCH — routes through matrix + applies privacy masking
  // ══════════════════════════════════════════════════════════════════════════════

  async dispatch(input: DispatchInput): Promise<DispatchResult> {
    const rule          = ROUTING_MATRIX[input.eventType];
    const providerRefs: Record<string, string> = {};
    const maskedTitle   = this.maskContent(input.titleTemplate);
    const maskedBody    = this.maskContent(input.bodyTemplate);

    this.logger.log(
      `[Notif] Dispatching event=${input.eventType} ` +
      `tenant=${input.tenantId} channels=${rule.channels.join('+')}`,
    );

    // Create log record (status=queued)
    const record = await this.repo.create({
      tenantId:     input.tenantId,
      recipientUid: input.recipientUid,
      eventType:    input.eventType,
      channel:      rule.channels[0],  // primary channel
      severity:     rule.severity,
      status:       'queued',
      maskedTitle,
      maskedBody,
      fullPayload:  this.sanitizePayload(input.fullPayload),
    });

    let anySuccess = false;

    // ── Dispatch to each channel in the routing rule ──────────────────────
    for (const channel of rule.channels) {
      const ref = await this.dispatchToChannel(channel, input, maskedTitle, maskedBody);
      providerRefs[channel] = ref;

      if (ref !== 'FAILED') {
        anySuccess = true;
        await this.repo.markDelivered(input.tenantId, record.notifId, ref);
      } else {
        await this.repo.markFailed(input.tenantId, record.notifId, 'provider_error');
      }
    }

    const status: DispatchResult['status'] =
      anySuccess && Object.values(providerRefs).some(r => r === 'FAILED')
        ? 'partial'
        : anySuccess ? 'sent' : 'failed';

    // ── C9 Seal: proof of delivery attempt ───────────────────────────────
    await this.c9.append({
      tenantId:    input.tenantId,
      eventType:   'NOTIFICATION_DISPATCHED',
      actorUid:    input.actorUid ?? 'system',
      actorRole:   'system',
      subjectUid:  input.recipientUid,
      subjectType: 'notification',
      payload: {
        notifId:      record.notifId,
        eventType:    input.eventType,
        channels:     rule.channels,
        severity:     rule.severity,
        status,
        providerRefs,
        maskedTitle,  // only masked version stored in C9
      },
    });

    return {
      notifId:      record.notifId,
      eventType:    input.eventType,
      channels:     rule.channels,
      status,
      providerRefs: providerRefs as Record<NotifChannel, string>,
    };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // CHANNEL DISPATCHERS (provider mocks — replace SDK calls in production)
  // ══════════════════════════════════════════════════════════════════════════════

  private async dispatchToChannel(
    channel:    NotifChannel,
    input:      DispatchInput,
    title:      string,
    body:       string,
  ): Promise<string> {
    try {
      switch (channel) {
        case 'sms':   return await this.sendSms(input.recipientPhone ?? '', body);
        case 'email': return await this.sendEmail(input.recipientEmail ?? '', title, body, input.fullPayload);
        case 'push':  return await this.sendPush(input.fcmToken ?? '', title, body, input.eventType);
        default:      return 'UNSUPPORTED';
      }
    } catch (err) {
      this.logger.error(`[Notif] Channel '${channel}' failed: ${err}`);
      return 'FAILED';
    }
  }

  /**
   * SMS — Twilio placeholder
   * Production: replace with `twilio(accountSid, authToken).messages.create(...)`
   */
  private async sendSms(to: string, body: string): Promise<string> {
    if (!to) return 'SKIPPED_NO_PHONE';

    const accountSid = this.config.get<string>('TWILIO_ACCOUNT_SID');
    const authToken  = this.config.get<string>('TWILIO_AUTH_TOKEN');
    const fromNumber = this.config.get<string>('TWILIO_FROM_NUMBER', '+966000000000');

    // ── PLACEHOLDER — replace with actual Twilio SDK call ──────────────────
    // const client = twilio(accountSid, authToken);
    // const msg    = await client.messages.create({ body, from: fromNumber, to });
    // return msg.sid;

    const mockSid = `SM_MOCK_${randomUUID().replace(/-/g, '').slice(0, 20).toUpperCase()}`;
    this.logger.log(`[SMS] MOCK → to=${to} sid=${mockSid}`);
    return mockSid;
  }

  /**
   * Email — SendGrid placeholder
   * Production: replace with `@sendgrid/mail` sgMail.send(...)
   */
  private async sendEmail(
    to:          string,
    subject:     string,
    textBody:    string,
    payload:     Record<string, unknown>,
  ): Promise<string> {
    if (!to) return 'SKIPPED_NO_EMAIL';

    const apiKey     = this.config.get<string>('SENDGRID_API_KEY');
    const fromEmail  = this.config.get<string>('SENDGRID_FROM', 'noreply@lexops.sa');

    // ── PLACEHOLDER — replace with actual SendGrid SDK call ─────────────────
    // await sgMail.send({ to, from: fromEmail, subject, text: textBody, ... });

    const mockMsgId = `SG_MOCK_${randomUUID().replace(/-/g, '').slice(0, 20).toUpperCase()}`;
    this.logger.log(`[Email] MOCK → to=${to} subject="${subject}" id=${mockMsgId}`);
    return mockMsgId;
  }

  /**
   * Push — Firebase Cloud Messaging
   * Uses the Admin SDK (already initialised globally) — partially real.
   * Token is optional in dev; gracefully skips if absent.
   */
  private async sendPush(
    fcmToken:  string,
    title:     string,
    body:      string,
    eventType: NotifEventType,
  ): Promise<string> {
    if (!fcmToken) return 'SKIPPED_NO_FCM_TOKEN';

    try {
      const messaging = getMessaging();
      const messageId = await messaging.send({
        token: fcmToken,
        notification: { title, body },
        android: {
          priority:     'high',
          notification: {
            channelId: eventType.startsWith('INDEPENDENT_') ? 'lexops_ind' : 'lexops_entity',
          },
        },
        apns: {
          payload: { aps: { alert: { title, body }, sound: 'default', badge: 1 } },
        },
        data: { eventType, platform: 'lexops' },
      });

      this.logger.log(`[Push] FCM → token=…${fcmToken.slice(-8)} messageId=${messageId}`);
      return messageId;
    } catch (err) {
      // FCM token may be invalid in dev — fall through to mock
      const mockId = `FCM_MOCK_${randomUUID().replace(/-/g, '').slice(0, 18).toUpperCase()}`;
      this.logger.warn(`[Push] FCM failed (${err}) — using mock: ${mockId}`);
      return mockId;
    }
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // PRIVACY MASKING — Sovereign Rule
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * maskContent — replaces sensitive substrings with redaction markers.
   * Used for lock-screen preview (maskedTitle / maskedBody).
   *
   * Pattern: any sequence that looks like:
   *   - Saudi National IDs (10 digits starting with 1 or 2)
   *   - Currency amounts (digits followed by ريال / SAR / ﷼)
   *   - Arabic violation text after "مخالفة:" keyword
   */
  private maskContent(text: string): string {
    return text
      // Mask Saudi National ID (10-digit starting with 1 or 2)
      .replace(/\b[12]\d{9}\b/g, '●●●●●●●●●●')
      // Mask salary/amounts: "1,234.56 ريال" or "SAR 1234"
      .replace(/[\d,]+\.?\d*\s*(ريال|SAR|﷼)/gi, '●●●● ريال')
      // Mask content after "مخالفة:" or "violation:" labels
      .replace(/(مخالفة|violation):\s*.+/gi, '$1: [محتوى محمي]')
      // Mask HMAC hashes (hex strings > 20 chars)
      .replace(/[0-9a-f]{20,}/gi, '●●●●[HASH]●●●●');
  }

  /**
   * sanitizePayload — strips raw sensitive values from the stored payload
   * and replaces them with redacted markers. The full payload is Firestore-only.
   */
  private sanitizePayload(
    payload: Record<string, unknown>,
  ): Record<string, unknown> {
    const sanitized: Record<string, unknown> = {};

    for (const [key, value] of Object.entries(payload)) {
      if (SENSITIVE_KEYS.includes(key)) {
        sanitized[key] = '[REDACTED — C9 Only]';
      } else {
        sanitized[key] = value;
      }
    }

    return sanitized;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // CONVENIENCE DISPATCHERS (called by other services)
  // ══════════════════════════════════════════════════════════════════════════════

  async notifyGeofenceBreach(
    tenantId:     string,
    employeeId:   string,
    branchName:   string,
    fcmToken?:    string,
  ): Promise<DispatchResult> {
    return this.dispatch({
      tenantId, recipientUid: employeeId, fcmToken,
      eventType:     'GEOFENCE_BREACH',
      titleTemplate: 'تنبيه: خروج عن النطاق الجغرافي',
      bodyTemplate:  `تم تسجيل خروج عن نطاق فرع ${branchName}. يرجى المراجعة الفورية.`,
      fullPayload:   { tenantId, employeeId, branchName },
    });
  }

  async notifyDocumentExpiry(
    tenantId:       string,
    adminUid:       string,
    adminEmail:     string,
    docLabel:       string,
    daysRemaining:  number,
    fcmToken?:      string,
  ): Promise<DispatchResult> {
    const isFinal   = daysRemaining <= 3;
    const eventType: NotifEventType = isFinal
      ? 'DOCUMENT_EXPIRY_FINAL_3D'
      : 'DOCUMENT_EXPIRY_90D';

    return this.dispatch({
      tenantId, recipientUid: adminUid, recipientEmail: adminEmail, fcmToken,
      eventType,
      titleTemplate: `تنبيه انتهاء صلاحية: ${docLabel}`,
      bodyTemplate:
        `${isFinal ? '⚠️ تحذير نهائي: ' : ''}` +
        `${docLabel} سينتهي خلال ${daysRemaining} يوم. يرجى التجديد الفوري.`,
      fullPayload: { tenantId, adminUid, docLabel, daysRemaining },
    });
  }

  async notifyFakeGpsDetected(
    tenantId:    string,
    employeeId:  string,
    adminEmail?: string,
    fcmToken?:   string,
  ): Promise<DispatchResult> {
    return this.dispatch({
      tenantId, recipientUid: employeeId, fcmToken, recipientEmail: adminEmail,
      eventType:     'FAKE_GPS_DETECTED',
      titleTemplate: 'تحذير: اكتشاف موقع وهمي',
      bodyTemplate:  'تم اكتشاف محاولة تلاعب بالموقع الجغرافي أثناء تسجيل الحضور.',
      fullPayload:   { tenantId, employeeId, event: 'mock_location_detected' },
    });
  }

  async notifyLexiDailyReport(
    tenantId:    string,
    adminUid:    string,
    adminEmail:  string,
    reportUrl:   string,
  ): Promise<DispatchResult> {
    return this.dispatch({
      tenantId, recipientUid: adminUid, recipientEmail: adminEmail,
      eventType:     'LEXI_DAILY_REPORT',
      titleTemplate: 'تقرير LEXI اليومي جاهز',
      bodyTemplate:  'يمكنك الاطلاع على تقرير الامتثال اليومي من LEXI من خلال المنصة.',
      fullPayload:   { tenantId, adminUid, reportUrl },
    });
  }

  async notifyViolationGenerated(
    tenantId:     string,
    employeeId:   string,
    employeeEmail?: string,
    violationType?: string,
    fcmToken?:    string,
  ): Promise<DispatchResult> {
    return this.dispatch({
      tenantId, recipientUid: employeeId,
      recipientEmail: employeeEmail, fcmToken,
      eventType:     'VIOLATION_AUTO_GENERATED',
      titleTemplate: 'إشعار: تم توليد مخالفة تلقائية',
      bodyTemplate:  'تم تسجيل مخالفة على ملفك وفق قواعد الامتثال. يمكنك تقديم اعتراض من المنصة.',
      fullPayload:   { tenantId, employeeId, violationType: '[REDACTED]' },
    });
  }

  // ── Queries ──────────────────────────────────────────────────────────────────

  getMyNotifications(tenantId: string, recipientUid: string) {
    return this.repo.findByRecipient(tenantId, recipientUid);
  }

  getTenantNotificationLog(tenantId: string) {
    return this.repo.findByTenant(tenantId);
  }
}
