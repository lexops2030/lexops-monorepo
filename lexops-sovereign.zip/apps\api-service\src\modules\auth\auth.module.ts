import { Module, Global } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import * as admin from 'firebase-admin';
import { FirebaseAuthGuard } from './firebase.guard';

@Global()
@Module({
  providers: [
    // ── Initialize Firebase Admin (once) ──────────────────────────────────────
    {
      provide: 'FIREBASE_ADMIN',
      useFactory: () => {
        if (admin.apps.length === 0) {
          admin.initializeApp({
            // In Cloud Run, Application Default Credentials are used automatically.
            // Locally, set GOOGLE_APPLICATION_CREDENTIALS env var to your service account key.
            projectId: process.env.GCP_PROJECT_ID,
          });
        }
        return admin.app();
      },
    },

    // ── Apply Firebase Guard globally ────────────────────────────────────────
    {
      provide: APP_GUARD,
      useClass: FirebaseAuthGuard,
    },

    FirebaseAuthGuard,
  ],
  exports: ['FIREBASE_ADMIN', FirebaseAuthGuard],
})
export class AuthModule {}
