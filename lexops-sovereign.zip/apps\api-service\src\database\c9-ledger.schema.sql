-- ═══════════════════════════════════════════════════════════════════════════════
-- LexOps C9 Ledger — The Immutable Truth Log
-- PostgreSQL Schema — Append-Only, HMAC-Sealed
--
-- Principle: Every record is cryptographically sealed with HMAC-SHA256.
--            UPDATE and DELETE are blocked at the database level via triggers.
--            This table is the legally binding source of truth for all disputes.
-- ═══════════════════════════════════════════════════════════════════════════════

-- Enable pgcrypto for HMAC verification
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ── Main Truth Trail Table ─────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS lexops_truth_trail (
  id              BIGSERIAL       PRIMARY KEY,

  -- Fortress 700 isolation key
  tenant_id       VARCHAR(50)     NOT NULL,

  -- Record classification
  event_type      VARCHAR(80)     NOT NULL,
  -- e.g.: 'attendance.checkin', 'attendance.checkout', 'violation.issued',
  --       'payroll.closed', 'leave.approved', 'lexi.decision', 'user.created'

  -- The immutable actor
  actor_uid       VARCHAR(128)    NOT NULL,
  actor_role      VARCHAR(30)     NOT NULL,

  -- Target entity (employee, entity, branch)
  subject_uid     VARCHAR(128),
  subject_type    VARCHAR(50),

  -- Event payload — full JSON snapshot at time of event
  payload         JSONB           NOT NULL,

  -- Cryptographic seal (HMAC-SHA256 of tenant_id||event_type||payload||created_at)
  hmac_signature  VARCHAR(64)     NOT NULL,

  -- Timestamp — set by DB, immutable
  created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

  -- Geographic context (for attendance events)
  geo_lat         DECIMAL(10, 7),
  geo_lng         DECIMAL(10, 7),
  geo_accuracy_m  SMALLINT,

  -- Device fingerprint (anti-spoofing)
  device_id       VARCHAR(255),
  ip_address      INET
);

-- ── Fortress 700 Index ─────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_truth_trail_tenant     ON lexops_truth_trail (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_truth_trail_actor      ON lexops_truth_trail (actor_uid, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_truth_trail_subject    ON lexops_truth_trail (subject_uid, tenant_id);
CREATE INDEX IF NOT EXISTS idx_truth_trail_event_type ON lexops_truth_trail (event_type, tenant_id);

-- ── APPEND-ONLY ENFORCEMENT ────────────────────────────────────────────────────
-- These triggers make the table physically immutable after insert.

CREATE OR REPLACE FUNCTION lexops_block_mutation()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION
    '[C9 Ledger] IMMUTABILITY VIOLATION: % operations are permanently prohibited on lexops_truth_trail. '
    'This table is a sealed legal record. TenantId: %, RecordId: %',
    TG_OP,
    OLD.tenant_id,
    OLD.id;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Block UPDATE
CREATE TRIGGER trg_block_update
  BEFORE UPDATE ON lexops_truth_trail
  FOR EACH ROW EXECUTE FUNCTION lexops_block_mutation();

-- Block DELETE
CREATE TRIGGER trg_block_delete
  BEFORE DELETE ON lexops_truth_trail
  FOR EACH ROW EXECUTE FUNCTION lexops_block_mutation();

-- ── HMAC Verification Function ────────────────────────────────────────────────
-- Utility to verify record integrity at any point in time

CREATE OR REPLACE FUNCTION lexops_verify_hmac(
  p_tenant_id    TEXT,
  p_event_type   TEXT,
  p_payload      JSONB,
  p_created_at   TIMESTAMPTZ,
  p_stored_hmac  TEXT,
  p_secret_key   TEXT
)
RETURNS BOOLEAN AS $$
DECLARE
  computed_hmac TEXT;
  raw_data TEXT;
BEGIN
  raw_data := p_tenant_id || '|' || p_event_type || '|' || p_payload::TEXT || '|' || p_created_at::TEXT;
  computed_hmac := encode(hmac(raw_data, p_secret_key, 'sha256'), 'hex');
  RETURN computed_hmac = p_stored_hmac;
END;
$$ LANGUAGE plpgsql;

-- ── Table Comment ──────────────────────────────────────────────────────────────
COMMENT ON TABLE lexops_truth_trail IS
  'LexOps C9 Ledger — Immutable, HMAC-sealed legal truth log. '
  'Any attempt to UPDATE or DELETE records will raise a fatal exception. '
  'Governed by Saudi data sovereignty regulations (me-central1/me-central2).';
