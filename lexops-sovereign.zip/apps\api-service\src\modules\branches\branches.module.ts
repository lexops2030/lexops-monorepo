import { Module } from '@nestjs/common';
import { BranchesRepository } from './branches.repository';
import { BranchesService } from './branches.service';
import { BranchesController } from './branches.controller';

@Module({
  providers: [BranchesRepository, BranchesService],
  controllers: [BranchesController],
  exports: [BranchesRepository, BranchesService],
})
export class BranchesModule {}
