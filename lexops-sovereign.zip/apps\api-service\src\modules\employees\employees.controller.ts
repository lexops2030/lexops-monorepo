import {
  Controller, Get, Post, Patch, Delete,
  Param, Body, Request, Version,
  UseGuards, Query,
} from '@nestjs/common';
import {
  ApiTags, ApiBearerAuth, ApiOperation,
  ApiParam, ApiQuery,
} from '@nestjs/swagger';
import {
  IsString, IsNotEmpty, IsOptional, IsEnum,
  IsNumber, IsPositive, IsDateString, IsEmail,
  IsMobilePhone,
} from 'class-validator';
import { EmployeesService } from './employees.service';
import { EmploymentType, EmployeeStatus } from './employees.repository';
import { Roles } from '../auth/firebase.guard';
import { TenantScopeGuard } from '../../common/guards';
import { Request as ExpressRequest } from 'express';
import type { LexOpsClaims } from '../auth/firebase.guard';

// ── DTOs ──────────────────────────────────────────────────────────────────────

class CreateEmployeeDto {
  @IsString() @IsNotEmpty()
  branchId: string;

  @IsString() @IsNotEmpty()
  nationalId: string;

  @IsString() @IsNotEmpty()
  name: string;

  @IsString() @IsOptional()
  nameEn?: string;

  @IsString() @IsNotEmpty()
  position: string;

  @IsString() @IsOptional()
  department?: string;

  @IsEnum(['full_time', 'part_time', 'contract', 'seasonal'])
  employmentType: EmploymentType;

  @IsDateString()
  joinedAt: string;

  @IsString() @IsOptional()
  @IsMobilePhone('ar-SA')
  phone?: string;

  @IsEmail() @IsOptional()
  email?: string;

  @IsDateString() @IsOptional()
  iqamaExpiry?: string;

  @IsDateString() @IsOptional()
  probationEndsAt?: string;

  @IsNumber() @IsPositive() @IsOptional()
  baseSalary?: number;
}

class UpdateEmployeeDto {
  @IsString() @IsOptional()
  branchId?: string;

  @IsString() @IsOptional()
  name?: string;

  @IsString() @IsOptional()
  position?: string;

  @IsString() @IsOptional()
  department?: string;

  @IsEnum(['full_time', 'part_time', 'contract', 'seasonal']) @IsOptional()
  employmentType?: EmploymentType;

  @IsEnum(['active', 'on_leave', 'suspended', 'terminated']) @IsOptional()
  status?: EmployeeStatus;

  @IsNumber() @IsPositive() @IsOptional()
  baseSalary?: number;

  @IsDateString() @IsOptional()
  iqamaExpiry?: string;

  @IsDateString() @IsOptional()
  probationEndsAt?: string;
}

// ── Controller ────────────────────────────────────────────────────────────────

@ApiTags('Employees — Fortress 700')
@ApiBearerAuth('Firebase-JWT')
@Controller('entities/:tenantId/employees')
@UseGuards(TenantScopeGuard)
export class EmployeesController {
  constructor(private readonly employeesService: EmployeesService) {}

  @Get()
  @Version('1')
  @Roles('sovereign', 'entity_admin')
  @ApiOperation({ summary: 'List employees in an entity (filterable by branchId / status)' })
  @ApiParam({ name: 'tenantId' })
  @ApiQuery({ name: 'branchId', required: false })
  @ApiQuery({ name: 'status', required: false, enum: ['active', 'on_leave', 'suspended', 'terminated'] })
  findAll(
    @Param('tenantId') tenantId: string,
    @Query('branchId') branchId?: string,
    @Query('status') status?: EmployeeStatus,
  ) {
    return this.employeesService.findAll(tenantId, { branchId, status });
  }

  @Get(':employeeId')
  @Version('1')
  @Roles('sovereign', 'entity_admin', 'employee')
  @ApiOperation({ summary: 'Get employee profile' })
  findOne(
    @Param('tenantId') tenantId: string,
    @Param('employeeId') employeeId: string,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    // Employees can only fetch their own profile
    if (req.user.role === 'employee' && req.user.uid !== employeeId) {
      return { message: 'Access restricted to own profile' };
    }
    return this.employeesService.findOne(tenantId, employeeId);
  }

  @Post()
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({
    summary: 'Register a new employee — validates branch belongs to same entity (422 if violated)',
  })
  create(
    @Param('tenantId') tenantId: string,
    @Body() dto: CreateEmployeeDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.employeesService.create(
      tenantId,
      { ...dto, status: 'active', isActive: true, createdBy: req.user.uid },
      req.user.uid,
    );
  }

  @Patch(':employeeId')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'Update employee details' })
  update(
    @Param('tenantId') tenantId: string,
    @Param('employeeId') employeeId: string,
    @Body() dto: UpdateEmployeeDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.employeesService.update(tenantId, employeeId, dto, req.user.uid);
  }

  @Delete(':employeeId')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'Terminate an employee (soft-delete, C9 sealed)' })
  terminate(
    @Param('tenantId') tenantId: string,
    @Param('employeeId') employeeId: string,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.employeesService.terminate(tenantId, employeeId, req.user.uid);
  }
}
