/**
 * LexOps — Leaves Repository
 *
 * Stores leave requests under:
 *   /entities/{tenantId}/leaves/{leaveId}
 *
 * C9 principle: no hard deletes. Cancellation is a status mutation.
 * Overlap detection is done via a date-range query before creating.
 */

import {
  Injectable, Inject,
  NotFoundException, ConflictException,
} from '@nestjs/common';
import { Firestore, FieldValue } from '@google-cloud/firestore';

// ── Types ─────────────────────────────────────────────────────────────────────

export type LeaveType   = 'annual' | 'sick' | 'unpaid' | 'other';
export type LeaveStatus = 'requested' | 'approved' | 'rejected' | 'cancelled';

export interface LeaveReview {
  reviewedBy:  string;
  reviewedAt:  FirebaseFirestore.Timestamp;
  decision:    'approved' | 'rejected';
  reason:      string;
}

export interface LeaveDocument {
  leaveId:       string;
  tenantId:      string;
  employeeUid:   string;
  branchId:      string;
  leaveType:     LeaveType;
  status:        LeaveStatus;
  startDate:     string;      // ISO 8601 'YYYY-MM-DD'
  endDate:       string;      // ISO 8601 'YYYY-MM-DD'
  daysRequested: number;      // Calculated inclusive days
  reason:        string;
  attachmentUrl?: string;
  review?:       LeaveReview;
  createdAt:     FirebaseFirestore.Timestamp;
  updatedAt:     FirebaseFirestore.Timestamp;
  createdBy:     string;
}

// ── Repository ────────────────────────────────────────────────────────────────

@Injectable()
export class LeavesRepository {
  constructor(@Inject('FIRESTORE') private readonly db: Firestore) {}

  private leaveRef(tenantId: string, leaveId: string) {
    return this.db
      .collection('entities').doc(tenantId)
      .collection('leaves').doc(leaveId);
  }

  private leavesCol(tenantId: string) {
    return this.db.collection('entities').doc(tenantId).collection('leaves');
  }

  async findById(tenantId: string, leaveId: string): Promise<LeaveDocument | null> {
    const snap = await this.leaveRef(tenantId, leaveId).get();
    return snap.exists ? (snap.data() as LeaveDocument) : null;
  }

  /** All leaves for a tenant (admin view) */
  async findAllByTenant(
    tenantId: string,
    filters: { status?: LeaveStatus; leaveType?: LeaveType } = {},
  ): Promise<LeaveDocument[]> {
    let q = this.leavesCol(tenantId)
      .orderBy('startDate', 'desc') as FirebaseFirestore.Query;

    if (filters.status)    q = q.where('status',    '==', filters.status);
    if (filters.leaveType) q = q.where('leaveType', '==', filters.leaveType);

    const snap = await q.limit(100).get();
    return snap.docs.map((d) => d.data() as LeaveDocument);
  }

  /** Leaves for a single employee */
  async findByEmployee(
    tenantId: string,
    employeeUid: string,
  ): Promise<LeaveDocument[]> {
    const snap = await this.leavesCol(tenantId)
      .where('employeeUid', '==', employeeUid)
      .orderBy('startDate', 'desc')
      .limit(50)
      .get();
    return snap.docs.map((d) => d.data() as LeaveDocument);
  }

  /**
   * Find all APPROVED leaves for an employee that overlap with [start, end].
   * Used for:
   *   a) overlap detection before new request
   *   b) attendance block check (isDateOnApprovedLeave)
   */
  async findApprovedOverlapping(
    tenantId: string,
    employeeUid: string,
    startDate: string,
    endDate: string,
  ): Promise<LeaveDocument[]> {
    // Firestore range queries: startDate <= endDate AND endDate >= startDate
    // We query where endDate >= startDate to capture partial overlaps
    const snap = await this.leavesCol(tenantId)
      .where('employeeUid', '==', employeeUid)
      .where('status', '==', 'approved')
      .where('endDate', '>=', startDate)
      .orderBy('endDate', 'asc')
      .get();

    // Post-filter: also ensure startDate <= endDate of request
    return snap.docs
      .map((d) => d.data() as LeaveDocument)
      .filter((l) => l.startDate <= endDate);
  }

  /**
   * Find ALL active (requested | approved) leaves for an employee
   * that overlap with the given range — for overlap policy check.
   */
  async findActiveOverlapping(
    tenantId: string,
    employeeUid: string,
    startDate: string,
    endDate: string,
    excludeLeaveId?: string,
  ): Promise<LeaveDocument[]> {
    const snap = await this.leavesCol(tenantId)
      .where('employeeUid', '==', employeeUid)
      .where('status', 'in', ['requested', 'approved'])
      .where('endDate', '>=', startDate)
      .orderBy('endDate', 'asc')
      .get();

    return snap.docs
      .map((d) => d.data() as LeaveDocument)
      .filter(
        (l) =>
          l.startDate <= endDate &&
          (excludeLeaveId ? l.leaveId !== excludeLeaveId : true),
      );
  }

  /** Count used annual-leave days in the current Hijri/Gregorian year */
  async countUsedAnnualDays(
    tenantId: string,
    employeeUid: string,
    year: number,
  ): Promise<number> {
    const yearStart = `${year}-01-01`;
    const yearEnd   = `${year}-12-31`;

    const snap = await this.leavesCol(tenantId)
      .where('employeeUid', '==', employeeUid)
      .where('leaveType', '==', 'annual')
      .where('status', 'in', ['approved', 'requested'])
      .where('startDate', '>=', yearStart)
      .where('startDate', '<=', yearEnd)
      .get();

    return snap.docs
      .map((d) => d.data() as LeaveDocument)
      .reduce((sum, l) => sum + l.daysRequested, 0);
  }

  async create(
    tenantId: string,
    leaveId: string,
    data: Omit<LeaveDocument, 'leaveId' | 'tenantId' | 'createdAt' | 'updatedAt'>,
  ): Promise<LeaveDocument> {
    const doc: LeaveDocument = {
      ...data,
      leaveId,
      tenantId,
      createdAt: FieldValue.serverTimestamp() as FirebaseFirestore.Timestamp,
      updatedAt: FieldValue.serverTimestamp() as FirebaseFirestore.Timestamp,
    };
    await this.leaveRef(tenantId, leaveId).set(doc);
    return doc;
  }

  async applyReview(
    tenantId: string,
    leaveId: string,
    review: LeaveReview,
  ): Promise<void> {
    const ref  = this.leaveRef(tenantId, leaveId);
    const snap = await ref.get();

    if (!snap.exists) {
      throw new NotFoundException(`Leave '${leaveId}' not found in tenant '${tenantId}'`);
    }

    const doc = snap.data() as LeaveDocument;
    if (doc.status !== 'requested') {
      throw new ConflictException(
        `طلب الإجازة '${leaveId}' بحالة '${doc.status}' ولا يمكن مراجعته مجدداً.`,
      );
    }

    await ref.update({
      status:    review.decision,
      review,
      updatedAt: FieldValue.serverTimestamp(),
    });
  }

  async cancel(tenantId: string, leaveId: string, employeeUid: string): Promise<void> {
    const ref  = this.leaveRef(tenantId, leaveId);
    const snap = await ref.get();

    if (!snap.exists) throw new NotFoundException(`Leave '${leaveId}' not found`);

    const doc = snap.data() as LeaveDocument;
    if (doc.employeeUid !== employeeUid) {
      throw new ConflictException('لا يمكنك إلغاء إجازة موظف آخر.');
    }
    if (doc.status === 'approved') {
      throw new ConflictException('لا يمكن إلغاء إجازة معتمدة. تواصل مع المدير.');
    }

    await ref.update({ status: 'cancelled', updatedAt: FieldValue.serverTimestamp() });
  }
}
