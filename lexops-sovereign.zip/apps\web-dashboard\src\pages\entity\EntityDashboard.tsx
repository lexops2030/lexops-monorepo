import { useState } from 'react';
import { Building2, UserPlus, ChevronLeft } from 'lucide-react';
import BranchFormPage from './BranchFormPage';
import EmployeeFormPage from './EmployeeFormPage';
import { Button } from '../../components/ui/Button';

type View = 'dashboard' | 'add-branch' | 'add-employee';

// In real use, tenantId comes from auth store
const TENANT_ID = import.meta.env.VITE_DEMO_TENANT_ID ?? 'ENTITY_700';

export default function EntityDashboard() {
  const [view, setView] = useState<View>('dashboard');

  if (view === 'add-branch') {
    return (
      <div>
        <button
          onClick={() => setView('dashboard')}
          className="mb-6 flex items-center gap-1 text-sm text-primary hover:underline"
        >
          <ChevronLeft className="h-4 w-4" />
          العودة للوحة التحكم
        </button>
        <BranchFormPage tenantId={TENANT_ID} onSuccess={() => setView('dashboard')} />
      </div>
    );
  }

  if (view === 'add-employee') {
    return (
      <div>
        <button
          onClick={() => setView('dashboard')}
          className="mb-6 flex items-center gap-1 text-sm text-primary hover:underline"
        >
          <ChevronLeft className="h-4 w-4" />
          العودة للوحة التحكم
        </button>
        <EmployeeFormPage tenantId={TENANT_ID} onSuccess={() => setView('dashboard')} />
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-neutral-900 mb-2">لوحة التحكم</h1>
      <p className="text-neutral-500 mb-8">إدارة المنشأة والفروع والموظفين</p>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 max-w-lg">
        <button
          onClick={() => setView('add-branch')}
          className="card-sovereign flex items-center gap-4 text-start hover:shadow-sovereign
                     hover:border-primary/30 transition-all duration-200 cursor-pointer group"
        >
          <div className="flex h-12 w-12 items-center justify-center rounded-xl
                          bg-primary/10 group-hover:bg-primary/20 transition-colors">
            <Building2 className="h-6 w-6 text-primary" />
          </div>
          <div>
            <p className="font-semibold text-neutral-800">إضافة فرع جديد</p>
            <p className="text-xs text-neutral-500 mt-0.5">تحديد الإحداثيات والنطاق الجغرافي</p>
          </div>
        </button>

        <button
          onClick={() => setView('add-employee')}
          className="card-sovereign flex items-center gap-4 text-start hover:shadow-gold
                     hover:border-secondary/40 transition-all duration-200 cursor-pointer group"
        >
          <div className="flex h-12 w-12 items-center justify-center rounded-xl
                          bg-secondary/20 group-hover:bg-secondary/30 transition-colors">
            <UserPlus className="h-6 w-6 text-secondary-dark" />
          </div>
          <div>
            <p className="font-semibold text-neutral-800">تسجيل موظف جديد</p>
            <p className="text-xs text-neutral-500 mt-0.5">ربط الموظف بالفرع وختم C9</p>
          </div>
        </button>
      </div>
    </div>
  );
}
