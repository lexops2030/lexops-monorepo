import { Injectable, Inject, ConflictException, NotFoundException } from '@nestjs/common';
import { Firestore, FieldValue } from '@google-cloud/firestore';

export interface EntityDocument {
  tenantId: string;          // 700-series commercial ID — primary key
  nameAr: string;
  nameEn: string;
  commercialRegNumber: string;
  licenseExpiry: string;     // ISO 8601 date
  activeBranchCount: number;
  subscriptionTier: 'starter' | 'growth' | 'enterprise';
  isActive: boolean;
  createdAt: FirebaseFirestore.Timestamp;
  updatedAt: FirebaseFirestore.Timestamp;
}

@Injectable()
export class EntitiesRepository {
  private readonly col: FirebaseFirestore.CollectionReference;

  constructor(@Inject('FIRESTORE') private readonly db: Firestore) {
    this.col = db.collection('entities');
  }

  async findById(tenantId: string): Promise<EntityDocument | null> {
    const snap = await this.col.doc(tenantId).get();
    return snap.exists ? (snap.data() as EntityDocument) : null;
  }

  async findAll(): Promise<EntityDocument[]> {
    const snap = await this.col.where('isActive', '==', true).get();
    return snap.docs.map((d) => d.data() as EntityDocument);
  }

  async create(tenantId: string, data: Omit<EntityDocument, 'tenantId' | 'createdAt' | 'updatedAt'>): Promise<EntityDocument> {
    const ref = this.col.doc(tenantId);
    const existing = await ref.get();

    if (existing.exists) {
      throw new ConflictException(`Entity with tenantId '${tenantId}' already exists`);
    }

    const doc: EntityDocument = {
      ...data,
      tenantId,
      createdAt: FieldValue.serverTimestamp() as FirebaseFirestore.Timestamp,
      updatedAt: FieldValue.serverTimestamp() as FirebaseFirestore.Timestamp,
    };

    await ref.set(doc);
    return doc;
  }

  async update(tenantId: string, data: Partial<Omit<EntityDocument, 'tenantId' | 'createdAt'>>): Promise<void> {
    const ref = this.col.doc(tenantId);
    const existing = await ref.get();

    if (!existing.exists) {
      throw new NotFoundException(`Entity '${tenantId}' not found`);
    }

    await ref.update({
      ...data,
      updatedAt: FieldValue.serverTimestamp(),
    });
  }

  // Soft-delete only — no hard deletes per C9 Ledger principle
  async deactivate(tenantId: string): Promise<void> {
    await this.update(tenantId, { isActive: false });
  }
}
