import { Module } from '@nestjs/common';
import { LexiService } from './lexi.service';
import { LexiController } from './lexi.controller';

@Module({
  providers: [LexiService],
  controllers: [LexiController],
  exports: [LexiService],
})
export class LexiModule {}
