import { Module } from '@nestjs/common';
import { ObjectionsRepository } from './objections.repository';
import { ObjectionsService } from './objections.service';
import { ObjectionsController } from './objections.controller';
import { ComplianceModule } from '../compliance/compliance.module';
import { DatabaseModule } from '../../database/database.module';

@Module({
  imports: [
    DatabaseModule,    // Firestore + C9LedgerRepository
    ComplianceModule,  // ViolationsRepository (markContested, resolve, findById)
  ],
  providers:   [ObjectionsRepository, ObjectionsService],
  controllers: [ObjectionsController],
  exports:     [ObjectionsService, ObjectionsRepository],
})
export class ObjectionsModule {}
