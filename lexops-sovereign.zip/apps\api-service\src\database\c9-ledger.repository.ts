import { Injectable, Inject, Logger } from '@nestjs/common';
import { Pool } from 'pg';
import * as crypto from 'crypto';

export interface C9Record {
  id?: number;
  tenantId: string;
  eventType: string;
  actorUid: string;
  actorRole: string;
  subjectUid?: string;
  subjectType?: string;
  payload: Record<string, unknown>;
  hmacSignature?: string;
  createdAt?: Date;
  geoLat?: number;
  geoLng?: number;
  geoAccuracyM?: number;
  deviceId?: string;
  ipAddress?: string;
}

@Injectable()
export class C9LedgerRepository {
  private readonly logger = new Logger(C9LedgerRepository.name);

  constructor(@Inject('PG_POOL') private readonly pool: Pool) {}

  /**
   * Append a new immutable record to the C9 Ledger.
   * Computes HMAC-SHA256 before insertion — secret key NEVER exposed in logs.
   */
  async append(record: Omit<C9Record, 'id' | 'createdAt' | 'hmacSignature'>): Promise<number> {
    const hmacSecret = process.env.C9_HMAC_SECRET;
    if (!hmacSecret) {
      throw new Error('[C9 Ledger] C9_HMAC_SECRET environment variable is not set');
    }

    const nowIso = new Date().toISOString();
    const rawData = `${record.tenantId}|${record.eventType}|${JSON.stringify(record.payload)}|${nowIso}`;
    const hmacSignature = crypto
      .createHmac('sha256', hmacSecret)
      .update(rawData)
      .digest('hex');

    const sql = `
      INSERT INTO lexops_truth_trail (
        tenant_id, event_type, actor_uid, actor_role,
        subject_uid, subject_type, payload, hmac_signature,
        geo_lat, geo_lng, geo_accuracy_m, device_id, ip_address
      ) VALUES (
        $1, $2, $3, $4,
        $5, $6, $7, $8,
        $9, $10, $11, $12, $13
      )
      RETURNING id
    `;

    const result = await this.pool.query<{ id: number }>(sql, [
      record.tenantId,
      record.eventType,
      record.actorUid,
      record.actorRole,
      record.subjectUid ?? null,
      record.subjectType ?? null,
      JSON.stringify(record.payload),
      hmacSignature,
      record.geoLat ?? null,
      record.geoLng ?? null,
      record.geoAccuracyM ?? null,
      record.deviceId ?? null,
      record.ipAddress ?? null,
    ]);

    const insertedId = result.rows[0].id;
    this.logger.verbose(`[C9] Appended record #${insertedId} | tenant=${record.tenantId} | event=${record.eventType}`);
    return insertedId;
  }

  /**
   * Query records for a specific tenant (read-only).
   * Supports pagination for audit trail exports.
   */
  async queryByTenant(
    tenantId: string,
    options: { limit?: number; offset?: number; eventType?: string } = {},
  ): Promise<C9Record[]> {
    const { limit = 50, offset = 0, eventType } = options;

    let sql = `
      SELECT id, tenant_id, event_type, actor_uid, actor_role,
             subject_uid, subject_type, payload, hmac_signature,
             created_at, geo_lat, geo_lng, geo_accuracy_m, device_id, ip_address
      FROM lexops_truth_trail
      WHERE tenant_id = $1
    `;
    const params: (string | number)[] = [tenantId];

    if (eventType) {
      params.push(eventType);
      sql += ` AND event_type = $${params.length}`;
    }

    sql += ` ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(limit, offset);

    const result = await this.pool.query<Record<string, unknown>>(sql, params);
    return result.rows.map(this.mapRow);
  }

  /**
   * Verify integrity of a specific record using stored HMAC.
   */
  async verifyRecord(id: number): Promise<{ valid: boolean; recordId: number }> {
    const hmacSecret = process.env.C9_HMAC_SECRET;
    if (!hmacSecret) throw new Error('C9_HMAC_SECRET not set');

    const result = await this.pool.query<Record<string, unknown>>(
      'SELECT * FROM lexops_truth_trail WHERE id = $1',
      [id],
    );
    if (!result.rows.length) return { valid: false, recordId: id };

    const row = result.rows[0];
    const raw = `${row['tenant_id']}|${row['event_type']}|${JSON.stringify(row['payload'])}|${(row['created_at'] as Date).toISOString()}`;
    const computed = crypto.createHmac('sha256', hmacSecret).update(raw).digest('hex');
    return { valid: computed === row['hmac_signature'], recordId: id };
  }

  private mapRow(row: Record<string, unknown>): C9Record {
    return {
      id: row['id'] as number,
      tenantId: row['tenant_id'] as string,
      eventType: row['event_type'] as string,
      actorUid: row['actor_uid'] as string,
      actorRole: row['actor_role'] as string,
      subjectUid: row['subject_uid'] as string | undefined,
      subjectType: row['subject_type'] as string | undefined,
      payload: row['payload'] as Record<string, unknown>,
      hmacSignature: row['hmac_signature'] as string,
      createdAt: row['created_at'] as Date,
      geoLat: row['geo_lat'] as number | undefined,
      geoLng: row['geo_lng'] as number | undefined,
      geoAccuracyM: row['geo_accuracy_m'] as number | undefined,
      deviceId: row['device_id'] as string | undefined,
      ipAddress: row['ip_address'] as string | undefined,
    };
  }
}
