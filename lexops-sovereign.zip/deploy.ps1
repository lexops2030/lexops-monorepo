# ═══════════════════════════════════════════════════════════════════════════════
#  LexOps — Sovereign Deployment Script (PowerShell)
#  المشروع: gen-lang-client-0154024574
#  الاستخدام: .\deploy.ps1
#  المتطلبات: gcloud CLI + firebase CLI مثبّتان
# ═══════════════════════════════════════════════════════════════════════════════

param(
    [string]$Step = "all"   # all | backend | frontend | secrets
)

$PROJECT_ID   = "gen-lang-client-0154024574"
$REGION       = "me-central2"
$SERVICE_NAME = "lexops-api"
$REGISTRY     = "me-central2-docker.pkg.dev"
$IMAGE        = "$REGISTRY/$PROJECT_ID/lexops/api-service"

Write-Host ""
Write-Host "  ██╗     ███████╗██╗  ██╗ ██████╗ ██████╗ ███████╗" -ForegroundColor DarkYellow
Write-Host "  ██║     ██╔════╝╚██╗██╔╝██╔═══██╗██╔══██╗██╔════╝" -ForegroundColor DarkYellow
Write-Host "  ██║     █████╗   ╚███╔╝ ██║   ██║██████╔╝███████╗" -ForegroundColor DarkYellow
Write-Host "  ██║     ██╔══╝   ██╔██╗ ██║   ██║██╔═══╝ ╚════██║" -ForegroundColor DarkYellow
Write-Host "  ███████╗███████╗██╔╝ ██╗╚██████╔╝██║     ███████║" -ForegroundColor DarkYellow
Write-Host "  ╚══════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚══════╝" -ForegroundColor DarkYellow
Write-Host "  Sovereign Legal OS — Deployment Pipeline" -ForegroundColor Cyan
Write-Host ""

# ── Helper functions ─────────────────────────────────────────────────────────

function Check-Tool($name) {
    if (-not (Get-Command $name -ErrorAction SilentlyContinue)) {
        Write-Host "  [ERROR] '$name' غير مثبّت. راجع DEPLOY.md للتعليمات." -ForegroundColor Red
        exit 1
    }
}

function Step-Header($title) {
    Write-Host ""
    Write-Host "  ┌─────────────────────────────────────────" -ForegroundColor DarkCyan
    Write-Host "  │  $title" -ForegroundColor Cyan
    Write-Host "  └─────────────────────────────────────────" -ForegroundColor DarkCyan
}

# ── Pre-flight checks ────────────────────────────────────────────────────────

Check-Tool "gcloud"
Check-Tool "docker"
Check-Tool "firebase"

Step-Header "التحقق من تسجيل الدخول في Google Cloud"
$account = gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>&1
if (-not $account) {
    Write-Host "  جارٍ تسجيل الدخول..." -ForegroundColor Yellow
    gcloud auth login
}
Write-Host "  الحساب النشط: $account" -ForegroundColor Green

gcloud config set project $PROJECT_ID | Out-Null
Write-Host "  المشروع: $PROJECT_ID" -ForegroundColor Green

# ── Step 1: Enable required APIs ────────────────────────────────────────────

if ($Step -eq "all" -or $Step -eq "setup") {
    Step-Header "تفعيل Google Cloud APIs"

    $apis = @(
        "run.googleapis.com",
        "cloudbuild.googleapis.com",
        "artifactregistry.googleapis.com",
        "secretmanager.googleapis.com",
        "firestore.googleapis.com",
        "aiplatform.googleapis.com"
    )

    foreach ($api in $apis) {
        Write-Host "  تفعيل $api..." -ForegroundColor Gray
        gcloud services enable $api --project=$PROJECT_ID | Out-Null
    }
    Write-Host "  تم تفعيل جميع الـ APIs" -ForegroundColor Green

    # Create Artifact Registry repo if not exists
    Step-Header "إنشاء Artifact Registry"
    $repoExists = gcloud artifacts repositories describe lexops --location=$REGION --project=$PROJECT_ID 2>&1
    if ($LASTEXITCODE -ne 0) {
        gcloud artifacts repositories create lexops `
            --repository-format=docker `
            --location=$REGION `
            --description="LexOps Docker Images" `
            --project=$PROJECT_ID
        Write-Host "  تم إنشاء repository: lexops" -ForegroundColor Green
    } else {
        Write-Host "  Repository موجود مسبقاً" -ForegroundColor Gray
    }

    # Configure Docker auth
    gcloud auth configure-docker "$REGION-docker.pkg.dev" --quiet
}

# ── Step 2: Deploy Backend (Cloud Run) ───────────────────────────────────────

if ($Step -eq "all" -or $Step -eq "backend") {
    Step-Header "بناء ونشر Backend (Cloud Run)"

    $SHA = (git rev-parse --short HEAD 2>&1)
    if ($LASTEXITCODE -ne 0) { $SHA = "latest" }

    Write-Host "  بناء صورة Docker..." -ForegroundColor Gray
    docker build `
        -t "${IMAGE}:${SHA}" `
        -t "${IMAGE}:latest" `
        -f apps/api-service/Dockerfile `
        .

    if ($LASTEXITCODE -ne 0) {
        Write-Host "  [ERROR] فشل بناء Docker image" -ForegroundColor Red
        exit 1
    }

    Write-Host "  رفع الصورة إلى Artifact Registry..." -ForegroundColor Gray
    docker push --all-tags $IMAGE

    Write-Host "  نشر على Cloud Run..." -ForegroundColor Gray
    gcloud run deploy $SERVICE_NAME `
        --image="${IMAGE}:${SHA}" `
        --region=$REGION `
        --platform=managed `
        --allow-unauthenticated `
        --port=8080 `
        --memory=1Gi `
        --cpu=1 `
        --min-instances=0 `
        --max-instances=10 `
        --concurrency=80 `
        --set-env-vars="NODE_ENV=production,PORT=8080" `
        --set-secrets="FIREBASE_SERVICE_ACCOUNT=FIREBASE_SERVICE_ACCOUNT:latest,GEMINI_API_KEY=GEMINI_API_KEY:latest,C9_HMAC_SECRET=C9_HMAC_SECRET:latest" `
        --project=$PROJECT_ID

    if ($LASTEXITCODE -eq 0) {
        $apiUrl = gcloud run services describe $SERVICE_NAME `
            --region=$REGION `
            --project=$PROJECT_ID `
            --format="value(status.url)"
        Write-Host ""
        Write-Host "  Backend URL: $apiUrl" -ForegroundColor Green
        $env:VITE_API_URL = $apiUrl
    }
}

# ── Step 3: Deploy Frontend (Firebase Hosting) ───────────────────────────────

if ($Step -eq "all" -or $Step -eq "frontend") {
    Step-Header "بناء ونشر Frontend (Firebase Hosting)"

    if (-not $env:VITE_API_URL) {
        $env:VITE_API_URL = gcloud run services describe $SERVICE_NAME `
            --region=$REGION `
            --project=$PROJECT_ID `
            --format="value(status.url)" 2>&1
    }

    $env:VITE_FIREBASE_PROJECT_ID = $PROJECT_ID

    Write-Host "  بناء React app..." -ForegroundColor Gray
    Set-Location apps/web-dashboard
    npm ci --silent
    npm run build

    if ($LASTEXITCODE -ne 0) {
        Write-Host "  [ERROR] فشل بناء Frontend" -ForegroundColor Red
        Set-Location ../..
        exit 1
    }
    Set-Location ../..

    Write-Host "  رفع إلى Firebase Hosting..." -ForegroundColor Gray
    firebase deploy --only hosting --project=$PROJECT_ID --non-interactive

    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "  Frontend URL: https://$PROJECT_ID.web.app" -ForegroundColor Green
    }
}

# ── Step 4: Add Secrets ───────────────────────────────────────────────────────

if ($Step -eq "secrets") {
    Step-Header "إضافة Secrets إلى Secret Manager"

    Write-Host "  ادخل القيم التالية (اضغط Enter للتخطي):" -ForegroundColor Yellow
    Write-Host ""

    $secrets = @{
        "FIREBASE_SERVICE_ACCOUNT" = "محتوى ملف service-account.json من Firebase Console"
        "GEMINI_API_KEY"           = "مفتاح API من https://aistudio.google.com"
        "C9_HMAC_SECRET"           = "قيمة عشوائية 64 حرف (سيتم توليدها تلقائياً)"
        "FIREBASE_TOKEN"           = "من: firebase login:ci"
    }

    foreach ($key in $secrets.Keys) {
        Write-Host "  [$key] — ${secrets[$key]}" -ForegroundColor Gray
        $value = Read-Host "  القيمة"
        if ($value -and $value.Length -gt 0) {
            # Generate random for C9_HMAC_SECRET if empty
            if ($key -eq "C9_HMAC_SECRET" -and $value -eq "auto") {
                $value = -join ((65..90) + (97..122) + (48..57) | Get-Random -Count 64 | ForEach-Object { [char]$_ })
                Write-Host "  تم توليد قيمة عشوائية: $value" -ForegroundColor Cyan
            }
            echo $value | gcloud secrets create $key --data-file=- --project=$PROJECT_ID 2>&1
            if ($LASTEXITCODE -ne 0) {
                echo $value | gcloud secrets versions add $key --data-file=- --project=$PROJECT_ID 2>&1
            }
            Write-Host "  [OK] $key" -ForegroundColor Green
        }
    }

    # Grant Cloud Run SA access to secrets
    $projectNumber = gcloud projects describe $PROJECT_ID --format="value(projectNumber)"
    $sa = "${projectNumber}-compute@developer.gserviceaccount.com"
    foreach ($key in $secrets.Keys) {
        gcloud secrets add-iam-policy-binding $key `
            --member="serviceAccount:$sa" `
            --role="roles/secretmanager.secretAccessor" `
            --project=$PROJECT_ID | Out-Null
    }
    Write-Host "  تم منح صلاحيات Cloud Run للوصول للـ Secrets" -ForegroundColor Green
}

# ── Summary ───────────────────────────────────────────────────────────────────

Write-Host ""
Write-Host "  ════════════════════════════════════════════" -ForegroundColor DarkYellow
Write-Host "  النشر مكتمل" -ForegroundColor Green
Write-Host "  Frontend : https://$PROJECT_ID.web.app" -ForegroundColor Cyan
Write-Host "  Backend  : https://lexops-api-XXXX-$REGION.run.app" -ForegroundColor Cyan
Write-Host "  Console  : https://console.cloud.google.com/run?project=$PROJECT_ID" -ForegroundColor Gray
Write-Host "  ════════════════════════════════════════════" -ForegroundColor DarkYellow
Write-Host ""
