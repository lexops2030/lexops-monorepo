/**
 * LexOps — Violations Repository  (Sprint 6 — Compliance Engine)
 *
 * Firestore path:
 *   /entities/{tenantId}/violations/{violationId}
 *
 * Violations are APPEND-ONLY by design — no deletes, no status rollbacks.
 * Every auto-generated violation is sealed in C9 by ComplianceService after creation.
 *
 * Key method: findRecentByEmployee(tenantId, employeeId, windowDays)
 *   Used by the 180-Day Recurrence Rule (إدارة التكرار والعود):
 *   Saudi Labor Law mandates that a repeated violation within 180 days
 *   triggers escalated severity and a heavier penalty multiplier.
 */

import { Injectable, Inject } from '@nestjs/common';
import { Firestore, FieldValue, Timestamp } from '@google-cloud/firestore';
import { randomUUID } from 'crypto';

// ── Types ─────────────────────────────────────────────────────────────────────

export type ViolationType =
  | 'unauthorized_absence'      // غياب بدون إذن
  | 'repeated_lateness'         // تأخر متكرر
  | 'early_departure'           // مغادرة مبكرة
  | 'geofence_breach'           // خروج عن النطاق الجغرافي
  | 'policy_breach'             // مخالفة لوائح داخلية
  | 'insubordination'           // عصيان أوامر
  | 'misconduct'                // سلوك مخالف
  | 'attendance_fraud';         // تلاعب بسجلات الحضور

export type ViolationSeverity  = 'minor' | 'moderate' | 'serious' | 'gross';
export type ViolationSource    = 'auto_rule' | 'manual_admin' | 'lexi_inference';
export type ViolationStatus    = 'open' | 'contested' | 'resolved' | 'escalated';

export interface ViolationPenalty {
  type:        'warning' | 'deduction' | 'suspension' | 'termination_notice';
  description: string;
  deductionSar?: number;        // For type='deduction'
  suspensionDays?: number;      // For type='suspension'
}

export interface ViolationDocument {
  violationId:     string;
  tenantId:        string;
  employeeId:      string;
  branchId?:       string;
  violationType:   ViolationType;
  severity:        ViolationSeverity;
  source:          ViolationSource;
  status:          ViolationStatus;
  ruleId?:         string;       // The JSON Logic rule that fired (if auto_rule)
  isRepeated:      boolean;      // true if a similar violation was found in the last 180 days
  priorViolationId?: string;     // ID of the most recent prior violation of same type
  daysSincePrior?: number;       // Days since the prior violation (for audit trail)
  penalty:         ViolationPenalty;
  description:     string;       // Human-readable Arabic description
  evidenceRefs:    string[];     // Attendance record IDs, leave IDs, etc.
  resolvedBy?:     string;
  resolvedAt?:     FirebaseFirestore.Timestamp;
  resolutionNote?: string;
  createdAt:       FirebaseFirestore.Timestamp;
  updatedAt:       FirebaseFirestore.Timestamp;
  createdBy:       string;       // 'system' for auto_rule, admin UID otherwise
}

// ── Repository ────────────────────────────────────────────────────────────────

@Injectable()
export class ViolationsRepository {
  constructor(@Inject('FIRESTORE') private readonly db: Firestore) {}

  private violRef(tenantId: string, violationId: string) {
    return this.db
      .collection('entities').doc(tenantId)
      .collection('violations').doc(violationId);
  }

  private violCol(tenantId: string) {
    return this.db.collection('entities').doc(tenantId).collection('violations');
  }

  // ── Create ───────────────────────────────────────────────────────────────────

  async create(
    tenantId: string,
    data: Omit<ViolationDocument, 'violationId' | 'tenantId' | 'createdAt' | 'updatedAt'>,
  ): Promise<ViolationDocument> {
    const violationId = `viol_${randomUUID().replace(/-/g, '').slice(0, 14)}`;

    const doc: ViolationDocument = {
      ...data,
      violationId,
      tenantId,
      createdAt: FieldValue.serverTimestamp() as unknown as FirebaseFirestore.Timestamp,
      updatedAt: FieldValue.serverTimestamp() as unknown as FirebaseFirestore.Timestamp,
    };

    await this.violRef(tenantId, violationId).set(doc);
    return doc;
  }

  // ── Queries ───────────────────────────────────────────────────────────────────

  async findById(tenantId: string, violationId: string): Promise<ViolationDocument | null> {
    const snap = await this.violRef(tenantId, violationId).get();
    return snap.exists ? (snap.data() as ViolationDocument) : null;
  }

  /**
   * findRecentByEmployee — 180-Day Recurrence Rule
   *
   * Returns all violations for a given employee created within the past `windowDays` days.
   * Used by ComplianceService to build the disciplinary context before executing a rule:
   *   - If a matching violationType exists within the window → isRepeated = true
   *   - Severity escalates from 'minor' → 'moderate' → 'serious' → 'gross'
   *   - Penalty multiplier increases per repetition tier
   *
   * @param tenantId   Fortress 700 entity ID
   * @param employeeId Target employee UID
   * @param windowDays Lookback window (180 for Saudi Labor Law recurrence rule)
   * @param filterType Optional — restrict to a specific violation type
   */
  async findRecentByEmployee(
    tenantId:    string,
    employeeId:  string,
    windowDays:  number,
    filterType?: ViolationType,
  ): Promise<ViolationDocument[]> {
    const cutoffMs  = Date.now() - windowDays * 86_400_000;
    const cutoffTs  = Timestamp.fromMillis(cutoffMs);

    let query = this.violCol(tenantId)
      .where('employeeId', '==', employeeId)
      .where('createdAt', '>=', cutoffTs)
      .orderBy('createdAt', 'desc') as FirebaseFirestore.Query;

    if (filterType) {
      query = query.where('violationType', '==', filterType);
    }

    const snap = await query.limit(100).get();
    return snap.docs.map(d => d.data() as ViolationDocument);
  }

  /**
   * findByEmployee — full history (paginated).
   * Used by the admin dashboard violation log.
   */
  async findByEmployee(
    tenantId:   string,
    employeeId: string,
    limit = 50,
  ): Promise<ViolationDocument[]> {
    const snap = await this.violCol(tenantId)
      .where('employeeId', '==', employeeId)
      .orderBy('createdAt', 'desc')
      .limit(limit)
      .get();
    return snap.docs.map(d => d.data() as ViolationDocument);
  }

  /**
   * findOpenByTenant — all open violations for admin review board.
   */
  async findOpenByTenant(tenantId: string, limit = 100): Promise<ViolationDocument[]> {
    const snap = await this.violCol(tenantId)
      .where('status', 'in', ['open', 'contested'])
      .orderBy('createdAt', 'desc')
      .limit(limit)
      .get();
    return snap.docs.map(d => d.data() as ViolationDocument);
  }

  /**
   * Count violations by type for a given employee within a window.
   * Used to determine escalation tier without fetching full docs.
   */
  async countRecentByType(
    tenantId:    string,
    employeeId:  string,
    violationType: ViolationType,
    windowDays:  number,
  ): Promise<number> {
    const records = await this.findRecentByEmployee(
      tenantId, employeeId, windowDays, violationType,
    );
    return records.length;
  }

  // ── Mutations (status only — no field overwrites) ──────────────────────────

  async resolve(
    tenantId:      string,
    violationId:   string,
    resolvedBy:    string,
    resolutionNote: string,
  ): Promise<void> {
    await this.violRef(tenantId, violationId).update({
      status:         'resolved',
      resolvedBy,
      resolutionNote,
      resolvedAt:     FieldValue.serverTimestamp(),
      updatedAt:      FieldValue.serverTimestamp(),
    });
  }

  async escalate(tenantId: string, violationId: string): Promise<void> {
    await this.violRef(tenantId, violationId).update({
      status:    'escalated',
      updatedAt: FieldValue.serverTimestamp(),
    });
  }

  async markContested(tenantId: string, violationId: string): Promise<void> {
    await this.violRef(tenantId, violationId).update({
      status:    'contested',
      updatedAt: FieldValue.serverTimestamp(),
    });
  }
}
