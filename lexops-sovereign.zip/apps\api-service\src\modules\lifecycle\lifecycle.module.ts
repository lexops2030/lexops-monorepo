import { Module } from '@nestjs/common';
import { LifecycleRepository } from './lifecycle.repository';
import { LifecycleService } from './lifecycle.service';
import { LifecycleController } from './lifecycle.controller';

@Module({
  providers: [LifecycleRepository, LifecycleService],
  controllers: [LifecycleController],
  exports: [LifecycleService, LifecycleRepository],
})
export class LifecycleModule {}
