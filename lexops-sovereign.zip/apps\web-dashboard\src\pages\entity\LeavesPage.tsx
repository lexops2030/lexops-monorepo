import { useState } from 'react';
import { CalendarDays, CalendarCheck } from 'lucide-react';
import LeaveRequestForm from './leaves/LeaveRequestForm';
import LeaveReviewBoard from './leaves/LeaveReviewBoard';
import { cn } from '../../lib/utils';

type Tab = 'request' | 'review';

export default function LeavesPage() {
  const [tab, setTab] = useState<Tab>('request');

  const tabs: { key: Tab; label: string; icon: typeof CalendarDays }[] = [
    { key: 'request', label: 'طلب إجازة',         icon: CalendarDays },
    { key: 'review',  label: 'مراجعة الطلبات',   icon: CalendarCheck },
  ];

  return (
    <div>
      {/* ── Tab Switcher ── */}
      <div className="mb-8 flex gap-1 rounded-xl bg-neutral-100 p-1 max-w-md">
        {tabs.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={cn(
              'flex flex-1 items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-semibold transition-all duration-200',
              tab === key
                ? 'bg-white text-primary shadow-card'
                : 'text-neutral-500 hover:text-neutral-700',
            )}
          >
            <Icon className="h-4 w-4" />
            {label}
          </button>
        ))}
      </div>

      {tab === 'request' && <LeaveRequestForm />}
      {tab === 'review'  && <LeaveReviewBoard />}
    </div>
  );
}
