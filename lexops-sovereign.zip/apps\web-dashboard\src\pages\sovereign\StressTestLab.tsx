/**
 * StressTestLab.tsx — مختبر اختبار الإجهاد السيادي
 * Founder-restricted performance & scaling dashboard
 */

import { useState, useEffect, useRef } from 'react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, RadialBarChart, RadialBar, Cell,
} from 'recharts';
import {
  Activity, Zap, Brain, MapPin, Play, RefreshCw,
  CheckCircle2, AlertCircle, TrendingUp, Server,
} from 'lucide-react';

// ── Sovereign Theme ───────────────────────────────────────────────────────────

const S = {
  bg900:   '#05060d',
  bg800:   '#0b1121',
  bg700:   '#0f1729',
  bg600:   '#162035',
  border:  '#1e2d4a',
  gold:    '#C8A96B',
  goldDim: '#9A7F45',
  red:     '#f87171',
  green:   '#34d399',
  blue:    '#60a5fa',
  purple:  '#a78bfa',
  text:    '#e2e8f0',
  muted:   '#64748b',
  amber:   '#fbbf24',
};

// ── Types ─────────────────────────────────────────────────────────────────────

interface MetricConfig {
  id:       string;
  label:    string;
  labelEn:  string;
  peak:     number;
  unit:     string;
  icon:     React.ReactNode;
  color:    string;
  bgColor:  string;
}

type SimStatus = 'idle' | 'running' | 'complete';

// ── Throughput timeline data (60-second simulated load wave) ─────────────────

const TIMELINE_DATA = Array.from({ length: 61 }, (_, i) => {
  const t = i / 60;
  const wave = Math.sin(t * Math.PI) * 0.85 + Math.sin(t * Math.PI * 3) * 0.1 + 0.05;
  return {
    sec:        i,
    users:      Math.round(wave * 5000),
    writes:     Math.round(wave * 10000),
    inferences: Math.round(wave * 500),
    ticks:      Math.round(wave * 2000),
  };
});

// ── Radial gauge component ────────────────────────────────────────────────────

function RadialGauge({
  value, peak, color, size = 88,
}: { value: number; peak: number; color: string; size?: number }) {
  const pct   = Math.min((value / peak) * 100, 100);
  const data  = [{ value: pct }, { value: 100 - pct }];
  return (
    <RadialBarChart
      width={size} height={size}
      cx={size / 2} cy={size / 2}
      innerRadius={size * 0.32} outerRadius={size * 0.48}
      startAngle={225} endAngle={-45}
      data={data}
    >
      <RadialBar dataKey="value" cornerRadius={4} background={{ fill: S.border }}>
        <Cell fill={color} />
        <Cell fill="transparent" />
      </RadialBar>
    </RadialBarChart>
  );
}

// ── Metric card ───────────────────────────────────────────────────────────────

function MetricCard({
  cfg, current,
}: { cfg: MetricConfig; current: number }) {
  const pct = Math.round((current / cfg.peak) * 100);

  return (
    <div
      style={{
        background:   S.bg700,
        border:       `1px solid ${S.border}`,
        borderRadius: 16,
        padding:      24,
        display:      'flex',
        flexDirection:'column',
        gap:          12,
        transition:   'border-color 0.3s',
      }}
    >
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <p style={{ color: S.muted, fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 4 }}>
            {cfg.labelEn}
          </p>
          <p style={{ color: S.text, fontSize: 13, fontWeight: 600 }}>{cfg.label}</p>
        </div>
        <div style={{
          background: cfg.bgColor, borderRadius: 10, padding: '8px',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          {cfg.icon}
        </div>
      </div>

      {/* Value + Gauge */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <p style={{
            color: cfg.color, fontSize: 32, fontWeight: 800,
            fontFamily: 'IBM Plex Mono, monospace', lineHeight: 1,
          }}>
            {current.toLocaleString('en')}
          </p>
          <p style={{ color: S.muted, fontSize: 11, marginTop: 4 }}>{cfg.unit}</p>
        </div>
        <RadialGauge value={current} peak={cfg.peak} color={cfg.color} />
      </div>

      {/* Progress bar */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
          <span style={{ color: S.muted, fontSize: 10 }}>0</span>
          <span style={{ color: cfg.color, fontSize: 10, fontWeight: 700 }}>{pct}% of peak</span>
          <span style={{ color: S.muted, fontSize: 10 }}>{cfg.peak.toLocaleString('en')}</span>
        </div>
        <div style={{ background: S.border, borderRadius: 99, height: 4, overflow: 'hidden' }}>
          <div style={{
            background:   cfg.color,
            width:        `${pct}%`,
            height:       '100%',
            borderRadius: 99,
            transition:   'width 0.08s linear',
            boxShadow:    `0 0 8px ${cfg.color}80`,
          }} />
        </div>
      </div>
    </div>
  );
}

// ── Custom tooltip for timeline ───────────────────────────────────────────────

function TimelineTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: S.bg600, border: `1px solid ${S.border}`,
      borderRadius: 10, padding: '10px 14px', fontSize: 12,
    }}>
      <p style={{ color: S.muted, marginBottom: 6 }}>ثانية {label}</p>
      {payload.map((p: any) => (
        <p key={p.name} style={{ color: p.color, margin: '2px 0' }}>
          {p.name}: <strong>{p.value.toLocaleString('en')}</strong>
        </p>
      ))}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────

export function StressTestLab() {
  const [status,   setStatus]   = useState<SimStatus>('idle');
  const [currents, setCurrents] = useState([0, 0, 0, 0]);
  const [elapsed,  setElapsed]  = useState(0);
  const [lastRun,  setLastRun]  = useState<string | null>(null);
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const frameRef = useRef(0);

  const PEAK_VALUES = [5000, 10000, 500, 2000];

  const METRICS: MetricConfig[] = [
    {
      id: 'users', label: 'مستخدمون متزامنون', labelEn: 'Concurrent Users',
      peak: 5000,   unit: 'users active',
      icon: <Activity size={18} color={S.green} />,
      color: S.green, bgColor: '#34d39920',
    },
    {
      id: 'writes', label: 'كتابات Firestore', labelEn: 'Firestore Writes',
      peak: 10000,  unit: 'writes / sec',
      icon: <Server size={18} color={S.blue} />,
      color: S.blue, bgColor: '#60a5fa20',
    },
    {
      id: 'lexi', label: 'استدلالات LEXI AI', labelEn: 'LEXI AI Inferences',
      peak: 500,    unit: 'inferences / min',
      icon: <Brain size={18} color={S.purple} />,
      color: S.purple, bgColor: '#a78bfa20',
    },
    {
      id: 'ticks', label: 'نبضات Geofencing', labelEn: 'Geofence Ticks',
      peak: 2000,   unit: 'ticks / sec',
      icon: <MapPin size={18} color={S.amber} />,
      color: S.amber, bgColor: '#fbbf2420',
    },
  ];

  const runSimulation = () => {
    if (status === 'running') return;
    setStatus('running');
    setElapsed(0);
    frameRef.current = 0;

    tickRef.current = setInterval(() => {
      frameRef.current += 1;
      const t    = Math.min(frameRef.current / 60, 1);
      const wave = Math.sin(t * Math.PI) * 0.92 + Math.random() * 0.08;
      setCurrents(PEAK_VALUES.map(p => Math.min(Math.round(wave * p), p)));
      setElapsed(frameRef.current);

      if (frameRef.current >= 60) {
        clearInterval(tickRef.current!);
        setCurrents(PEAK_VALUES);
        setStatus('complete');
        setLastRun(new Date().toLocaleString('ar-SA'));
      }
    }, 80);
  };

  useEffect(() => () => { if (tickRef.current) clearInterval(tickRef.current); }, []);

  const resetSim = () => {
    if (tickRef.current) clearInterval(tickRef.current);
    setStatus('idle');
    setCurrents([0, 0, 0, 0]);
    setElapsed(0);
  };

  const statusConfig = {
    idle:     { label: 'STANDBY',    color: S.muted,  dot: S.muted  },
    running:  { label: 'SIMULATING', color: S.amber,  dot: S.amber  },
    complete: { label: 'PEAK REACHED', color: S.green, dot: S.green },
  }[status];

  return (
    <div dir="rtl" style={{ background: S.bg900, minHeight: '100vh', fontFamily: 'Cairo, IBM Plex Sans Arabic, sans-serif', color: S.text, padding: 32 }}>
      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 32 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
            <div style={{ background: `${S.gold}20`, border: `1px solid ${S.gold}40`, borderRadius: 10, padding: '8px 14px', display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: statusConfig.dot, boxShadow: `0 0 8px ${statusConfig.dot}`, animation: status === 'running' ? 'pulse 1s infinite' : 'none' }} />
              <span style={{ color: statusConfig.color, fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', fontFamily: 'IBM Plex Mono, monospace' }}>
                {statusConfig.label}
              </span>
            </div>
            {lastRun && (
              <span style={{ color: S.muted, fontSize: 11 }}>آخر تشغيل: {lastRun}</span>
            )}
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 800, color: S.text, margin: 0 }}>
            مختبر اختبار الإجهاد
          </h1>
          <p style={{ color: S.muted, fontSize: 13, marginTop: 4 }}>
            Peak Hour Simulation Lab — LexOps Sovereign Performance Monitor
          </p>
        </div>

        <div style={{ display: 'flex', gap: 10 }}>
          {status !== 'idle' && (
            <button onClick={resetSim} style={{ background: S.bg700, border: `1px solid ${S.border}`, borderRadius: 10, padding: '10px 18px', color: S.muted, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, fontFamily: 'inherit' }}>
              <RefreshCw size={15} /> إعادة تعيين
            </button>
          )}
          <button
            onClick={runSimulation}
            disabled={status === 'running'}
            style={{
              background:    status === 'running' ? S.bg700 : `linear-gradient(135deg, ${S.gold}, ${S.goldDim})`,
              border:        `1px solid ${status === 'running' ? S.border : S.gold}`,
              borderRadius:  10,
              padding:       '10px 22px',
              color:         status === 'running' ? S.muted : S.bg900,
              cursor:        status === 'running' ? 'not-allowed' : 'pointer',
              fontWeight:    700,
              fontSize:      14,
              display:       'flex',
              alignItems:    'center',
              gap:           8,
              fontFamily:    'inherit',
              boxShadow:     status !== 'running' ? `0 4px 20px ${S.gold}40` : 'none',
              transition:    'all 0.2s',
            }}
          >
            <Play size={15} />
            {status === 'running' ? `جارٍ المحاكاة… (${elapsed}s)` : 'تشغيل محاكاة الذروة'}
          </button>
        </div>
      </div>

      {/* ── Metric Cards ───────────────────────────────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 28 }}>
        {METRICS.map((cfg, i) => (
          <MetricCard key={cfg.id} cfg={cfg} current={currents[i]} />
        ))}
      </div>

      {/* ── Throughput Timeline ────────────────────────────────────────────── */}
      <div style={{ background: S.bg700, border: `1px solid ${S.border}`, borderRadius: 16, padding: 28, marginBottom: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
          <TrendingUp size={18} color={S.gold} />
          <h2 style={{ color: S.text, fontSize: 16, fontWeight: 700, margin: 0 }}>
            خط زمني لعبء التشغيل — 60 ثانية
          </h2>
          <span style={{ color: S.muted, fontSize: 11, marginRight: 'auto' }}>Throughput Timeline</span>
        </div>

        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={TIMELINE_DATA} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
            <defs>
              {[
                { id: 'gUsers',  color: S.green  },
                { id: 'gWrites', color: S.blue   },
                { id: 'gLexi',   color: S.purple },
                { id: 'gTicks',  color: S.amber  },
              ].map(g => (
                <linearGradient key={g.id} id={g.id} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor={g.color} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={g.color} stopOpacity={0}   />
                </linearGradient>
              ))}
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke={S.border} />
            <XAxis dataKey="sec" stroke={S.muted} tick={{ fill: S.muted, fontSize: 10 }} tickFormatter={v => `${v}s`} />
            <YAxis stroke={S.muted} tick={{ fill: S.muted, fontSize: 10 }} />
            <Tooltip content={<TimelineTooltip />} />
            <Area type="monotone" dataKey="users"      name="Users"      stroke={S.green}  fill="url(#gUsers)"  strokeWidth={1.5} dot={false} />
            <Area type="monotone" dataKey="writes"     name="Writes"     stroke={S.blue}   fill="url(#gWrites)" strokeWidth={1.5} dot={false} />
            <Area type="monotone" dataKey="inferences" name="Inferences" stroke={S.purple} fill="url(#gLexi)"   strokeWidth={1.5} dot={false} />
            <Area type="monotone" dataKey="ticks"      name="Ticks"      stroke={S.amber}  fill="url(#gTicks)"  strokeWidth={1.5} dot={false} />
          </AreaChart>
        </ResponsiveContainer>

        {/* Legend */}
        <div style={{ display: 'flex', gap: 24, justifyContent: 'center', marginTop: 14, flexWrap: 'wrap' }}>
          {[
            { color: S.green,  label: 'المستخدمون' },
            { color: S.blue,   label: 'كتابات Firestore' },
            { color: S.purple, label: 'LEXI Inferences' },
            { color: S.amber,  label: 'Geofence Ticks' },
          ].map(l => (
            <div key={l.label} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 24, height: 3, borderRadius: 99, background: l.color }} />
              <span style={{ color: S.muted, fontSize: 11 }}>{l.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ── Completion Badge ───────────────────────────────────────────────── */}
      {status === 'complete' && (
        <div style={{ background: `${S.green}12`, border: `1px solid ${S.green}40`, borderRadius: 12, padding: '14px 20px', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 12 }}>
          <CheckCircle2 size={20} color={S.green} />
          <div>
            <p style={{ color: S.green, fontWeight: 700, fontSize: 14, margin: 0 }}>المحاكاة مكتملة — تم الوصول إلى ذروة التحميل</p>
            <p style={{ color: S.muted, fontSize: 11, margin: '2px 0 0' }}>Peak simulation complete — all metrics at 100% capacity</p>
          </div>
        </div>
      )}

      {/* ── LEXI Recommendation Banner ─────────────────────────────────────── */}
      <div style={{
        background:   `linear-gradient(135deg, ${S.gold}22, ${S.goldDim}15)`,
        border:       `1px solid ${S.gold}50`,
        borderRadius: 16,
        padding:      28,
        position:     'relative',
        overflow:     'hidden',
      }}>
        <div style={{ position: 'absolute', top: -20, left: -20, width: 120, height: 120, background: `${S.gold}10`, borderRadius: '50%', filter: 'blur(30px)' }} />
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16, position: 'relative' }}>
          <div style={{ background: `${S.gold}25`, border: `1px solid ${S.gold}50`, borderRadius: 12, padding: 12, flexShrink: 0 }}>
            <Brain size={24} color={S.gold} />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
              <span style={{ color: S.gold, fontWeight: 800, fontSize: 14 }}>توصية LEXI السيادية</span>
              <span style={{ background: `${S.gold}30`, border: `1px solid ${S.gold}50`, borderRadius: 99, padding: '2px 10px', color: S.gold, fontSize: 10, fontWeight: 700, letterSpacing: '0.06em' }}>AI VERIFIED</span>
            </div>
            <p style={{ color: S.text, fontSize: 15, lineHeight: 1.8, margin: 0, fontWeight: 500 }}>
              "النظام جاهز للتوسع حتى{' '}
              <span style={{ color: S.gold, fontWeight: 800 }}>200 منشأة</span>{' '}
              دون الحاجة لتغيير البنية التحتية بفضل خاصية الـ{' '}
              <span style={{ color: S.gold, fontWeight: 800, fontFamily: 'IBM Plex Mono, monospace' }}>Auto-scaling</span>{' '}
              في Cloud Functions — مع الحفاظ على عزل بيانات كل منشأة (Fortress 700) وسلامة سجل C9 اللامتغير."
            </p>
            <div style={{ display: 'flex', gap: 20, marginTop: 14, flexWrap: 'wrap' }}>
              {[
                { label: 'الاستعداد', value: '100%', color: S.green },
                { label: 'السعة المتاحة', value: '200 منشأة', color: S.gold },
                { label: 'زمن الاستجابة P95', value: '< 200ms', color: S.blue },
                { label: 'معدل الخطأ', value: '0.00%', color: S.green },
              ].map(m => (
                <div key={m.label}>
                  <p style={{ color: S.muted, fontSize: 10, margin: 0 }}>{m.label}</p>
                  <p style={{ color: m.color, fontSize: 16, fontWeight: 800, fontFamily: 'IBM Plex Mono, monospace', margin: '2px 0 0' }}>{m.value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
      `}</style>
    </div>
  );
}

export default StressTestLab;
