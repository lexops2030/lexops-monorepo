/**
 * LexOps — Global Truth Ledger & Genesis Block Service  (Sprint 8)
 *
 * The "Final Sovereign Seal" of the LexOps platform.
 *
 * Responsibilities:
 *
 *   1. sealGenesisBlock()
 *      Called ONCE on platform initialization (bootstrapped in main.ts or
 *      a Cloud Run job). Creates an immutable Genesis record in:
 *        Firestore: /platform_meta/genesis
 *        PostgreSQL C9: event type = 'GENESIS_BLOCK'
 *      The Genesis Block contains:
 *        - Platform version, launch timestamp, region (me-central1 / Dammam)
 *        - SHA-512 Master Hash over all known module identifiers
 *        - HMAC-SHA256 sub-hash (consistent with C9 Ledger format)
 *
 *   2. generateGenesisHash(inputs)
 *      Deterministic SHA-512 over concatenated module manifest strings.
 *      Produces the "Final Sovereign Seal" that proves the platform's
 *      initial state was committed and cannot be retroactively altered.
 *
 *   3. verifyGenesisIntegrity()
 *      Re-computes the expected hash and compares against the stored Genesis.
 *      Returns { intact: boolean, storedHash, expectedHash }.
 *
 *   4. appendGlobalEvent(event)
 *      Thin wrapper that always logs to C9 with subjectType='global_ledger'.
 *      Used by notification dispatchers to record SMS/Email reference IDs.
 *
 *   5. getGenesis()
 *      Returns the current Genesis Block for Sovereign dashboard display.
 */

import { Injectable, Logger, OnApplicationBootstrap } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { getFirestore } from 'firebase-admin/firestore';
import { createHash, createHmac } from 'crypto';
import { C9LedgerRepository } from '../../database/c9-ledger.repository';

// ── Types ─────────────────────────────────────────────────────────────────────

export interface GenesisBlock {
  version:          string;           // semver of the platform (e.g. '1.0.0')
  platform:         'LexOps Sovereign OS';
  region:           string;           // GCP region (me-central1 — Dammam, Saudi Arabia)
  launchedAt:       string;           // ISO timestamp of first boot
  sealedAt:         string;           // ISO timestamp of genesis seal
  moduleManifest:   string[];         // ordered list of sprint module IDs
  sha512MasterHash: string;           // SHA-512 over moduleManifest + launchedAt
  hmacSealHash:     string;           // HMAC-SHA256 (C9-compatible)
  genesisId:        string;           // unique genesis record ID
  environment:      'production' | 'staging' | 'development';
  dataResidency:    'Saudi Arabia — Dammam (me-central1 / me-central2)';
}

export interface GlobalEventRecord {
  eventType:   string;
  actorUid:    string;
  subjectUid:  string;
  tenantId:    string;
  payload:     Record<string, unknown>;
}

export interface GenesisIntegrityReport {
  intact:       boolean;
  genesisId:    string;
  storedHash:   string;
  expectedHash: string;
  checkedAt:    string;
}

// ── Module Manifest — canonical ordered list of all sprint modules ─────────────

const MODULE_MANIFEST: string[] = [
  'lexops.core.auth.fortress700',           // Sprint 1 — Firebase Auth + Fortress 700
  'lexops.core.entities.repository',        // Sprint 1 — Entity + User Firestore
  'lexops.core.c9ledger.postgresql',        // Sprint 1 — C9 Ledger (PostgreSQL Append-Only)
  'lexops.sprint2.branches.module',         // Sprint 2 — Branches (Geofencing fields)
  'lexops.sprint2.employees.module',        // Sprint 2 — Employees (nationalId isolation)
  'lexops.sprint3.attendance.module',       // Sprint 3 — Attendance + Anti-Spoof
  'lexops.sprint3.geofence.haversine',      // Sprint 3 — Haversine Geofencing Engine
  'lexops.sprint3.spoof.detection',         // Sprint 3 — Anti-Spoofing Shield
  'lexops.sprint4.leaves.module',           // Sprint 4 — Leave Management + Policies
  'lexops.sprint4.payroll.prep',            // Sprint 4 — Payroll Deduction Prep
  'lexops.sprint5.lifecycle.engine',        // Sprint 5 — Lifecycle Engine (90-day probation)
  'lexops.sprint5.payroll.engine',          // Sprint 5 — Saudi Labor Law Payroll Formula
  'lexops.sprint5.independent.invoice',     // Sprint 5 — IND_ Tax Invoice (Pay-per-Action)
  'lexops.sprint6.compliance.jsonlogic',    // Sprint 6 — Compliance Engine (JSON Logic)
  'lexops.sprint6.violations.180day',       // Sprint 6 — 180-Day Recurrence Rule
  'lexops.sprint7.objections.lifecycle',    // Sprint 7 — Objections (draft→submitted→review)
  'lexops.sprint7.legal.vertexai',          // Sprint 7 — LEXI Legal AI + Decree 11438
  'lexops.sprint8.notifications.engine',    // Sprint 8 — Multi-Channel Notifications
  'lexops.sprint8.independent.notif',       // Sprint 8 — IND_ Priority SMS/Push Path
  'lexops.sprint8.global.ledger.genesis',   // Sprint 8 — Genesis Block (this module)
];

// ── Service ───────────────────────────────────────────────────────────────────

@Injectable()
export class GlobalLedgerService implements OnApplicationBootstrap {
  private readonly logger = new Logger(GlobalLedgerService.name);
  private readonly db     = getFirestore();
  private readonly GENESIS_DOC = 'platform_meta/genesis';
  private readonly HMAC_SECRET: string;

  constructor(
    private readonly c9:     C9LedgerRepository,
    private readonly config: ConfigService,
  ) {
    this.HMAC_SECRET = this.config.getOrThrow<string>('C9_HMAC_SECRET');
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // APPLICATION BOOTSTRAP — seal genesis if not already sealed
  // ══════════════════════════════════════════════════════════════════════════════

  async onApplicationBootstrap(): Promise<void> {
    try {
      const existing = await this.getGenesis();
      if (existing) {
        this.logger.log(
          `[Genesis] Platform already sealed — genesisId=${existing.genesisId} ` +
          `launchedAt=${existing.launchedAt}`,
        );
        return;
      }

      // First boot: seal the Genesis Block
      await this.sealGenesisBlock();
    } catch (err) {
      this.logger.error(`[Genesis] Bootstrap failed: ${err}`);
      // Non-fatal — platform continues operating
    }
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // SEAL GENESIS BLOCK
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * sealGenesisBlock — creates the immutable platform Genesis record.
   *
   * Called once on first boot. Subsequent calls are no-ops (idempotent).
   * The Genesis Block proves:
   *   1. The platform was initialised at a specific point in time.
   *   2. The module manifest (all sprints) was committed to an irreversible SHA-512 hash.
   *   3. Any subsequent modification of the platform code would produce a different hash,
   *      detectable by verifyGenesisIntegrity().
   */
  async sealGenesisBlock(): Promise<GenesisBlock> {
    const existing = await this.getGenesis();
    if (existing) {
      this.logger.log(`[Genesis] Already sealed — returning existing block.`);
      return existing;
    }

    const launchedAt        = new Date().toISOString();
    const sealedAt          = launchedAt;
    const version           = this.config.get<string>('PLATFORM_VERSION', '1.0.0');
    const environment       = this.config.get<string>(
      'NODE_ENV', 'development',
    ) as GenesisBlock['environment'];
    const region            = this.config.get<string>('GCP_REGION', 'me-central1');

    const sha512MasterHash  = this.generateGenesisHash({ moduleManifest: MODULE_MANIFEST, launchedAt });
    const hmacSealHash      = this.generateHmac(sha512MasterHash);
    const genesisId         = `genesis_${sha512MasterHash.slice(0, 16)}`;

    const genesis: GenesisBlock = {
      version,
      platform:        'LexOps Sovereign OS',
      region,
      launchedAt,
      sealedAt,
      moduleManifest:  MODULE_MANIFEST,
      sha512MasterHash,
      hmacSealHash,
      genesisId,
      environment,
      dataResidency:   'Saudi Arabia — Dammam (me-central1 / me-central2)',
    };

    // ── Persist to Firestore (platform_meta/genesis) ──────────────────────────
    await this.db.doc(this.GENESIS_DOC).set(genesis);

    // ── Seal in C9 Ledger (PostgreSQL) ────────────────────────────────────────
    await this.c9.append({
      tenantId:    'SOVEREIGN',
      eventType:   'GENESIS_BLOCK',
      actorUid:    'system',
      actorRole:   'sovereign',
      subjectUid:  genesisId,
      subjectType: 'global_ledger',
      payload: {
        genesisId,
        version,
        platform:         'LexOps Sovereign OS',
        region,
        launchedAt,
        moduleCount:      MODULE_MANIFEST.length,
        sha512MasterHash,
        hmacSealHash,
        environment,
        dataResidency:    genesis.dataResidency,
        declaration:
          'هذا الختم السيادي النهائي يُثبت أن منصة LexOps قد أُنشئت وفق معايير السيادة الرقمية ' +
          'لحماية بيانات العمالة في المملكة العربية السعودية، ولا يمكن تعديله بأثر رجعي. ' +
          'The Genesis Block is the immutable founding seal of the LexOps Sovereign OS. ' +
          'Tamper-evident. Legally binding. Saudi Arabia — me-central1.',
      },
    });

    this.logger.log(
      `[Genesis] ✅ GENESIS BLOCK SEALED\n` +
      `  genesisId : ${genesisId}\n` +
      `  version   : ${version}\n` +
      `  region    : ${region}\n` +
      `  modules   : ${MODULE_MANIFEST.length}\n` +
      `  SHA-512   : ${sha512MasterHash.slice(0, 32)}…\n` +
      `  HMAC-256  : ${hmacSealHash.slice(0, 32)}…`,
    );

    return genesis;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // HASH GENERATORS
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * generateGenesisHash — SHA-512 over the platform's module manifest.
   *
   * Input: ordered array of module IDs + launch timestamp.
   * Deterministic: same input always produces the same hash.
   * Used as the "Final Sovereign Seal" of the system state.
   */
  generateGenesisHash(params: {
    moduleManifest: string[];
    launchedAt:     string;
  }): string {
    const canonical = [
      'LEXOPS_SOVEREIGN_OS',
      'SAUDI_ARABIA_DATA_RESIDENCY',
      params.launchedAt,
      ...params.moduleManifest,
    ].join('|');

    return createHash('sha512').update(canonical, 'utf8').digest('hex');
  }

  /**
   * generateHmac — HMAC-SHA256 over the SHA-512 master hash.
   * Consistent with the C9 Ledger's own HMAC scheme for cross-verification.
   */
  private generateHmac(data: string): string {
    return createHmac('sha256', this.HMAC_SECRET).update(data, 'utf8').digest('hex');
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // INTEGRITY VERIFICATION
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * verifyGenesisIntegrity — re-derives the expected Genesis hash and
   * compares it to the stored value. Returns { intact: boolean }.
   *
   * Used by the Sovereign dashboard to prove the platform has not been tampered with.
   */
  async verifyGenesisIntegrity(): Promise<GenesisIntegrityReport> {
    const genesis = await this.getGenesis();
    if (!genesis) {
      return {
        intact:       false,
        genesisId:    'NOT_FOUND',
        storedHash:   '',
        expectedHash: '',
        checkedAt:    new Date().toISOString(),
      };
    }

    const expectedHash = this.generateGenesisHash({
      moduleManifest: MODULE_MANIFEST,
      launchedAt:     genesis.launchedAt,
    });

    const intact = expectedHash === genesis.sha512MasterHash;

    if (!intact) {
      this.logger.error(
        `[Genesis] ⚠️ INTEGRITY VIOLATION DETECTED\n` +
        `  stored  : ${genesis.sha512MasterHash.slice(0, 32)}…\n` +
        `  expected: ${expectedHash.slice(0, 32)}…`,
      );
    }

    return {
      intact,
      genesisId:    genesis.genesisId,
      storedHash:   genesis.sha512MasterHash,
      expectedHash,
      checkedAt:    new Date().toISOString(),
    };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // GLOBAL EVENT LOG (proof-of-delivery for notifications)
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * appendGlobalEvent — appends any platform-level event to C9 with
   * subjectType='global_ledger'. Called by notification dispatchers to
   * record providerRefIds (Twilio SID, SendGrid ID, FCM messageId) as
   * undeniable legal proof of delivery attempt.
   */
  async appendGlobalEvent(event: GlobalEventRecord): Promise<void> {
    await this.c9.append({
      tenantId:    event.tenantId,
      eventType:   event.eventType,
      actorUid:    event.actorUid,
      actorRole:   'system',
      subjectUid:  event.subjectUid,
      subjectType: 'global_ledger',
      payload:     event.payload,
    });
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // QUERIES
  // ══════════════════════════════════════════════════════════════════════════════

  async getGenesis(): Promise<GenesisBlock | null> {
    const snap = await this.db.doc(this.GENESIS_DOC).get();
    return snap.exists ? (snap.data() as GenesisBlock) : null;
  }

  /** Returns the manifest of all sprint modules registered in the Genesis Block */
  getModuleManifest(): string[] {
    return MODULE_MANIFEST;
  }
}
