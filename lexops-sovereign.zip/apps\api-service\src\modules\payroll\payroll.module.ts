import { Module, forwardRef } from '@nestjs/common';
import { PayrollRepository } from './payroll.repository';
import { PayrollService } from './payroll.service';
import { PayrollController, IndependentPayrollController } from './payroll.controller';
import { LeavesModule } from '../leaves/leaves.module';
import { DatabaseModule } from '../../database/database.module';

@Module({
  imports: [
    DatabaseModule,                     // Firestore + PostgreSQL (C9 Ledger)
    forwardRef(() => LeavesModule),     // LeavesService.calculateLeaveDeductions()
  ],
  providers:   [PayrollRepository, PayrollService],
  controllers: [PayrollController, IndependentPayrollController],
  exports:     [PayrollService, PayrollRepository],
})
export class PayrollModule {}
