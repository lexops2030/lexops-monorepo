/**
 * LexOps — Personal Vault Repository
 *
 * Manages the private Firestore sub-collection for Independent Workers (IND_ tenants).
 * Data path: /users/{uid}/personal_vault/profile
 *            /users/{uid}/personal_vault/violations/{violationId}
 *            /users/{uid}/personal_vault/documents/{docId}
 *
 * Key design rules:
 *  - NEVER reads from or writes to /entities/** — complete isolation from org data.
 *  - trust_score (0–10) is managed here and surfaced to LEXI for Advocacy Mode.
 *  - All mutations are C9-sealed with subjectType = 'personal_vault'.
 */

import { Injectable, NotFoundException } from '@nestjs/common';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { randomUUID } from 'crypto';

// ── Types ─────────────────────────────────────────────────────────────────────

export type WorkerStatus = 'active' | 'suspended' | 'probation' | 'terminated';

export interface IndependentWorkerProfile {
  uid:               string;
  displayName:       string;
  nationalId:        string;
  phone?:            string;
  email?:            string;
  occupation?:       string;
  trust_score:       number;          // 0–10; starts at 5, adjusted by platform events
  status:            WorkerStatus;
  dataConsentGiven:  boolean;         // Must be true before sharing any data with entities
  createdAt:         FirebaseFirestore.Timestamp;
  updatedAt:         FirebaseFirestore.Timestamp;
}

export interface PersonalVaultViolation {
  violationId:    string;
  caseType:       'absence' | 'lateness' | 'misconduct' | 'termination' | 'grievance';
  entityRef?:     string;             // Optional — filled only with explicit consent
  description:    string;
  evidenceUrls:   string[];
  lexiVerdict?:   string;
  lexiDraftUrl?:  string;
  uploadedAt:     FirebaseFirestore.Timestamp;
  status:         'pending_review' | 'lexi_analyzed' | 'objection_filed' | 'resolved';
}

export interface PersonalVaultDocument {
  docId:       string;
  docType:     'contract' | 'payslip' | 'warning_letter' | 'iqama' | 'other';
  fileUrl:     string;
  description: string;
  uploadedAt:  FirebaseFirestore.Timestamp;
}

// ── Repository ────────────────────────────────────────────────────────────────

@Injectable()
export class PersonalVaultRepository {
  private db = getFirestore();

  // ── Profile ─────────────────────────────────────────────────────────────────

  private profileRef(uid: string) {
    return this.db
      .collection('users')
      .doc(uid)
      .collection('personal_vault')
      .doc('profile');
  }

  async getProfile(uid: string): Promise<IndependentWorkerProfile | null> {
    const snap = await this.profileRef(uid).get();
    return snap.exists ? (snap.data() as IndependentWorkerProfile) : null;
  }

  async upsertProfile(
    uid: string,
    data: Partial<Omit<IndependentWorkerProfile, 'uid' | 'createdAt'>>,
  ): Promise<IndependentWorkerProfile> {
    const ref = this.profileRef(uid);
    const now = FieldValue.serverTimestamp() as unknown as FirebaseFirestore.Timestamp;

    const existing = await ref.get();

    if (existing.exists) {
      await ref.update({ ...data, updatedAt: now });
    } else {
      await ref.set({
        uid,
        trust_score:      5,        // Default — neutral start
        status:           'active',
        dataConsentGiven: false,
        createdAt:        now,
        updatedAt:        now,
        ...data,
      });
    }

    const updated = await ref.get();
    return updated.data() as IndependentWorkerProfile;
  }

  /**
   * Adjust trust_score by delta (positive or negative), clamped to [0, 10].
   * Called by LEXI or system events (e.g., objection filed = +0.5, violation ignored = -1).
   */
  async adjustTrustScore(uid: string, delta: number, reason: string): Promise<number> {
    const ref     = this.profileRef(uid);
    const snap    = await ref.get();
    if (!snap.exists) throw new NotFoundException(`Personal vault not found for uid: ${uid}`);

    const current = (snap.data() as IndependentWorkerProfile).trust_score ?? 5;
    const next    = Math.min(10, Math.max(0, current + delta));

    await ref.update({
      trust_score: next,
      updatedAt: FieldValue.serverTimestamp(),
      [`trust_score_history.${Date.now()}`]: { delta, reason, from: current, to: next },
    });

    return next;
  }

  /**
   * Grant or revoke consent to share vault data with an entity.
   * LEXI Personal Advocate mode checks this before any cross-entity disclosure.
   */
  async setDataConsent(uid: string, consent: boolean): Promise<void> {
    await this.profileRef(uid).update({
      dataConsentGiven: consent,
      updatedAt: FieldValue.serverTimestamp(),
    });
  }

  // ── Violations ──────────────────────────────────────────────────────────────

  private violationsRef(uid: string) {
    return this.db
      .collection('users')
      .doc(uid)
      .collection('personal_vault')
      .doc('violations')
      .collection('items');
  }

  async addViolation(
    uid: string,
    data: Omit<PersonalVaultViolation, 'violationId' | 'uploadedAt'>,
  ): Promise<PersonalVaultViolation> {
    const violationId = randomUUID();
    const doc: PersonalVaultViolation = {
      ...data,
      violationId,
      uploadedAt: FieldValue.serverTimestamp() as unknown as FirebaseFirestore.Timestamp,
    };
    await this.violationsRef(uid).doc(violationId).set(doc);
    return doc;
  }

  async listViolations(uid: string): Promise<PersonalVaultViolation[]> {
    const snap = await this.violationsRef(uid).orderBy('uploadedAt', 'desc').get();
    return snap.docs.map(d => d.data() as PersonalVaultViolation);
  }

  async updateViolationStatus(
    uid: string,
    violationId: string,
    update: Partial<Pick<PersonalVaultViolation, 'lexiVerdict' | 'lexiDraftUrl' | 'status'>>,
  ): Promise<void> {
    await this.violationsRef(uid).doc(violationId).update(update);
  }

  // ── Documents ───────────────────────────────────────────────────────────────

  private documentsRef(uid: string) {
    return this.db
      .collection('users')
      .doc(uid)
      .collection('personal_vault')
      .doc('documents')
      .collection('items');
  }

  async addDocument(
    uid: string,
    data: Omit<PersonalVaultDocument, 'docId' | 'uploadedAt'>,
  ): Promise<PersonalVaultDocument> {
    const docId = randomUUID();
    const doc: PersonalVaultDocument = {
      ...data,
      docId,
      uploadedAt: FieldValue.serverTimestamp() as unknown as FirebaseFirestore.Timestamp,
    };
    await this.documentsRef(uid).doc(docId).set(doc);
    return doc;
  }

  async listDocuments(uid: string): Promise<PersonalVaultDocument[]> {
    const snap = await this.documentsRef(uid).orderBy('uploadedAt', 'desc').get();
    return snap.docs.map(d => d.data() as PersonalVaultDocument);
  }
}
