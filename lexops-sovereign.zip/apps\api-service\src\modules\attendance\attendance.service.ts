import {
  Injectable, Logger,
  ConflictException, NotFoundException,
  ForbiddenException, Inject, forwardRef,
} from '@nestjs/common';
import { AttendanceRepository, AttendanceRecord, AttendanceReview } from './attendance.repository';
import { BranchesRepository } from '../branches/branches.repository';
import { GeofenceService } from './geofence.service';
import { AntiSpoofService } from './spoof.service';
import { C9LedgerRepository } from '../../database/c9-ledger.repository';
import { LeavesService } from '../leaves/leaves.service';
import { randomUUID } from 'crypto';

// ── Input shapes ──────────────────────────────────────────────────────────────

export interface CheckInInput {
  employeeUid: string;
  branchId: string;
  lat: number;
  lng: number;
  accuracy: number;
  isMock: boolean;
  deviceTimestampMs: number;
  deviceId?: string;
  ipAddress?: string;
}

export interface ReviewInput {
  adminUid: string;
  decision: 'accepted' | 'rejected';
  reason: string;
}

@Injectable()
export class AttendanceService {
  private readonly logger = new Logger(AttendanceService.name);

  constructor(
    private readonly attendanceRepo: AttendanceRepository,
    private readonly branchesRepo: BranchesRepository,
    private readonly geofenceService: GeofenceService,
    private readonly antiSpoofService: AntiSpoofService,
    private readonly c9: C9LedgerRepository,
    @Inject(forwardRef(() => LeavesService))
    private readonly leavesService: LeavesService,
  ) {}

  // ══════════════════════════════════════════════════════════════════════════════
  // CHECK-IN
  // ══════════════════════════════════════════════════════════════════════════════

  async checkIn(tenantId: string, input: CheckInInput): Promise<AttendanceRecord> {
    // ── 1. Fetch branch geofence config ──────────────────────────────────────
    const branch = await this.branchesRepo.findById(tenantId, input.branchId);
    if (!branch) {
      throw new NotFoundException(
        `Branch '${input.branchId}' not found in entity '${tenantId}'`,
      );
    }

    // ── 1b. Leave integration — block check-in during approved leave ─────────
    const todayDate = new Date().toISOString().slice(0, 10);
    const leaveCheck = await this.leavesService.isDateOnApprovedLeave(
      tenantId,
      input.employeeUid,
      todayDate,
    );

    if (leaveCheck.onLeave && leaveCheck.leave) {
      const leave = leaveCheck.leave;
      throw new ForbiddenException(
        `[إجازة معتمدة] لا يمكن تسجيل الحضور. ` +
        `الموظف في إجازة ${leave.leaveType} معتمدة من ${leave.startDate} حتى ${leave.endDate} ` +
        `(${leave.daysRequested} يوم). رقم الإجازة: ${leave.leaveId}.`,
      );
    }

    // ── 2. Anti-spoof: fetch last known position ─────────────────────────────
    const lastCheckIn = await this.attendanceRepo.findLatestCheckIn(
      tenantId, input.employeeUid,
    );

    const spoofResult = this.antiSpoofService.check({
      isMock:              input.isMock,
      lat:                 input.lat,
      lng:                 input.lng,
      deviceTimestampMs:   input.deviceTimestampMs,
      previousLat:         lastCheckIn?.lat ?? null,
      previousLng:         lastCheckIn?.lng ?? null,
      previousTimestampMs: lastCheckIn?.deviceTimestampMs ?? null,
    });

    // ── 3. Geofence verification ─────────────────────────────────────────────
    const geoResult = this.geofenceService.verify({
      employeeLat:  input.lat,
      employeeLng:  input.lng,
      accuracy:     input.accuracy,
      branchLat:    branch.geofence.lat,
      branchLng:    branch.geofence.lng,
      radiusMeters: branch.geofence.radiusMeters,
    });

    // ── 4. Determine final status ────────────────────────────────────────────
    // Spoof suspicion always escalates to pending_review (never overrides rejected)
    let finalStatus: AttendanceRecord['status'] = geoResult.verdict;
    if (spoofResult.isMockSuspected && finalStatus === 'accepted') {
      finalStatus = 'pending_review';
    }

    // ── 5. Persist record ────────────────────────────────────────────────────
    const recordId = `ck_${randomUUID().replace(/-/g, '').slice(0, 16)}`;
    const serverTimestampMs = Date.now();

    const record = await this.attendanceRepo.create(tenantId, recordId, {
      employeeUid:       input.employeeUid,
      branchId:          input.branchId,
      eventType:         'check_in',
      status:            finalStatus,
      lat:               input.lat,
      lng:               input.lng,
      accuracy:          input.accuracy,
      distanceMeters:    geoResult.distanceMeters,
      isMock:            input.isMock,
      isMockSuspected:   spoofResult.isMockSuspected,
      spoofReason:       spoofResult.triggerReason,
      geofenceReason:    geoResult.reason,
      velocityMps:       spoofResult.velocityMps,
      deviceId:          input.deviceId,
      deviceTimestampMs: input.deviceTimestampMs,
      serverTimestampMs,
      ipAddress:         input.ipAddress,
    });

    // ── 6. C9 Seal: ATTENDANCE_CHECK_IN ──────────────────────────────────────
    await this.c9.append({
      tenantId,
      eventType:   'ATTENDANCE_CHECK_IN',
      actorUid:    input.employeeUid,
      actorRole:   'employee',
      subjectUid:  input.employeeUid,
      subjectType: 'attendance_record',
      payload: {
        recordId,
        branchId:        input.branchId,
        status:          finalStatus,
        distanceMeters:  geoResult.distanceMeters,
        radiusMeters:    branch.geofence.radiusMeters,
        accuracy:        input.accuracy,
        isMockSuspected: spoofResult.isMockSuspected,
      },
      geoLat:       input.lat,
      geoLng:       input.lng,
      geoAccuracyM: Math.round(input.accuracy),
      deviceId:     input.deviceId,
      ipAddress:    input.ipAddress,
    });

    // ── 7. C9 Seal: ATTENDANCE_SPOOF_SUSPECTED (conditional) ─────────────────
    if (spoofResult.isMockSuspected) {
      await this.c9.append({
        tenantId,
        eventType:   'ATTENDANCE_SPOOF_SUSPECTED',
        actorUid:    input.employeeUid,
        actorRole:   'employee',
        subjectUid:  recordId,
        subjectType: 'attendance_record',
        payload: {
          recordId,
          isMock:      input.isMock,
          velocityMps: spoofResult.velocityMps,
          reason:      spoofResult.triggerReason,
        },
        geoLat:    input.lat,
        geoLng:    input.lng,
        deviceId:  input.deviceId,
        ipAddress: input.ipAddress,
      });

      this.logger.warn(
        `[AntiSpoof] Suspected — tenant=${tenantId} employee=${input.employeeUid} record=${recordId}`,
      );
    }

    return record;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // CHECK-OUT
  // ══════════════════════════════════════════════════════════════════════════════

  async checkOut(
    tenantId: string,
    input: Omit<CheckInInput, 'branchId'>,
  ): Promise<AttendanceRecord> {
    const openCheckIn = await this.attendanceRepo.findOpenCheckIn(tenantId, input.employeeUid);
    if (!openCheckIn) {
      throw new ConflictException(
        `لا يوجد تسجيل حضور مفتوح للموظف '${input.employeeUid}'. يجب تسجيل الحضور أولاً.`,
      );
    }

    const branch = await this.branchesRepo.findById(tenantId, openCheckIn.branchId);
    if (!branch) throw new NotFoundException(`Branch '${openCheckIn.branchId}' not found`);

    const geoResult = this.geofenceService.verify({
      employeeLat:  input.lat,
      employeeLng:  input.lng,
      accuracy:     input.accuracy,
      branchLat:    branch.geofence.lat,
      branchLng:    branch.geofence.lng,
      radiusMeters: branch.geofence.radiusMeters,
    });

    const spoofResult = this.antiSpoofService.check({
      isMock:              input.isMock,
      lat:                 input.lat,
      lng:                 input.lng,
      deviceTimestampMs:   input.deviceTimestampMs,
      previousLat:         openCheckIn.lat,
      previousLng:         openCheckIn.lng,
      previousTimestampMs: openCheckIn.deviceTimestampMs,
    });

    let finalStatus: AttendanceRecord['status'] = geoResult.verdict;
    if (spoofResult.isMockSuspected && finalStatus === 'accepted') {
      finalStatus = 'pending_review';
    }

    const recordId = `co_${randomUUID().replace(/-/g, '').slice(0, 16)}`;

    const record = await this.attendanceRepo.create(tenantId, recordId, {
      employeeUid:       input.employeeUid,
      branchId:          openCheckIn.branchId,
      eventType:         'check_out',
      status:            finalStatus,
      lat:               input.lat,
      lng:               input.lng,
      accuracy:          input.accuracy,
      distanceMeters:    geoResult.distanceMeters,
      isMock:            input.isMock,
      isMockSuspected:   spoofResult.isMockSuspected,
      spoofReason:       spoofResult.triggerReason,
      geofenceReason:    geoResult.reason,
      velocityMps:       spoofResult.velocityMps,
      deviceId:          input.deviceId,
      deviceTimestampMs: input.deviceTimestampMs,
      serverTimestampMs: Date.now(),
      ipAddress:         input.ipAddress,
    });

    await this.c9.append({
      tenantId,
      eventType:   'ATTENDANCE_CHECK_OUT',
      actorUid:    input.employeeUid,
      actorRole:   'employee',
      subjectUid:  input.employeeUid,
      subjectType: 'attendance_record',
      payload: {
        recordId,
        checkInRecordId:  openCheckIn.recordId,
        branchId:         openCheckIn.branchId,
        status:           finalStatus,
        distanceMeters:   geoResult.distanceMeters,
        isMockSuspected:  spoofResult.isMockSuspected,
      },
      geoLat:       input.lat,
      geoLng:       input.lng,
      geoAccuracyM: Math.round(input.accuracy),
      deviceId:     input.deviceId,
      ipAddress:    input.ipAddress,
    });

    return record;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // REVIEW WORKFLOW — entity_admin only
  // ══════════════════════════════════════════════════════════════════════════════

  async reviewRecord(
    tenantId: string,
    recordId: string,
    input: ReviewInput,
  ): Promise<{ message: string }> {
    const record = await this.attendanceRepo.findById(tenantId, recordId);
    if (!record) {
      throw new NotFoundException(
        `Attendance record '${recordId}' not found in entity '${tenantId}'`,
      );
    }

    if (record.status !== 'pending_review') {
      throw new ConflictException(
        `السجل '${recordId}' بحالة '${record.status}' — لا يمكن مراجعة سجل غير معلق.`,
      );
    }

    const review: AttendanceReview = {
      reviewedBy: input.adminUid,
      reviewedAt: { toDate: () => new Date() } as FirebaseFirestore.Timestamp,
      decision:   input.decision,
      reason:     input.reason,
    };

    await this.attendanceRepo.applyReview(tenantId, recordId, review);

    // ── C9 Seal: REVIEW_ACCEPTED or REVIEW_REJECTED ───────────────────────────
    await this.c9.append({
      tenantId,
      eventType: input.decision === 'accepted'
        ? 'ATTENDANCE_REVIEW_ACCEPTED'
        : 'ATTENDANCE_REVIEW_REJECTED',
      actorUid:    input.adminUid,
      actorRole:   'entity_admin',
      subjectUid:  recordId,
      subjectType: 'attendance_record',
      payload: {
        recordId,
        employeeUid:     record.employeeUid,
        branchId:        record.branchId,
        originalStatus:  'pending_review',
        newStatus:       input.decision,
        reason:          input.reason,
        isMockSuspected: record.isMockSuspected,
        distanceMeters:  record.distanceMeters,
      },
    });

    return {
      message: `تم ${input.decision === 'accepted' ? 'قبول' : 'رفض'} السجل '${recordId}' وختمه في سجل C9.`,
    };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // QUERIES
  // ══════════════════════════════════════════════════════════════════════════════

  getPendingReview(tenantId: string) {
    return this.attendanceRepo.findPendingReview(tenantId);
  }

  getEmployeeHistory(tenantId: string, employeeUid: string) {
    return this.attendanceRepo.findByEmployee(tenantId, employeeUid);
  }
}
