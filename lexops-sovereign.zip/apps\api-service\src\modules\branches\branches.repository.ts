import { Injectable, Inject, ConflictException, NotFoundException } from '@nestjs/common';
import { Firestore, FieldValue } from '@google-cloud/firestore';

// ── Branch Document Shape ─────────────────────────────────────────────────────

export interface GeofenceConfig {
  lat: number;           // Latitude — WGS-84
  lng: number;           // Longitude — WGS-84
  radiusMeters: number;  // Allowed check-in radius in meters (min: 50, max: 5000)
}

export interface BranchDocument {
  branchId: string;
  tenantId: string;         // Entity 700-series — Fortress 700 primary key
  name: string;
  nameEn?: string;
  city: string;
  address: string;
  geofence: GeofenceConfig;
  managerUid?: string;
  isActive: boolean;
  employeeCount: number;
  createdAt: FirebaseFirestore.Timestamp;
  updatedAt: FirebaseFirestore.Timestamp;
  createdBy: string;        // Actor UID — immutable
}

// ── Repository ────────────────────────────────────────────────────────────────

@Injectable()
export class BranchesRepository {
  constructor(@Inject('FIRESTORE') private readonly db: Firestore) {}

  private branchRef(tenantId: string, branchId: string) {
    return this.db
      .collection('entities').doc(tenantId)
      .collection('branches').doc(branchId);
  }

  private branchesCol(tenantId: string) {
    return this.db.collection('entities').doc(tenantId).collection('branches');
  }

  async findById(tenantId: string, branchId: string): Promise<BranchDocument | null> {
    const snap = await this.branchRef(tenantId, branchId).get();
    return snap.exists ? (snap.data() as BranchDocument) : null;
  }

  async findAllByTenant(tenantId: string): Promise<BranchDocument[]> {
    const snap = await this.branchesCol(tenantId)
      .where('isActive', '==', true)
      .orderBy('createdAt', 'asc')
      .get();
    return snap.docs.map((d) => d.data() as BranchDocument);
  }

  async exists(tenantId: string, branchId: string): Promise<boolean> {
    const snap = await this.branchRef(tenantId, branchId).get();
    return snap.exists;
  }

  async create(
    tenantId: string,
    branchId: string,
    data: Omit<BranchDocument, 'branchId' | 'tenantId' | 'createdAt' | 'updatedAt' | 'employeeCount'>,
  ): Promise<BranchDocument> {
    const ref = this.branchRef(tenantId, branchId);
    const existing = await ref.get();

    if (existing.exists) {
      throw new ConflictException(
        `Branch '${branchId}' already exists in tenant '${tenantId}'`,
      );
    }

    const doc: BranchDocument = {
      ...data,
      branchId,
      tenantId,
      employeeCount: 0,
      createdAt: FieldValue.serverTimestamp() as FirebaseFirestore.Timestamp,
      updatedAt: FieldValue.serverTimestamp() as FirebaseFirestore.Timestamp,
    };

    await ref.set(doc);
    return doc;
  }

  async update(
    tenantId: string,
    branchId: string,
    data: Partial<Omit<BranchDocument, 'branchId' | 'tenantId' | 'createdAt' | 'createdBy'>>,
  ): Promise<void> {
    const ref = this.branchRef(tenantId, branchId);
    const snap = await ref.get();
    if (!snap.exists) {
      throw new NotFoundException(`Branch '${branchId}' not found in tenant '${tenantId}'`);
    }
    await ref.update({ ...data, updatedAt: FieldValue.serverTimestamp() });
  }

  /** Increment or decrement employee counter atomically */
  async adjustEmployeeCount(tenantId: string, branchId: string, delta: 1 | -1): Promise<void> {
    await this.branchRef(tenantId, branchId).update({
      employeeCount: FieldValue.increment(delta),
      updatedAt: FieldValue.serverTimestamp(),
    });
  }

  async deactivate(tenantId: string, branchId: string): Promise<void> {
    await this.update(tenantId, branchId, { isActive: false });
  }
}
