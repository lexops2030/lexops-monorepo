import {
  Controller, Get, Post, Patch,
  Param, Body, Request, Version,
  UseGuards, Ip,
} from '@nestjs/common';
import {
  ApiTags, ApiBearerAuth, ApiOperation,
  ApiParam, ApiBody,
} from '@nestjs/swagger';
import {
  IsBoolean, IsNotEmpty, IsNumber,
  IsOptional, IsString, IsEnum,
  Min, Max,
} from 'class-validator';
import { AttendanceService } from './attendance.service';
import { Roles } from '../auth/firebase.guard';
import { TenantScopeGuard } from '../../common/guards';
import { Request as ExpressRequest } from 'express';
import type { LexOpsClaims } from '../auth/firebase.guard';

// ── DTOs ──────────────────────────────────────────────────────────────────────

class CheckInDto {
  @IsString() @IsNotEmpty()
  branchId: string;

  @IsNumber() @Min(-90) @Max(90)
  lat: number;

  @IsNumber() @Min(-180) @Max(180)
  lng: number;

  @IsNumber() @Min(0)
  accuracy: number;

  @IsBoolean()
  isMock: boolean;

  @IsNumber() @Min(0)
  deviceTimestampMs: number;

  @IsString() @IsOptional()
  deviceId?: string;
}

class CheckOutDto {
  @IsNumber() @Min(-90) @Max(90)
  lat: number;

  @IsNumber() @Min(-180) @Max(180)
  lng: number;

  @IsNumber() @Min(0)
  accuracy: number;

  @IsBoolean()
  isMock: boolean;

  @IsNumber() @Min(0)
  deviceTimestampMs: number;

  @IsString() @IsOptional()
  deviceId?: string;
}

class ReviewDto {
  @IsEnum(['accepted', 'rejected'])
  decision: 'accepted' | 'rejected';

  @IsString() @IsNotEmpty()
  reason: string;
}

// ── Controller ────────────────────────────────────────────────────────────────

@ApiTags('Attendance — Geofencing & Anti-Spoofing')
@ApiBearerAuth('Firebase-JWT')
@Controller('entities/:tenantId/attendance')
@UseGuards(TenantScopeGuard)
export class AttendanceController {
  constructor(private readonly attendanceService: AttendanceService) {}

  // ── POST /check-in ──────────────────────────────────────────────────────────
  @Post('check-in')
  @Version('1')
  @Roles('employee', 'entity_admin', 'sovereign')
  @ApiOperation({
    summary: 'تسجيل حضور — يُشغّل Haversine + Anti-Spoof + C9 Seal',
  })
  @ApiParam({ name: 'tenantId' })
  checkIn(
    @Param('tenantId') tenantId: string,
    @Body() dto: CheckInDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
    @Ip() ipAddress: string,
  ) {
    return this.attendanceService.checkIn(tenantId, {
      employeeUid: req.user.uid,
      ...dto,
      ipAddress,
    });
  }

  // ── POST /check-out ─────────────────────────────────────────────────────────
  @Post('check-out')
  @Version('1')
  @Roles('employee', 'entity_admin', 'sovereign')
  @ApiOperation({
    summary: 'تسجيل انصراف — يُختم في C9 مع مرجع سجل الحضور',
  })
  checkOut(
    @Param('tenantId') tenantId: string,
    @Body() dto: CheckOutDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
    @Ip() ipAddress: string,
  ) {
    return this.attendanceService.checkOut(tenantId, {
      employeeUid: req.user.uid,
      ...dto,
      ipAddress,
    });
  }

  // ── GET /pending-review ──────────────────────────────────────────────────────
  @Get('pending-review')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({
    summary: 'جلب قائمة السجلات الميدانية المعلقة (pending_review) — للمدير فقط',
  })
  getPendingReview(@Param('tenantId') tenantId: string) {
    return this.attendanceService.getPendingReview(tenantId);
  }

  // ── GET /employee/:employeeUid ───────────────────────────────────────────────
  @Get('employee/:employeeUid')
  @Version('1')
  @Roles('entity_admin', 'sovereign', 'employee')
  @ApiOperation({ summary: 'سجل حضور موظف محدد' })
  getEmployeeHistory(
    @Param('tenantId') tenantId: string,
    @Param('employeeUid') employeeUid: string,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    // Employees can only read their own history
    const target = req.user.role === 'employee' ? req.user.uid : employeeUid;
    return this.attendanceService.getEmployeeHistory(tenantId, target);
  }

  // ── PATCH /:id/review ────────────────────────────────────────────────────────
  @Patch(':id/review')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({
    summary:
      'مراجعة سجل معلق (pending_review) — يقبل أو يرفض المدير مع سبب — مختوم في C9',
  })
  @ApiBody({ type: ReviewDto })
  reviewRecord(
    @Param('tenantId') tenantId: string,
    @Param('id') recordId: string,
    @Body() dto: ReviewDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.attendanceService.reviewRecord(tenantId, recordId, {
      adminUid:  req.user.uid,
      decision:  dto.decision,
      reason:    dto.reason,
    });
  }
}
