/**
 * LexOps — Anti-Spoofing Shield
 *
 * Detects two classes of location manipulation:
 *
 * 1. Mock Location Flag   — device reports isMock=true (developer/fake GPS app)
 * 2. Impossible Velocity  — position changed > 500m in < 1 second compared
 *                           to the employee's last known check-in record.
 *
 * When either trigger fires → isMockSuspected = true → record → pending_review
 */

import { Injectable, Logger } from '@nestjs/common';
import { GeofenceService } from './geofence.service';

export interface SpoofCheckInput {
  isMock: boolean;
  lat: number;
  lng: number;
  deviceTimestampMs: number;          // Unix epoch ms reported by device
  previousLat?: number | null;
  previousLng?: number | null;
  previousTimestampMs?: number | null;
}

export interface SpoofCheckResult {
  isMockSuspected: boolean;
  triggerReason: string | null;       // null if clean
  velocityMps: number | null;         // metres per second (null if no prior point)
}

// ── Constants ─────────────────────────────────────────────────────────────────
/** Maximum physically plausible travel speed (500 m/s ≈ 1800 km/h) */
const MAX_PLAUSIBLE_VELOCITY_MPS = 500;

@Injectable()
export class AntiSpoofService {
  private readonly logger = new Logger(AntiSpoofService.name);

  constructor(private readonly geofenceService: GeofenceService) {}

  /**
   * Run spoofing checks against incoming check-in data.
   * Returns a structured result — caller decides how to apply it.
   */
  check(input: SpoofCheckInput): SpoofCheckResult {
    // ── Check 1: Mock location flag ─────────────────────────────────────────
    if (input.isMock) {
      this.logger.warn(
        `[AntiSpoof] Mock location detected. lat=${input.lat}, lng=${input.lng}`,
      );
      return {
        isMockSuspected: true,
        triggerReason: 'تم اكتشاف موقع وهمي (isMock=true). محتمل استخدام تطبيق تزوير GPS.',
        velocityMps: null,
      };
    }

    // ── Check 2: Impossible velocity ────────────────────────────────────────
    if (
      input.previousLat != null &&
      input.previousLng != null &&
      input.previousTimestampMs != null
    ) {
      const deltaMs = input.deviceTimestampMs - input.previousTimestampMs;

      // Ignore negative or zero time delta (clock manipulation guard)
      if (deltaMs <= 0) {
        this.logger.warn(`[AntiSpoof] Non-positive time delta: ${deltaMs}ms`);
        return {
          isMockSuspected: true,
          triggerReason:
            'فارق زمني سلبي أو صفري مقارنةً بالسجل السابق. ' +
            'يُشير إلى تلاعب بساعة الجهاز.',
          velocityMps: null,
        };
      }

      const distanceMeters = this.geofenceService.computeDistance(
        input.previousLat,
        input.previousLng,
        input.lat,
        input.lng,
      );

      const deltaSeconds = deltaMs / 1000;
      const velocityMps  = distanceMeters / deltaSeconds;

      if (velocityMps > MAX_PLAUSIBLE_VELOCITY_MPS) {
        this.logger.warn(
          `[AntiSpoof] Impossible velocity: ${velocityMps.toFixed(1)} m/s ` +
          `(dist=${distanceMeters.toFixed(1)}m, dt=${deltaSeconds.toFixed(2)}s)`,
        );
        return {
          isMockSuspected: true,
          triggerReason:
            `سرعة انتقال مستحيلة: ${velocityMps.toFixed(1)} م/ث ` +
            `(${distanceMeters.toFixed(1)}م في ${deltaSeconds.toFixed(2)}ث). ` +
            `الحد الأقصى المقبول: ${MAX_PLAUSIBLE_VELOCITY_MPS} م/ث.`,
          velocityMps,
        };
      }

      return { isMockSuspected: false, triggerReason: null, velocityMps };
    }

    // ── No prior data point — cannot compute velocity ────────────────────────
    return { isMockSuspected: false, triggerReason: null, velocityMps: null };
  }
}
