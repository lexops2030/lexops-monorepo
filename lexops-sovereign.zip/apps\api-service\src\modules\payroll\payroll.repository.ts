/**
 * LexOps — Payroll Repository
 *
 * Dual data-path:
 *  - Entity payroll   → Firestore: /entities/{tenantId}/payroll_runs/{runId}
 *                                  /entities/{tenantId}/payroll_runs/{runId}/items/{employeeUid}
 *  - Independent invoice → Firestore: /users/{uid}/personal_vault/invoices/{invoiceId}
 *
 * Sovereign closing rule:
 *   Once a payroll_run reaches status='closed', the repository REJECTS
 *   any further mutations to the run or its items at the code level.
 *   No UPDATE/DELETE reaches Firestore for a closed run.
 *
 * Adjustments:
 *   Post-closing changes are stored in a separate sub-collection
 *   /entities/{tenantId}/payroll_runs/{runId}/adjustments/{adjustmentId}
 *   and carried forward to the next month's run automatically.
 */

import {
  Injectable, Inject,
  ConflictException, NotFoundException, ForbiddenException,
} from '@nestjs/common';
import { Firestore, FieldValue } from '@google-cloud/firestore';
import { randomUUID } from 'crypto';

// ── Types ─────────────────────────────────────────────────────────────────────

export type PayrollRunStatus = 'draft' | 'approved' | 'closed';

export interface PayrollItemBreakdown {
  baseSalary:         number;
  dailySalary:        number;  // baseSalary / 30
  hourlyRate:         number;  // dailySalary / 8
  absenceDays:        number;
  absenceDeduction:   number;  // absenceDays * dailySalary
  lateMinutes:        number;
  lateDeduction:      number;  // floor(lateMinutes/60) * (dailySalary/2)
  unpaidLeaveDays:    number;
  leaveDeduction:     number;  // unpaidLeaveDays * dailySalary
  overtimeHours:      number;
  overtimeAmount:     number;  // overtimeHours * hourlyRate * 1.5
  grossSalary:        number;  // baseSalary + overtimeAmount
  totalDeductions:    number;  // absenceDeduction + lateDeduction + leaveDeduction
  netSalary:          number;  // grossSalary - totalDeductions
}

export interface PayrollItem {
  employeeUid:    string;
  employeeName:   string;
  nationalId:     string;
  branchId:       string;
  position:       string;
  breakdown:      PayrollItemBreakdown;
  generatedAt:    FirebaseFirestore.Timestamp;
}

export interface PayrollAdjustment {
  adjustmentId:  string;
  employeeUid:   string;
  amount:        number;         // positive = bonus, negative = deduction
  reason:        string;
  addedBy:       string;
  carryForward:  boolean;        // carry to next month if true
  createdAt:     FirebaseFirestore.Timestamp;
}

export interface PayrollRun {
  runId:        string;
  tenantId:     string;
  month:        string;          // 'YYYY-MM'
  status:       PayrollRunStatus;
  totalNetSalary: number;
  employeeCount:  number;
  generatedBy:  string;
  approvedBy?:  string;
  closedBy?:    string;
  closedAt?:    FirebaseFirestore.Timestamp;
  approvedAt?:  FirebaseFirestore.Timestamp;
  createdAt:    FirebaseFirestore.Timestamp;
  updatedAt:    FirebaseFirestore.Timestamp;
}

export interface IndependentInvoice {
  invoiceId:       string;
  uid:             string;
  month:           string;
  documentedHours: number;
  hourlyRate:      number;
  totalPay:        number;        // documentedHours * hourlyRate
  vatRate:         number;        // e.g. 0.15 for 15% VAT
  vatAmount:       number;
  totalWithVat:    number;
  status:          'draft' | 'stamped' | 'paid';
  generatedAt:     FirebaseFirestore.Timestamp;
}

// ── Repository ────────────────────────────────────────────────────────────────

@Injectable()
export class PayrollRepository {
  constructor(@Inject('FIRESTORE') private readonly db: Firestore) {}

  // ══════════════════════════════════════════════════════════════════════════════
  // ENTITY PAYROLL RUNS
  // ══════════════════════════════════════════════════════════════════════════════

  private runRef(tenantId: string, runId: string) {
    return this.db
      .collection('entities').doc(tenantId)
      .collection('payroll_runs').doc(runId);
  }

  private runsCol(tenantId: string) {
    return this.db.collection('entities').doc(tenantId).collection('payroll_runs');
  }

  private itemRef(tenantId: string, runId: string, employeeUid: string) {
    return this.runRef(tenantId, runId).collection('items').doc(employeeUid);
  }

  private adjustmentsCol(tenantId: string, runId: string) {
    return this.runRef(tenantId, runId).collection('adjustments');
  }

  async findRunById(tenantId: string, runId: string): Promise<PayrollRun | null> {
    const snap = await this.runRef(tenantId, runId).get();
    return snap.exists ? (snap.data() as PayrollRun) : null;
  }

  async findRunByMonth(tenantId: string, month: string): Promise<PayrollRun | null> {
    const snap = await this.runsCol(tenantId)
      .where('month', '==', month)
      .limit(1)
      .get();
    return snap.empty ? null : (snap.docs[0].data() as PayrollRun);
  }

  async listRuns(tenantId: string, limit = 12): Promise<PayrollRun[]> {
    const snap = await this.runsCol(tenantId)
      .orderBy('month', 'desc')
      .limit(limit)
      .get();
    return snap.docs.map(d => d.data() as PayrollRun);
  }

  /**
   * Create a payroll run. Fails if a run for the same month already exists.
   */
  async createRun(
    tenantId: string,
    data: Omit<PayrollRun, 'runId' | 'createdAt' | 'updatedAt'>,
  ): Promise<PayrollRun> {
    const existing = await this.findRunByMonth(tenantId, data.month);
    if (existing) {
      throw new ConflictException(
        `يوجد مسير رواتب مسبق لشهر ${data.month} في المنشأة ${tenantId} ` +
        `(${existing.runId}). لا يمكن إنشاء مسير مكرر.`,
      );
    }

    const runId = `pr_${data.month.replace('-', '')}_${randomUUID().slice(0, 8)}`;
    const now   = FieldValue.serverTimestamp() as unknown as FirebaseFirestore.Timestamp;

    const run: PayrollRun = {
      ...data,
      runId,
      createdAt: now,
      updatedAt: now,
    };

    await this.runRef(tenantId, runId).set(run);
    return run;
  }

  /**
   * Upsert a single employee payroll item inside a run.
   * Blocks writes if the run is already closed.
   */
  async upsertItem(
    tenantId: string,
    runId: string,
    item: PayrollItem,
  ): Promise<void> {
    await this.assertNotClosed(tenantId, runId);
    await this.itemRef(tenantId, runId, item.employeeUid).set(item);
  }

  async listItems(tenantId: string, runId: string): Promise<PayrollItem[]> {
    const snap = await this.runRef(tenantId, runId).collection('items').get();
    return snap.docs.map(d => d.data() as PayrollItem);
  }

  async getItem(
    tenantId: string,
    runId: string,
    employeeUid: string,
  ): Promise<PayrollItem | null> {
    const snap = await this.itemRef(tenantId, runId, employeeUid).get();
    return snap.exists ? (snap.data() as PayrollItem) : null;
  }

  /**
   * Approve a payroll run (draft → approved).
   * Requires run to be in 'draft' state.
   */
  async approveRun(
    tenantId: string,
    runId: string,
    approvedBy: string,
  ): Promise<void> {
    const run = await this.assertExists(tenantId, runId);
    if (run.status !== 'draft') {
      throw new ConflictException(
        `مسير الرواتب '${runId}' بحالة '${run.status}' — لا يمكن اعتماده إلا وهو في وضع draft.`,
      );
    }

    await this.runRef(tenantId, runId).update({
      status:     'approved',
      approvedBy,
      approvedAt: FieldValue.serverTimestamp(),
      updatedAt:  FieldValue.serverTimestamp(),
    });
  }

  /**
   * Close a payroll run (approved → closed).
   * After closing, no further mutations are allowed on items.
   */
  async closeRun(
    tenantId: string,
    runId: string,
    closedBy: string,
  ): Promise<void> {
    const run = await this.assertExists(tenantId, runId);
    if (run.status === 'closed') {
      throw new ConflictException(
        `مسير الرواتب '${runId}' مغلق مسبقاً — لا يمكن إغلاقه مرتين.`,
      );
    }
    if (run.status !== 'approved') {
      throw new ConflictException(
        `مسير الرواتب '${runId}' يجب أن يكون معتمداً (approved) قبل الإغلاق.`,
      );
    }

    await this.runRef(tenantId, runId).update({
      status:   'closed',
      closedBy,
      closedAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });
  }

  // ── Adjustments ──────────────────────────────────────────────────────────────

  /**
   * Add a post-closing adjustment. The run MUST be closed first.
   * Adjustments are stored separately and do NOT modify closed items.
   */
  async addAdjustment(
    tenantId: string,
    runId: string,
    data: Omit<PayrollAdjustment, 'adjustmentId' | 'createdAt'>,
  ): Promise<PayrollAdjustment> {
    const run = await this.assertExists(tenantId, runId);
    if (run.status !== 'closed') {
      throw new ConflictException(
        `يمكن إضافة تسويات فقط على مسير مغلق. ` +
        `مسير '${runId}' بحالة '${run.status}'.`,
      );
    }

    const adjustmentId = `adj_${randomUUID().slice(0, 12)}`;
    const adj: PayrollAdjustment = {
      ...data,
      adjustmentId,
      createdAt: FieldValue.serverTimestamp() as unknown as FirebaseFirestore.Timestamp,
    };

    await this.adjustmentsCol(tenantId, runId).doc(adjustmentId).set(adj);
    return adj;
  }

  async listAdjustments(tenantId: string, runId: string): Promise<PayrollAdjustment[]> {
    const snap = await this.adjustmentsCol(tenantId, runId)
      .orderBy('createdAt', 'desc')
      .get();
    return snap.docs.map(d => d.data() as PayrollAdjustment);
  }

  /**
   * Fetch all adjustments marked carryForward=true from the previous month.
   * Called by generateEntityPayroll() to pre-load them into the new run.
   */
  async fetchCarryForwardAdjustments(
    tenantId: string,
    previousMonth: string, // 'YYYY-MM'
  ): Promise<PayrollAdjustment[]> {
    const prevRun = await this.findRunByMonth(tenantId, previousMonth);
    if (!prevRun) return [];

    const snap = await this.adjustmentsCol(tenantId, prevRun.runId)
      .where('carryForward', '==', true)
      .get();

    return snap.docs.map(d => d.data() as PayrollAdjustment);
  }

  // ── Guards ───────────────────────────────────────────────────────────────────

  private async assertExists(tenantId: string, runId: string): Promise<PayrollRun> {
    const run = await this.findRunById(tenantId, runId);
    if (!run) throw new NotFoundException(`مسير الرواتب '${runId}' غير موجود في المنشأة '${tenantId}'.`);
    return run;
  }

  private async assertNotClosed(tenantId: string, runId: string): Promise<void> {
    const run = await this.findRunById(tenantId, runId);
    if (run?.status === 'closed') {
      throw new ForbiddenException(
        `[C9 Immutability] مسير الرواتب '${runId}' مغلق نهائياً. ` +
        `لا يمكن تعديل بنوده. استخدم نقطة التسويات (adjustments) بدلاً من ذلك.`,
      );
    }
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // INDEPENDENT WORKER INVOICES
  // ══════════════════════════════════════════════════════════════════════════════

  private invoiceRef(uid: string, invoiceId: string) {
    return this.db
      .collection('users').doc(uid)
      .collection('personal_vault')
      .doc('invoices')
      .collection('items')
      .doc(invoiceId);
  }

  private invoicesCol(uid: string) {
    return this.db
      .collection('users').doc(uid)
      .collection('personal_vault')
      .doc('invoices')
      .collection('items');
  }

  async createInvoice(
    uid: string,
    data: Omit<IndependentInvoice, 'invoiceId' | 'generatedAt'>,
  ): Promise<IndependentInvoice> {
    const invoiceId = `inv_${data.month.replace('-', '')}_${randomUUID().slice(0, 8)}`;
    const invoice: IndependentInvoice = {
      ...data,
      invoiceId,
      generatedAt: FieldValue.serverTimestamp() as unknown as FirebaseFirestore.Timestamp,
    };
    await this.invoiceRef(uid, invoiceId).set(invoice);
    return invoice;
  }

  async findInvoiceByMonth(uid: string, month: string): Promise<IndependentInvoice | null> {
    const snap = await this.invoicesCol(uid)
      .where('month', '==', month)
      .limit(1)
      .get();
    return snap.empty ? null : (snap.docs[0].data() as IndependentInvoice);
  }

  async listInvoices(uid: string): Promise<IndependentInvoice[]> {
    const snap = await this.invoicesCol(uid).orderBy('generatedAt', 'desc').limit(24).get();
    return snap.docs.map(d => d.data() as IndependentInvoice);
  }

  async stampInvoice(uid: string, invoiceId: string): Promise<void> {
    await this.invoiceRef(uid, invoiceId).update({ status: 'stamped' });
  }
}
