import { Injectable, Inject, NotFoundException, ForbiddenException } from '@nestjs/common';
import { Firestore, FieldValue } from '@google-cloud/firestore';
import type { LexOpsRole } from '../auth/firebase.guard';

export interface UserDocument {
  uid: string;
  tenantId: string;
  email: string;
  nameAr: string;
  nameEn?: string;
  role: LexOpsRole;
  level: 1 | 2 | 3 | 4;
  branchId?: string;
  nationalId?: string;
  iqamaExpiry?: string;
  jobTitle?: string;
  isActive: boolean;
  createdAt: FirebaseFirestore.Timestamp;
  updatedAt: FirebaseFirestore.Timestamp;
}

@Injectable()
export class UsersRepository {
  constructor(@Inject('FIRESTORE') private readonly db: Firestore) {}

  private userRef(tenantId: string, uid: string) {
    return this.db.collection('entities').doc(tenantId).collection('users').doc(uid);
  }

  private usersCol(tenantId: string) {
    return this.db.collection('entities').doc(tenantId).collection('users');
  }

  async findByUid(tenantId: string, uid: string): Promise<UserDocument | null> {
    const snap = await this.userRef(tenantId, uid).get();
    return snap.exists ? (snap.data() as UserDocument) : null;
  }

  async findAllInTenant(tenantId: string): Promise<UserDocument[]> {
    const snap = await this.usersCol(tenantId).where('isActive', '==', true).get();
    return snap.docs.map((d) => d.data() as UserDocument);
  }

  async create(tenantId: string, uid: string, data: Omit<UserDocument, 'uid' | 'tenantId' | 'createdAt' | 'updatedAt'>): Promise<UserDocument> {
    const doc: UserDocument = {
      ...data,
      uid,
      tenantId,
      createdAt: FieldValue.serverTimestamp() as FirebaseFirestore.Timestamp,
      updatedAt: FieldValue.serverTimestamp() as FirebaseFirestore.Timestamp,
    };
    await this.userRef(tenantId, uid).set(doc);
    return doc;
  }

  async update(
    tenantId: string,
    uid: string,
    data: Partial<Omit<UserDocument, 'uid' | 'tenantId' | 'createdAt'>>,
    callerRole: LexOpsRole,
  ): Promise<void> {
    // Protect sensitive fields from employee self-update
    const sensitiveFields: (keyof UserDocument)[] = ['role', 'level', 'tenantId'];
    if (callerRole === 'employee') {
      for (const field of sensitiveFields) {
        if (field in data) {
          throw new ForbiddenException(`Field '${field}' cannot be modified by employees`);
        }
      }
    }

    const snap = await this.userRef(tenantId, uid).get();
    if (!snap.exists) throw new NotFoundException(`User '${uid}' not found in tenant '${tenantId}'`);

    await this.userRef(tenantId, uid).update({
      ...data,
      updatedAt: FieldValue.serverTimestamp(),
    });
  }

  async deactivate(tenantId: string, uid: string): Promise<void> {
    await this.update(tenantId, uid, { isActive: false }, 'entity_admin');
  }
}
