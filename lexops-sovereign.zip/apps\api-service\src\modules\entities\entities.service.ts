import { Injectable } from '@nestjs/common';
import { EntitiesRepository, EntityDocument } from './entities.repository';
import { C9LedgerRepository } from '../../database/c9-ledger.repository';

@Injectable()
export class EntitiesService {
  constructor(
    private readonly entitiesRepo: EntitiesRepository,
    private readonly c9: C9LedgerRepository,
  ) {}

  async findById(tenantId: string): Promise<EntityDocument | null> {
    return this.entitiesRepo.findById(tenantId);
  }

  async findAll(): Promise<EntityDocument[]> {
    return this.entitiesRepo.findAll();
  }

  async create(
    tenantId: string,
    data: Omit<EntityDocument, 'tenantId' | 'createdAt' | 'updatedAt'>,
    actorUid: string,
  ): Promise<EntityDocument> {
    const entity = await this.entitiesRepo.create(tenantId, data);

    // Seal the creation event in the C9 Ledger
    await this.c9.append({
      tenantId,
      eventType: 'entity.created',
      actorUid,
      actorRole: 'sovereign',
      subjectUid: tenantId,
      subjectType: 'entity',
      payload: { nameAr: data.nameAr, commercialRegNumber: data.commercialRegNumber },
    });

    return entity;
  }
}
