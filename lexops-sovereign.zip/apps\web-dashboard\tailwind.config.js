/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],

  theme: {
    extend: {
      // ── LexOps Sovereign Color Palette ───────────────────────────────────────
      colors: {
        primary: {
          DEFAULT:  '#0A4F38',   // Deep sovereign green
          dark:     '#073527',
          light:    '#0F6B4B',   // Vibrant green
          50:       '#E8F5F0',
          100:      '#C6E8DA',
          200:      '#93D0B7',
          300:      '#5CB893',
          400:      '#2EA070',
          500:      '#0F6B4B',
          600:      '#0A4F38',   // Default
          700:      '#073527',
          800:      '#041F17',
          900:      '#020D0A',
        },
        secondary: {
          DEFAULT:  '#C8A96B',   // Sovereign gold
          dark:     '#9A7F45',
          light:    '#DFC48C',
          50:       '#FBF6EC',
          100:      '#F4E8CC',
          200:      '#EAD09B',
          300:      '#DFC48C',
          400:      '#D4B47B',
          500:      '#C8A96B',   // Default
          600:      '#9A7F45',
          700:      '#7A6335',
          800:      '#584724',
          900:      '#2C2412',
        },
        neutral: {
          50:  '#F8F9FA',
          100: '#F1F3F5',
          200: '#E9ECEF',
          300: '#DEE2E6',
          400: '#CED4DA',
          500: '#ADB5BD',
          600: '#6C757D',
          700: '#495057',
          800: '#343A40',
          900: '#212529',
          950: '#0D1117',
        },
        // Status colors — legal compliance indicators
        verdict: {
          justified:   '#10B981',   // Green — justified
          unjustified: '#EF4444',   // Red — unjustified
          partial:     '#F59E0B',   // Amber — partial
          escalate:    '#8B5CF6',   // Purple — escalate to court
        },
      },

      // ── Typography ────────────────────────────────────────────────────────────
      fontFamily: {
        sans: [
          'IBM Plex Sans Arabic',
          'Cairo',
          'Noto Sans Arabic',
          'ui-sans-serif',
          'system-ui',
          'sans-serif',
        ],
        mono: ['IBM Plex Mono', 'Fira Code', 'ui-monospace', 'monospace'],
        display: ['Cairo', 'IBM Plex Sans Arabic', 'sans-serif'],
      },

      fontSize: {
        // Arabic-optimized sizes (slightly larger base for readability)
        'xs':   ['0.8125rem',  { lineHeight: '1.6' }],
        'sm':   ['0.9375rem',  { lineHeight: '1.65' }],
        'base': ['1.0625rem',  { lineHeight: '1.7' }],
        'lg':   ['1.1875rem',  { lineHeight: '1.7' }],
        'xl':   ['1.3125rem',  { lineHeight: '1.65' }],
        '2xl':  ['1.5rem',     { lineHeight: '1.6' }],
        '3xl':  ['1.875rem',   { lineHeight: '1.5' }],
        '4xl':  ['2.25rem',    { lineHeight: '1.4' }],
        '5xl':  ['3rem',       { lineHeight: '1.3' }],
      },

      // ── Spacing & Border Radius ───────────────────────────────────────────────
      borderRadius: {
        'none': '0',
        'sm':   '0.25rem',
        DEFAULT:'0.5rem',
        'md':   '0.625rem',
        'lg':   '0.875rem',
        'xl':   '1.25rem',
        '2xl':  '1.75rem',
        'full': '9999px',
      },

      // ── Box Shadow — Sovereign Style ──────────────────────────────────────────
      boxShadow: {
        'sovereign': '0 4px 24px 0 rgba(10, 79, 56, 0.18)',
        'gold':      '0 4px 20px 0 rgba(200, 169, 107, 0.25)',
        'card':      '0 2px 12px 0 rgba(0, 0, 0, 0.08)',
        'elevated':  '0 8px 40px 0 rgba(0, 0, 0, 0.14)',
      },

      // ── Animations ────────────────────────────────────────────────────────────
      keyframes: {
        'fade-in': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'pulse-gold': {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(200, 169, 107, 0.4)' },
          '50%': { boxShadow: '0 0 0 8px rgba(200, 169, 107, 0)' },
        },
      },
      animation: {
        'fade-in':    'fade-in 0.25s ease-out',
        'pulse-gold': 'pulse-gold 2s ease-in-out infinite',
      },
    },
  },

  plugins: [],

  // RTL / Arabic-first: direction utilities
  corePlugins: {
    preflight: true,
  },
};
