/**
 * LexOps — Objections Repository  (Sprint 7 — Legal Engine)
 *
 * Firestore path:
 *   /entities/{tenantId}/objections/{objectionId}
 *   /entities/{tenantId}/objections/{objectionId}/documents/{docId}
 *
 * Status lifecycle (append-only transitions):
 *   draft → submitted → under_review → accepted | rejected
 *
 * An objection is always linked to a single violationId.
 * One violation may have at most ONE active (non-rejected) objection at a time.
 */

import {
  Injectable, Inject,
  NotFoundException, ConflictException, ForbiddenException,
} from '@nestjs/common';
import { Firestore, FieldValue } from '@google-cloud/firestore';
import { randomUUID } from 'crypto';

// ── Types ─────────────────────────────────────────────────────────────────────

export type ObjectionStatus =
  | 'draft'
  | 'submitted'
  | 'under_review'
  | 'accepted'
  | 'rejected';

export interface LexiDraft {
  legalArgument:        string;
  factsSummary:         string;
  recommendedDocuments: string[];
  riskLevel:            'low' | 'medium' | 'high';
  generatedAt:          string;   // ISO timestamp
  model:                string;   // e.g. 'gemini-1.5-pro-002'
  decree11438Applied:   boolean;  // Whether Royal Decree 11438 filter was triggered
}

export interface ObjectionDocument {
  docId:       string;
  label:       string;          // e.g. 'عقد العمل', 'شهادة طبية'
  fileUrl:     string;
  uploadedBy:  string;
  uploadedAt:  FirebaseFirestore.Timestamp;
}

export interface ObjectionRecord {
  objectionId:   string;
  tenantId:      string;
  violationId:   string;
  employeeId:    string;
  branchId?:     string;
  content:       string;        // Employee's written objection (Arabic)
  status:        ObjectionStatus;
  lexiDraft?:    LexiDraft;     // Populated by LegalService.generateDraft()
  submittedAt?:  FirebaseFirestore.Timestamp;
  reviewedBy?:   string;
  reviewedAt?:   FirebaseFirestore.Timestamp;
  reviewNote?:   string;
  createdBy:     string;
  createdAt:     FirebaseFirestore.Timestamp;
  updatedAt:     FirebaseFirestore.Timestamp;
}

// ── Repository ────────────────────────────────────────────────────────────────

@Injectable()
export class ObjectionsRepository {
  constructor(@Inject('FIRESTORE') private readonly db: Firestore) {}

  private objRef(tenantId: string, objectionId: string) {
    return this.db
      .collection('entities').doc(tenantId)
      .collection('objections').doc(objectionId);
  }

  private objCol(tenantId: string) {
    return this.db.collection('entities').doc(tenantId).collection('objections');
  }

  private docsCol(tenantId: string, objectionId: string) {
    return this.objRef(tenantId, objectionId).collection('documents');
  }

  // ── Create ───────────────────────────────────────────────────────────────────

  async create(
    tenantId: string,
    data: Omit<ObjectionRecord, 'objectionId' | 'tenantId' | 'createdAt' | 'updatedAt'>,
  ): Promise<ObjectionRecord> {
    // Enforce one active objection per violation
    const existing = await this.findActiveByViolation(tenantId, data.violationId);
    if (existing) {
      throw new ConflictException(
        `توجد اعتراض نشط مسبقاً على المخالفة '${data.violationId}' ` +
        `(${existing.objectionId}). لا يمكن تقديم اعتراضين على نفس المخالفة.`,
      );
    }

    const objectionId = `obj_${randomUUID().replace(/-/g, '').slice(0, 14)}`;
    const now = FieldValue.serverTimestamp() as unknown as FirebaseFirestore.Timestamp;

    const record: ObjectionRecord = {
      ...data,
      objectionId,
      tenantId,
      status: 'draft',
      createdAt: now,
      updatedAt: now,
    };

    await this.objRef(tenantId, objectionId).set(record);
    return record;
  }

  // ── Queries ───────────────────────────────────────────────────────────────────

  async findById(tenantId: string, objectionId: string): Promise<ObjectionRecord | null> {
    const snap = await this.objRef(tenantId, objectionId).get();
    return snap.exists ? (snap.data() as ObjectionRecord) : null;
  }

  async findByViolation(tenantId: string, violationId: string): Promise<ObjectionRecord[]> {
    const snap = await this.objCol(tenantId)
      .where('violationId', '==', violationId)
      .orderBy('createdAt', 'desc')
      .get();
    return snap.docs.map(d => d.data() as ObjectionRecord);
  }

  async findByEmployee(tenantId: string, employeeId: string): Promise<ObjectionRecord[]> {
    const snap = await this.objCol(tenantId)
      .where('employeeId', '==', employeeId)
      .orderBy('createdAt', 'desc')
      .limit(50)
      .get();
    return snap.docs.map(d => d.data() as ObjectionRecord);
  }

  async findAllByTenant(tenantId: string, status?: ObjectionStatus): Promise<ObjectionRecord[]> {
    let q = this.objCol(tenantId).orderBy('createdAt', 'desc') as FirebaseFirestore.Query;
    if (status) q = q.where('status', '==', status);
    const snap = await q.limit(100).get();
    return snap.docs.map(d => d.data() as ObjectionRecord);
  }

  private async findActiveByViolation(
    tenantId:    string,
    violationId: string,
  ): Promise<ObjectionRecord | null> {
    const snap = await this.objCol(tenantId)
      .where('violationId', '==', violationId)
      .where('status', 'in', ['draft', 'submitted', 'under_review'])
      .limit(1)
      .get();
    return snap.empty ? null : (snap.docs[0].data() as ObjectionRecord);
  }

  // ── Mutations ─────────────────────────────────────────────────────────────────

  async submit(tenantId: string, objectionId: string): Promise<void> {
    const rec = await this.assertExists(tenantId, objectionId);
    if (rec.status !== 'draft') {
      throw new ConflictException(
        `الاعتراض '${objectionId}' بحالة '${rec.status}' — لا يمكن تقديمه مرة أخرى.`,
      );
    }
    await this.objRef(tenantId, objectionId).update({
      status:      'submitted',
      submittedAt: FieldValue.serverTimestamp(),
      updatedAt:   FieldValue.serverTimestamp(),
    });
  }

  async setUnderReview(tenantId: string, objectionId: string): Promise<void> {
    await this.objRef(tenantId, objectionId).update({
      status:    'under_review',
      updatedAt: FieldValue.serverTimestamp(),
    });
  }

  async saveLexiDraft(
    tenantId:    string,
    objectionId: string,
    draft:       LexiDraft,
  ): Promise<void> {
    await this.objRef(tenantId, objectionId).update({
      lexiDraft: draft,
      updatedAt: FieldValue.serverTimestamp(),
    });
  }

  async review(
    tenantId:     string,
    objectionId:  string,
    decision:     'accepted' | 'rejected',
    reviewedBy:   string,
    reviewNote:   string,
  ): Promise<void> {
    const rec = await this.assertExists(tenantId, objectionId);
    if (!['submitted', 'under_review'].includes(rec.status)) {
      throw new ConflictException(
        `الاعتراض '${objectionId}' بحالة '${rec.status}' — لا يمكن مراجعته.`,
      );
    }
    await this.objRef(tenantId, objectionId).update({
      status:     decision,
      reviewedBy,
      reviewedAt: FieldValue.serverTimestamp(),
      reviewNote,
      updatedAt:  FieldValue.serverTimestamp(),
    });
  }

  async updateContent(
    tenantId:    string,
    objectionId: string,
    content:     string,
    editorUid:   string,
  ): Promise<void> {
    const rec = await this.assertExists(tenantId, objectionId);
    if (rec.status !== 'draft') {
      throw new ForbiddenException(
        `لا يمكن تعديل محتوى اعتراض بحالة '${rec.status}'. التعديل مسموح فقط في وضع draft.`,
      );
    }
    await this.objRef(tenantId, objectionId).update({
      content,
      updatedAt: FieldValue.serverTimestamp(),
    });
  }

  // ── Documents ─────────────────────────────────────────────────────────────────

  async addDocument(
    tenantId:    string,
    objectionId: string,
    data:        Omit<ObjectionDocument, 'docId' | 'uploadedAt'>,
  ): Promise<ObjectionDocument> {
    await this.assertExists(tenantId, objectionId);

    const docId = `odoc_${randomUUID().replace(/-/g, '').slice(0, 12)}`;
    const doc: ObjectionDocument = {
      ...data,
      docId,
      uploadedAt: FieldValue.serverTimestamp() as unknown as FirebaseFirestore.Timestamp,
    };
    await this.docsCol(tenantId, objectionId).doc(docId).set(doc);
    return doc;
  }

  async listDocuments(tenantId: string, objectionId: string): Promise<ObjectionDocument[]> {
    const snap = await this.docsCol(tenantId, objectionId)
      .orderBy('uploadedAt', 'desc')
      .get();
    return snap.docs.map(d => d.data() as ObjectionDocument);
  }

  // ── Guard ─────────────────────────────────────────────────────────────────────

  async assertExists(tenantId: string, objectionId: string): Promise<ObjectionRecord> {
    const rec = await this.findById(tenantId, objectionId);
    if (!rec) {
      throw new NotFoundException(
        `الاعتراض '${objectionId}' غير موجود في المنشأة '${tenantId}'.`,
      );
    }
    return rec;
  }
}
