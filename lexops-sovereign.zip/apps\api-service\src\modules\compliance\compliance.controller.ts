/**
 * LexOps — Compliance Controller  (Sprint 6)
 *
 * REST Endpoints (all under /v1/entities/:tenantId/compliance):
 *
 *   POST   /scan/:employeeId           → single employee compliance scan
 *   POST   /scan-entity                → entity-wide month-end scan (sovereign/admin)
 *   GET    /violations                 → open violations board (admin)
 *   GET    /violations/employee/:empId → full history for one employee
 *   GET    /violations/recent/:empId   → last 180 days (recurrence audit)
 *   PATCH  /violations/:id/resolve     → resolve a violation + C9 seal
 *   GET    /rules                      → list active rules for this entity
 */

import {
  Controller, Get, Post, Patch,
  Param, Body, Request, Query, Version, UseGuards,
  HttpCode, HttpStatus,
} from '@nestjs/common';
import {
  ApiTags, ApiBearerAuth, ApiOperation, ApiParam, ApiQuery,
} from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsOptional } from 'class-validator';
import { ComplianceService } from './compliance.service';
import { FirebaseAuthGuard, TenantScopeGuard, Roles, LexOpsClaims } from '../auth/firebase.guard';
import { Request as ExpressRequest } from 'express';

// ── DTOs ─────────────────────────────────────────────────────────────────────

class ScanDto {
  @IsString() @IsNotEmpty()
  month: string; // 'YYYY-MM'
}

class ResolveViolationDto {
  @IsString() @IsNotEmpty()
  resolutionNote: string;
}

// ── Controller ────────────────────────────────────────────────────────────────

@ApiTags('Compliance Engine — محرك الامتثال')
@ApiBearerAuth('Firebase-JWT')
@Controller('entities/:tenantId/compliance')
@UseGuards(FirebaseAuthGuard, TenantScopeGuard)
export class ComplianceController {
  constructor(private readonly complianceService: ComplianceService) {}

  // ── Single Employee Scan ──────────────────────────────────────────────────

  @Post('scan/:employeeId')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'فحص امتثال موظف واحد — تطبيق قواعد JSON Logic + قاعدة التكرار 180 يوم',
    description:
      'يبني السياق الكامل (حضور + إجازات + تاريخ المخالفات 180 يوم) ويشغّل جميع القواعد المفعّلة. ' +
      'المخالفات المولودة تلقائياً تُختم في C9 Ledger.',
  })
  async scanEmployee(
    @Param('tenantId')   tenantId:   string,
    @Param('employeeId') employeeId: string,
    @Body() dto: ScanDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.complianceService.runComplianceScan(
      tenantId, employeeId, dto.month, req.user.uid,
    );
  }

  // ── Entity-Wide Scan ──────────────────────────────────────────────────────

  @Post('scan-entity')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: '[Cron / Manual] فحص امتثال شامل لجميع موظفي المنشأة',
    description:
      'مصمم للاستدعاء من Cloud Scheduler في نهاية كل شهر. ' +
      'يفحص كل موظف نشط ويولد المخالفات تلقائياً مع ختم الحدث ENTITY_COMPLIANCE_SCAN_COMPLETED في C9.',
  })
  async scanEntity(
    @Param('tenantId') tenantId: string,
    @Body() dto: ScanDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.complianceService.runEntityWideScan(
      tenantId, dto.month, req.user.uid,
    );
  }

  // ── Violations Board ──────────────────────────────────────────────────────

  @Get('violations')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'لوحة المخالفات المفتوحة — Open Violations Board' })
  getOpenViolations(@Param('tenantId') tenantId: string) {
    return this.complianceService.getOpenViolations(tenantId);
  }

  @Get('violations/employee/:employeeId')
  @Version('1')
  @Roles('entity_admin', 'sovereign', 'employee')
  @ApiOperation({ summary: 'سجل المخالفات الكامل لموظف' })
  getEmployeeViolations(
    @Param('tenantId')   tenantId:   string,
    @Param('employeeId') employeeId: string,
  ) {
    return this.complianceService.getEmployeeViolations(tenantId, employeeId);
  }

  @Get('violations/recent/:employeeId')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({
    summary: 'مخالفات الموظف في آخر N يوم (افتراضي: 180 يوم — نافذة التكرار)',
  })
  @ApiQuery({ name: 'days', required: false, description: 'نافذة الأيام (افتراضي: 180)' })
  getRecentViolations(
    @Param('tenantId')   tenantId:   string,
    @Param('employeeId') employeeId: string,
    @Query('days') days?: string,
  ) {
    const windowDays = days ? parseInt(days, 10) : 180;
    return this.complianceService.getRecentViolations(tenantId, employeeId, windowDays);
  }

  // ── Resolve Violation ─────────────────────────────────────────────────────

  @Patch('violations/:violationId/resolve')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({
    summary: 'حل مخالفة + ختم VIOLATION_RESOLVED في C9',
    description: 'يُغير حالة المخالفة إلى resolved ويُخزّن ملاحظة الحل.',
  })
  resolveViolation(
    @Param('tenantId')     tenantId:    string,
    @Param('violationId')  violationId: string,
    @Body() dto: ResolveViolationDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.complianceService.resolveViolation(
      tenantId, violationId, req.user.uid, dto.resolutionNote,
    );
  }

  // ── Rules ────────────────────────────────────────────────────────────────

  @Get('rules')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'قائمة قواعد الامتثال المفعّلة لهذه المنشأة (JSON Logic)' })
  getRules(@Param('tenantId') tenantId: string) {
    return this.complianceService.loadEntityRules(tenantId);
  }
}
