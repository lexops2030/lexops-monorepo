export default function ViolationsPage() {
  return <div className="card-sovereign"><p className="text-neutral-500">وحدة المخالفات — Sprint 3</p></div>;
}
