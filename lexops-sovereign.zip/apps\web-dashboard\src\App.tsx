import { Routes, Route, Navigate } from 'react-router-dom';

// Lazy-loaded dashboard views (code-split per role)
import { lazy, Suspense } from 'react';

const DashboardLayout  = lazy(() => import('./layouts/DashboardLayout'));
const LoginPage        = lazy(() => import('./pages/auth/LoginPage'));
const SovereignPage    = lazy(() => import('./pages/sovereign/SovereignPage'));
const EntityDashboard  = lazy(() => import('./pages/entity/EntityDashboard'));
const AttendancePage   = lazy(() => import('./pages/entity/AttendancePage'));
const ViolationsPage   = lazy(() => import('./pages/entity/ViolationsPage'));
const LeavesPage       = lazy(() => import('./pages/entity/LeavesPage'));
const LexiPage         = lazy(() => import('./pages/lexi/LexiPage'));
const FreelancerPortal = lazy(() => import('./pages/freelancer/FreelancerPortal'));
const NotFoundPage     = lazy(() => import('./pages/NotFoundPage'));

const LoadingSpinner = () => (
  <div className="flex h-screen items-center justify-center bg-neutral-50">
    <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent" />
  </div>
);

export default function App() {
  return (
    <Suspense fallback={<LoadingSpinner />}>
      <Routes>
        {/* Public */}
        <Route path="/login" element={<LoginPage />} />

        {/* Protected — Dashboard Shell */}
        <Route path="/" element={<DashboardLayout />}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard"        element={<EntityDashboard />} />
          <Route path="attendance"       element={<AttendancePage />} />
          <Route path="violations"       element={<ViolationsPage />} />
          <Route path="leaves"           element={<LeavesPage />} />
          <Route path="lexi"             element={<LexiPage />} />
          <Route path="sovereign"        element={<SovereignPage />} />
          <Route path="freelancer"       element={<FreelancerPortal />} />
        </Route>

        {/* 404 */}
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </Suspense>
  );
}
