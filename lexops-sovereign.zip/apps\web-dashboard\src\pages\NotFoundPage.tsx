export default function NotFoundPage() {
  return (
    <div className="flex h-screen flex-col items-center justify-center gap-4">
      <p className="text-6xl font-bold text-primary">404</p>
      <p className="text-neutral-500">الصفحة المطلوبة غير موجودة</p>
    </div>
  );
}
