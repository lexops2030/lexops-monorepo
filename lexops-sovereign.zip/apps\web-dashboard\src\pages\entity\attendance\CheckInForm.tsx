import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQuery } from '@tanstack/react-query';
import {
  MapPin, Wifi, WifiOff, CheckCircle2,
  Clock, AlertCircle, ShieldAlert, Navigation,
} from 'lucide-react';
import { Button } from '../../../components/ui/Button';
import { Input } from '../../../components/ui/Input';
import { Select } from '../../../components/ui/Select';
import api from '../../../lib/api';
import { cn } from '../../../lib/utils';
import type { BranchDocument } from '../../../../../api-service/src/modules/branches/branches.repository';

// ── Schema ────────────────────────────────────────────────────────────────────

const checkInSchema = z.object({
  branchId:          z.string().min(1, 'اختر الفرع'),
  lat:               z.number(),
  lng:               z.number(),
  accuracy:          z.number().min(0),
  isMock:            z.boolean(),
  deviceTimestampMs: z.number(),
  deviceId:          z.string().optional(),
});

type CheckInFormValues = z.infer<typeof checkInSchema>;

// ── Status display config ─────────────────────────────────────────────────────

const statusConfig = {
  accepted: {
    icon: CheckCircle2,
    label: 'تم تسجيل الحضور — مقبول',
    class: 'border-green-200 bg-green-50 text-green-800',
    iconClass: 'text-green-600',
  },
  pending_review: {
    icon: Clock,
    label: 'قيد المراجعة الإدارية',
    class: 'border-amber-200 bg-amber-50 text-amber-800',
    iconClass: 'text-amber-600',
  },
  rejected: {
    icon: AlertCircle,
    label: 'مرفوض — خارج النطاق أو غير دقيق',
    class: 'border-red-200 bg-red-50 text-red-800',
    iconClass: 'text-red-600',
  },
};

// ── Component ─────────────────────────────────────────────────────────────────

const TENANT_ID = import.meta.env.VITE_DEMO_TENANT_ID ?? 'ENTITY_700';

export default function CheckInForm() {
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle');
  const [result, setResult] = useState<{ status: string; geofenceReason: string; distanceMeters: number; isMockSuspected: boolean } | null>(null);

  const { data: branches = [] } = useQuery<BranchDocument[]>({
    queryKey: ['branches', TENANT_ID],
    queryFn: () => api.get(`/entities/${TENANT_ID}/branches`).then((r) => r.data),
  });

  const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm<CheckInFormValues>({
    resolver: zodResolver(checkInSchema),
    defaultValues: {
      isMock: false,
      lat: 0,
      lng: 0,
      accuracy: 0,
      deviceTimestampMs: Date.now(),
      deviceId: `web_sim_${navigator.userAgent.slice(0, 16).replace(/\s/g, '_')}`,
    },
  });

  const lat = watch('lat');
  const lng = watch('lng');
  const accuracy = watch('accuracy');
  const isMock = watch('isMock');

  // ── Acquire real GPS from browser ─────────────────────────────────────────
  const acquireGps = () => {
    if (!navigator.geolocation) {
      setGpsStatus('error');
      return;
    }
    setGpsStatus('loading');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setValue('lat', pos.coords.latitude);
        setValue('lng', pos.coords.longitude);
        setValue('accuracy', Math.round(pos.coords.accuracy));
        setValue('deviceTimestampMs', pos.timestamp);
        setGpsStatus('ready');
      },
      () => setGpsStatus('error'),
      { enableHighAccuracy: true, timeout: 10_000 },
    );
  };

  const mutation = useMutation({
    mutationFn: (data: CheckInFormValues) =>
      api.post(`/entities/${TENANT_ID}/attendance/check-in`, data).then((r) => r.data),
    onSuccess: (data) => setResult(data),
    onError: () => setResult(null),
  });

  const branchOptions = [
    { value: '', label: '-- اختر الفرع --' },
    ...branches.map((b) => ({ value: b.branchId, label: b.name })),
  ];

  const currentStatus = result ? statusConfig[result.status as keyof typeof statusConfig] : null;

  return (
    <div className="mx-auto max-w-sm">
      {/* ── Mobile-style header ── */}
      <div className="mb-6 text-center">
        <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary shadow-sovereign">
          <Navigation className="h-8 w-8 text-white" />
        </div>
        <h2 className="text-xl font-bold text-neutral-900">تسجيل الحضور</h2>
        <p className="text-sm text-neutral-400">محاكاة تطبيق الجوال — LexOps Field</p>
      </div>

      {/* ── Result Banner ── */}
      {currentStatus && result && (
        <div className={cn('mb-5 rounded-xl border p-4 animate-fade-in', currentStatus.class)}>
          <div className="flex items-center gap-2 mb-2">
            <currentStatus.icon className={cn('h-5 w-5 shrink-0', currentStatus.iconClass)} />
            <p className="font-semibold text-sm">{currentStatus.label}</p>
          </div>
          {result.isMockSuspected && (
            <div className="flex items-center gap-1.5 mt-2 mb-2">
              <ShieldAlert className="h-4 w-4 text-red-600 shrink-0" />
              <p className="text-xs font-semibold text-red-700">
                تحذير Fortress 700: اكتُشف موقع مشبوه
              </p>
            </div>
          )}
          <p className="text-xs mt-1 opacity-80">{result.geofenceReason}</p>
          <p className="text-xs mt-1 font-mono opacity-70">
            المسافة: {result.distanceMeters.toFixed(1)} م
          </p>
        </div>
      )}

      <form onSubmit={handleSubmit((d) => mutation.mutate(d))} noValidate>
        <div className="card-sovereign space-y-5">

          <Select
            id="branchId"
            label="الفرع"
            required
            options={branchOptions}
            error={errors.branchId?.message}
            {...register('branchId')}
          />

          {/* ── GPS Acquisition ── */}
          <div>
            <p className="text-sm font-medium text-neutral-700 mb-2">
              الإحداثيات الجغرافية
              <span className="text-red-500 mr-0.5">*</span>
            </p>

            <button
              type="button"
              onClick={acquireGps}
              className={cn(
                'flex w-full items-center justify-center gap-2 rounded-lg border-2 border-dashed py-4 text-sm font-medium transition-colors',
                gpsStatus === 'ready'
                  ? 'border-green-400 bg-green-50 text-green-700'
                  : gpsStatus === 'error'
                    ? 'border-red-300 bg-red-50 text-red-600'
                    : 'border-neutral-300 text-neutral-500 hover:border-primary hover:bg-primary/5',
              )}
            >
              {gpsStatus === 'loading' ? (
                <><span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" /> جارٍ تحديد الموقع...</>
              ) : gpsStatus === 'ready' ? (
                <><Wifi className="h-4 w-4" /> {lat.toFixed(5)}, {lng.toFixed(5)} (±{accuracy}م)</>
              ) : gpsStatus === 'error' ? (
                <><WifiOff className="h-4 w-4" /> فشل تحديد الموقع — أدخله يدوياً</>
              ) : (
                <><MapPin className="h-4 w-4" /> اضغط لتحديد موقعك الحالي</>
              )}
            </button>
          </div>

          {/* ── Manual Override (for testing/simulation) ── */}
          <details className="group">
            <summary className="cursor-pointer text-xs text-neutral-400 hover:text-neutral-600 list-none flex items-center gap-1">
              <span className="font-mono">▶</span> إدخال يدوي / محاكاة
            </summary>
            <div className="mt-3 grid grid-cols-2 gap-3">
              <Input
                id="lat-manual"
                label="خط العرض"
                type="number"
                step="0.0000001"
                {...register('lat', { valueAsNumber: true })}
              />
              <Input
                id="lng-manual"
                label="خط الطول"
                type="number"
                step="0.0000001"
                {...register('lng', { valueAsNumber: true })}
              />
              <Input
                id="accuracy-manual"
                label="الدقة (م)"
                type="number"
                {...register('accuracy', { valueAsNumber: true })}
              />
              <div className="flex flex-col gap-1.5">
                <label className="text-sm font-medium text-neutral-700">
                  موقع وهمي (Mock)
                </label>
                <label className="flex items-center gap-2 cursor-pointer mt-1">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-neutral-300 text-red-500 focus:ring-red-400"
                    {...register('isMock')}
                  />
                  <span className={cn('text-sm', isMock ? 'text-red-600 font-semibold' : 'text-neutral-500')}>
                    {isMock ? 'تفعّل — سيُكتشف!' : 'معطّل'}
                  </span>
                </label>
              </div>
            </div>
          </details>

          <Button
            type="submit"
            loading={mutation.isPending}
            className="w-full"
            size="lg"
          >
            <Navigation className="h-5 w-5" />
            تسجيل الحضور الآن
          </Button>
        </div>
      </form>
    </div>
  );
}
