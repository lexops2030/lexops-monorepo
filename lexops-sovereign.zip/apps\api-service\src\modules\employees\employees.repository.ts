import {
  Injectable, Inject, ConflictException,
  NotFoundException, UnprocessableEntityException,
} from '@nestjs/common';
import { Firestore, FieldValue } from '@google-cloud/firestore';

// ── Employee Document Shape ───────────────────────────────────────────────────

export type EmploymentType = 'full_time' | 'part_time' | 'contract' | 'seasonal';
export type EmployeeStatus = 'active' | 'on_leave' | 'suspended' | 'terminated';

export interface EmployeeDocument {
  employeeId: string;         // Auto-generated unique ID
  tenantId: string;           // Fortress 700 — mandatory
  branchId: string;           // Must belong to the SAME tenantId — validated in service
  nationalId: string;         // Saudi National ID / Iqama — unique per tenant
  name: string;
  nameEn?: string;
  position: string;
  department?: string;
  employmentType: EmploymentType;
  status: EmployeeStatus;
  phone?: string;
  email?: string;
  iqamaExpiry?: string;       // ISO 8601 date
  probationEndsAt?: string;   // ISO 8601 date
  baseSalary?: number;        // SAR — used by payroll engine
  joinedAt: string;           // ISO 8601 date
  isActive: boolean;
  createdAt: FirebaseFirestore.Timestamp;
  updatedAt: FirebaseFirestore.Timestamp;
  createdBy: string;
}

// ── Repository ────────────────────────────────────────────────────────────────

@Injectable()
export class EmployeesRepository {
  constructor(@Inject('FIRESTORE') private readonly db: Firestore) {}

  private empRef(tenantId: string, employeeId: string) {
    return this.db
      .collection('entities').doc(tenantId)
      .collection('employees').doc(employeeId);
  }

  private empCol(tenantId: string) {
    return this.db.collection('entities').doc(tenantId).collection('employees');
  }

  async findById(tenantId: string, employeeId: string): Promise<EmployeeDocument | null> {
    const snap = await this.empRef(tenantId, employeeId).get();
    return snap.exists ? (snap.data() as EmployeeDocument) : null;
  }

  async findByNationalId(tenantId: string, nationalId: string): Promise<EmployeeDocument | null> {
    const snap = await this.empCol(tenantId)
      .where('nationalId', '==', nationalId)
      .limit(1)
      .get();
    return snap.empty ? null : (snap.docs[0].data() as EmployeeDocument);
  }

  async findAllByTenant(
    tenantId: string,
    filters: { branchId?: string; status?: EmployeeStatus } = {},
  ): Promise<EmployeeDocument[]> {
    let query = this.empCol(tenantId).where('isActive', '==', true) as
      FirebaseFirestore.Query<FirebaseFirestore.DocumentData>;

    if (filters.branchId) query = query.where('branchId', '==', filters.branchId);
    if (filters.status)   query = query.where('status',   '==', filters.status);

    const snap = await query.orderBy('createdAt', 'asc').get();
    return snap.docs.map((d) => d.data() as EmployeeDocument);
  }

  async create(
    tenantId: string,
    employeeId: string,
    data: Omit<EmployeeDocument, 'employeeId' | 'tenantId' | 'createdAt' | 'updatedAt'>,
  ): Promise<EmployeeDocument> {
    // Enforce unique nationalId per tenant
    const existing = await this.findByNationalId(tenantId, data.nationalId);
    if (existing) {
      throw new ConflictException(
        `National ID '${data.nationalId}' is already registered in entity '${tenantId}'`,
      );
    }

    const doc: EmployeeDocument = {
      ...data,
      employeeId,
      tenantId,
      createdAt: FieldValue.serverTimestamp() as FirebaseFirestore.Timestamp,
      updatedAt: FieldValue.serverTimestamp() as FirebaseFirestore.Timestamp,
    };

    await this.empRef(tenantId, employeeId).set(doc);
    return doc;
  }

  async update(
    tenantId: string,
    employeeId: string,
    data: Partial<Omit<EmployeeDocument, 'employeeId' | 'tenantId' | 'nationalId' | 'createdAt' | 'createdBy'>>,
  ): Promise<void> {
    const snap = await this.empRef(tenantId, employeeId).get();
    if (!snap.exists) {
      throw new NotFoundException(
        `Employee '${employeeId}' not found in entity '${tenantId}'`,
      );
    }
    await this.empRef(tenantId, employeeId).update({
      ...data,
      updatedAt: FieldValue.serverTimestamp(),
    });
  }

  async deactivate(tenantId: string, employeeId: string): Promise<void> {
    await this.update(tenantId, employeeId, { isActive: false, status: 'terminated' });
  }
}
