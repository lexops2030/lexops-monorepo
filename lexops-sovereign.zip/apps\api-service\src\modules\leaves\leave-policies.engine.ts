/**
 * LexOps — Leave Policies Engine
 *
 * Enforces three leave policies before a request is persisted.
 * All violations throw UnprocessableEntityException (HTTP 422).
 *
 * Policy 1 — Invalid Date Range:
 *   startDate must be <= endDate, and startDate must be today or later.
 *
 * Policy 2 — Overlapping Leave:
 *   No active (requested|approved) leave may overlap the requested range.
 *
 * Policy 3 — Annual Balance Exceeded:
 *   Applies to 'annual' leave type only.
 *   Default annual entitlement = 21 days (Saudi Labor Law, Art. 109).
 *   Throws if (used + requested) > entitlement.
 */

import { Injectable, UnprocessableEntityException, Logger } from '@nestjs/common';
import { LeavesRepository, LeaveType, LeaveDocument } from './leaves.repository';

// ── Config ────────────────────────────────────────────────────────────────────

/** Saudi Labor Law Article 109 default annual entitlement */
const ANNUAL_LEAVE_DAYS_DEFAULT = 21;

export interface PolicyCheckInput {
  tenantId:       string;
  employeeUid:    string;
  leaveType:      LeaveType;
  startDate:      string;   // 'YYYY-MM-DD'
  endDate:        string;   // 'YYYY-MM-DD'
  daysRequested:  number;
  excludeLeaveId?: string;  // for future edit use
  /** Employee annual entitlement (from contract). Defaults to 21 days. */
  annualEntitlement?: number;
}

export interface PolicyCheckResult {
  passed:        boolean;
  violations:    string[];
  usedDays?:     number;   // only for annual type
  remainingDays?: number;  // only for annual type
}

// ── Engine ────────────────────────────────────────────────────────────────────

@Injectable()
export class LeavePoliciesEngine {
  private readonly logger = new Logger(LeavePoliciesEngine.name);

  constructor(private readonly leavesRepo: LeavesRepository) {}

  /**
   * Run all policy checks and throw 422 on first violation.
   * Returns metadata (used/remaining days) for the service layer.
   */
  async enforce(input: PolicyCheckInput): Promise<PolicyCheckResult> {
    const violations: string[] = [];

    // ── Policy 1: Date range validity ────────────────────────────────────────
    const today = new Date().toISOString().slice(0, 10);

    if (input.startDate > input.endDate) {
      violations.push(
        `تاريخ البداية (${input.startDate}) يجب أن يكون قبل أو يساوي تاريخ النهاية (${input.endDate}).`,
      );
    }

    if (input.startDate < today) {
      violations.push(
        `لا يمكن تقديم إجازة بأثر رجعي. تاريخ البداية (${input.startDate}) قبل اليوم (${today}).`,
      );
    }

    if (input.daysRequested < 1) {
      violations.push('يجب أن تكون مدة الإجازة يوماً واحداً على الأقل.');
    }

    // ── Policy 2: Overlap detection ──────────────────────────────────────────
    const overlapping = await this.leavesRepo.findActiveOverlapping(
      input.tenantId,
      input.employeeUid,
      input.startDate,
      input.endDate,
      input.excludeLeaveId,
    );

    if (overlapping.length > 0) {
      const conflicting = overlapping
        .map((l: LeaveDocument) => `${l.startDate} → ${l.endDate} (${l.status})`)
        .join(' | ');
      violations.push(
        `تداخل مع إجازة قائمة: ${conflicting}. ` +
        `لا يمكن تقديم طلبين متداخلين.`,
      );
    }

    // ── Policy 3: Annual balance ─────────────────────────────────────────────
    let usedDays: number | undefined;
    let remainingDays: number | undefined;

    if (input.leaveType === 'annual') {
      const year        = Number(input.startDate.slice(0, 4));
      const entitlement = input.annualEntitlement ?? ANNUAL_LEAVE_DAYS_DEFAULT;
      usedDays          = await this.leavesRepo.countUsedAnnualDays(
        input.tenantId, input.employeeUid, year,
      );
      remainingDays = entitlement - usedDays;

      if (usedDays + input.daysRequested > entitlement) {
        violations.push(
          `رصيد الإجازات السنوية غير كافٍ. ` +
          `المستخدم: ${usedDays} يوم — المطلوب: ${input.daysRequested} يوم — ` +
          `المتبقي: ${remainingDays} يوم من أصل ${entitlement} يوماً ` +
          `(نظام العمل السعودي، المادة 109).`,
        );
      }
    }

    // ── Throw 422 if any violation ───────────────────────────────────────────
    if (violations.length > 0) {
      this.logger.warn(
        `[LeavePolicies] Violations for employee=${input.employeeUid}: ` +
        violations.join(' | '),
      );
      throw new UnprocessableEntityException({
        statusCode:  422,
        error:       'Leave Policy Violation',
        violations,
        message:     'طلب الإجازة يخالف سياسات المنشأة ونظام العمل السعودي.',
      });
    }

    return { passed: true, violations: [], usedDays, remainingDays };
  }
}
