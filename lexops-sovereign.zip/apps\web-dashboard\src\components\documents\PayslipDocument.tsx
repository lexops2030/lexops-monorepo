/**
 * PayslipDocument — نموذج كشف راتب سيادي
 *
 * يوضّح كيفية استخدام SovereignDocumentRenderer لتغليف أي تقرير.
 * استخدام:
 *   <PayslipDocument run={payrollRun} item={payrollItem} requester={...} c9Seal={...} />
 */

import type { RequesterInfo, C9SealInfo } from '../SovereignDocumentRenderer';
import { SovereignDocumentRenderer } from '../SovereignDocumentRenderer';

// ── Types (mirrors payroll.repository shapes) ─────────────────────────────────

interface PayrollBreakdown {
  baseSalary:        number;
  dailySalary:       number;
  hourlyRate:        number;
  absenceDays:       number;
  absenceDeduction:  number;
  lateMinutes:       number;
  lateDeduction:     number;
  unpaidLeaveDays:   number;
  leaveDeduction:    number;
  overtimeHours:     number;
  overtimeAmount:    number;
  grossSalary:       number;
  totalDeductions:   number;
  netSalary:         number;
}

interface PayslipDocumentProps {
  month:      string;
  employeeName: string;
  nationalId:  string;
  position:    string;
  breakdown:   PayrollBreakdown;
  requester:   RequesterInfo;
  c9Seal:      C9SealInfo;
}

function Row({ label, value, bold, highlight }: {
  label:      string;
  value:      string;
  bold?:      boolean;
  highlight?: 'positive' | 'negative' | 'total';
}) {
  const colors = {
    positive: 'text-green-700 bg-green-50',
    negative: 'text-red-700  bg-red-50',
    total:    'text-primary  bg-primary/5 font-extrabold text-base',
  };
  return (
    <div
      className={`flex justify-between items-center px-3 py-2 rounded-lg ${
        highlight ? colors[highlight] : 'even:bg-neutral-50'
      } ${bold ? 'font-bold' : ''}`}
    >
      <span className="text-sm text-neutral-700">{label}</span>
      <span className={`font-mono text-sm ${highlight ? '' : 'text-neutral-900'}`}>
        {value}
      </span>
    </div>
  );
}

export function PayslipDocument({
  month, employeeName, nationalId, position,
  breakdown, requester, c9Seal,
}: PayslipDocumentProps) {
  const fmt = (n: number) => `${n.toLocaleString('ar-SA', { minimumFractionDigits: 2 })} ﷼`;

  return (
    <SovereignDocumentRenderer
      documentTitle="كشف راتب شهري"
      documentSubtitle={`شهر: ${month} — الموظف: ${employeeName}`}
      requester={requester}
      c9Seal={c9Seal}
      showEntitySeal
    >
      {/* Employee info */}
      <div className="grid grid-cols-3 gap-4 mb-6 text-sm">
        {[
          { label: 'اسم الموظف',     value: employeeName },
          { label: 'الهوية الوطنية', value: nationalId   },
          { label: 'المسمى الوظيفي', value: position     },
        ].map(({ label, value }) => (
          <div key={label} className="bg-neutral-50 rounded-lg p-3 border border-neutral-100">
            <p className="text-[10px] text-neutral-400 uppercase tracking-wide mb-0.5">{label}</p>
            <p className="font-semibold text-primary">{value}</p>
          </div>
        ))}
      </div>

      {/* Salary computation */}
      <div className="space-y-1">
        <p className="text-xs font-bold text-neutral-500 uppercase tracking-widest mb-2">
          تفصيل الراتب
        </p>
        <Row label="الراتب الأساسي"         value={fmt(breakdown.baseSalary)}       highlight="positive" />
        <Row label={`مكافأة عمل إضافي (${breakdown.overtimeHours} ساعة × 1.5)`}
                                            value={fmt(breakdown.overtimeAmount)}    highlight="positive" />
        <div className="border-t border-neutral-200 my-1" />
        <Row label={`خصم غياب (${breakdown.absenceDays} يوم)`}
                                            value={`- ${fmt(breakdown.absenceDeduction)}`} highlight="negative" />
        <Row label={`خصم تأخر (${breakdown.lateMinutes} دقيقة)`}
                                            value={`- ${fmt(breakdown.lateDeduction)}`}    highlight="negative" />
        <Row label={`خصم إجازة غير مدفوعة (${breakdown.unpaidLeaveDays} يوم)`}
                                            value={`- ${fmt(breakdown.leaveDeduction)}`}   highlight="negative" />
        <div className="border-t border-neutral-200 my-1" />
        <Row label="إجمالي الخصومات"        value={`- ${fmt(breakdown.totalDeductions)}`}  bold />
        <Row label="صافي الراتب المستحق"    value={fmt(breakdown.netSalary)}               highlight="total" />
      </div>

      <p className="mt-4 text-[10px] text-neutral-400 text-center">
        تم احتساب الراتب وفق نظام العمل السعودي المادة 87 والمرسوم الملكي 11438.
        هذا الكشف وثيقة رسمية مختومة في سجل C9 اللامتغير.
      </p>
    </SovereignDocumentRenderer>
  );
}
