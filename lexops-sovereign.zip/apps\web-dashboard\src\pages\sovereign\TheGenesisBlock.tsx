/**
 * TheGenesisBlock.tsx — كتلة التكوين السيادية
 * Founder-restricted terminal UI — Foundation Chain + SHA-512 Seal sequence
 */

import { useState, useEffect, useRef } from 'react';
import { Scale, Terminal, Copy, CheckCheck } from 'lucide-react';

// ── Sovereign Theme ────────────────────────────────────────────────────────────

const S = {
  bg900:   '#05060d',
  bg800:   '#0b1121',
  bg700:   '#0f1729',
  bg600:   '#101820',
  border:  '#1e2d4a',
  gold:    '#C8A96B',
  goldDim: '#9A7F45',
  red:     '#f87171',
  green:   '#34d399',
  amber:   '#fbbf24',
  text:    '#e2e8f0',
  muted:   '#64748b',
  termBg:  '#030508',
  termFg:  '#a8b9cc',
};

// ── Types ──────────────────────────────────────────────────────────────────────

type SealPhase = 'idle' | 'computing' | 'pulse' | 'revealed' | 'lexi';

interface ChainEntry {
  tag:    string;
  hash:   string;
  label:  string;
}

// ── Foundation Chain data ──────────────────────────────────────────────────────

const CHAIN: ChainEntry[] = [
  { tag: 'PRD_FOUNDATION',    hash: '0x1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D',  label: 'Product Foundation Seal'          },
  { tag: 'C9_LEDGER_INIT',    hash: '0x9D8E7F6A5B4C3D2E1F0A9B8C7D6E5F4A',  label: 'C9 Immutable Ledger Init'         },
  { tag: 'LEXI_AUTH_BIND',    hash: '0x5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B',  label: 'LEXI AI Authority Binding'        },
  { tag: 'FORTRESS_700',      hash: '0x3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F',  label: 'Fortress 700 Isolation Protocol'  },
  { tag: 'PAYROLL_ENGINE',    hash: '0xF1E2D3C4B5A697889A0B1C2D3E4F5A6B',  label: 'Saudi Payroll Engine v2.0'        },
  { tag: 'COMPLIANCE_CORE',   hash: '0x7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D',  label: 'JSON Logic Compliance Core'       },
  { tag: 'NOTIF_NERVOUS_SYS', hash: '0x2F3A4B5C6D7E8F90A1B2C3D4E5F6A7B8',  label: 'Notifications Nervous System'     },
  { tag: 'GENESIS_CANDIDATE', hash: '',                                       label: 'Genesis Candidate Block'          },
];

const SHA512_MASTER =
  '8f9d2c1b4a5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f' +
  '1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a';

// ── Blinking cursor ────────────────────────────────────────────────────────────

function Cursor() {
  const [vis, setVis] = useState(true);
  useEffect(() => {
    const t = setInterval(() => setVis(v => !v), 500);
    return () => clearInterval(t);
  }, []);
  return <span style={{ color: S.gold, opacity: vis ? 1 : 0 }}>█</span>;
}

// ── Chain row ──────────────────────────────────────────────────────────────────

function ChainRow({
  entry, visible, isLast, sealed,
}: { entry: ChainEntry; visible: boolean; isLast: boolean; sealed: boolean }) {
  return (
    <div style={{
      display:    'flex',
      alignItems: 'flex-start',
      gap:        10,
      padding:    '5px 0',
      opacity:    visible ? 1 : 0,
      transform:  visible ? 'translateY(0)' : 'translateY(4px)',
      transition: 'opacity 0.3s, transform 0.3s',
      fontFamily: 'IBM Plex Mono, Consolas, monospace',
      fontSize:   13,
    }}>
      {/* Check / pending */}
      <span style={{ color: (isLast && !sealed) ? S.amber : S.green, flexShrink: 0 }}>
        {isLast && !sealed ? '[ ]' : '[✓]'}
      </span>

      {/* Tag */}
      <span style={{ color: S.gold, minWidth: 170, flexShrink: 0 }}>{entry.tag.padEnd(18)}</span>

      {/* Hash or pending bar */}
      {isLast && !sealed ? (
        <span style={{ color: S.amber, letterSpacing: '0.04em' }}>
          {'██████████████████'.split('').map((c, i) => (
            <span key={i} style={{ opacity: 0.4 + 0.6 * ((i + Date.now() / 200) % 1) }}>{c}</span>
          ))} PENDING
        </span>
      ) : (
        <span style={{ color: sealed && isLast ? S.green : S.termFg }}>{entry.hash || SHA512_MASTER.slice(0, 34) + '…'}</span>
      )}
    </div>
  );
}

// ── Radial pulse animation (CSS keyframes injected) ───────────────────────────

function PulseRing() {
  return (
    <div style={{ position: 'relative', width: 160, height: 160, margin: '0 auto' }}>
      {[0, 1, 2].map(i => (
        <div key={i} style={{
          position:     'absolute',
          inset:        0,
          borderRadius: '50%',
          border:       `2px solid ${S.gold}`,
          animation:    `genesisRing 1.6s ease-out ${i * 0.4}s infinite`,
          opacity:      0,
        }} />
      ))}
      <div style={{
        position:       'absolute',
        inset:          '30%',
        borderRadius:   '50%',
        background:     `radial-gradient(circle, ${S.gold}80 0%, ${S.gold}20 60%, transparent 80%)`,
        animation:      'genesisCore 1.6s ease-in-out infinite',
      }} />
      <style>{`
        @keyframes genesisRing {
          0%   { transform: scale(0.3); opacity: 0.8; }
          100% { transform: scale(1.8); opacity: 0;   }
        }
        @keyframes genesisCore {
          0%,100% { opacity: 0.6; transform: scale(1);    }
          50%     { opacity: 1;   transform: scale(1.15); }
        }
        @keyframes slideUp {
          from { transform: translateY(40px); opacity: 0; }
          to   { transform: translateY(0);    opacity: 1; }
        }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
      `}</style>
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────

export function TheGenesisBlock() {
  const [visibleRows, setVisibleRows] = useState(0);
  const [phase,       setPhase]       = useState<SealPhase>('idle');
  const [copied,      setCopied]      = useState(false);
  const terminalRef = useRef<HTMLDivElement>(null);

  // Animate chain rows on mount
  useEffect(() => {
    let i = 0;
    const t = setInterval(() => {
      i++;
      setVisibleRows(i);
      if (i >= CHAIN.length) clearInterval(t);
    }, 150);
    return () => clearInterval(t);
  }, []);

  const handleSeal = () => {
    if (phase !== 'idle') return;

    // Phase 1 — computing
    setPhase('computing');

    // Phase 2 — pulse
    setTimeout(() => setPhase('pulse'), 800);

    // Phase 3 — reveal hash
    setTimeout(() => setPhase('revealed'), 1600);

    // Phase 4 — LEXI sign-off
    setTimeout(() => setPhase('lexi'), 2400);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(SHA512_MASTER).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isSealed = phase === 'revealed' || phase === 'lexi';

  return (
    <div dir="rtl" style={{ background: S.bg900, minHeight: '100vh', fontFamily: 'Cairo, IBM Plex Sans Arabic, sans-serif', color: S.text, padding: 32 }}>

      {/* ── Terminal window ───────────────────────────────────────────────────── */}
      <div style={{
        background:   S.termBg,
        border:       `1px solid ${S.border}`,
        borderRadius: 16,
        overflow:     'hidden',
        marginBottom: 24,
        boxShadow:    `0 8px 40px rgba(0,0,0,0.6), 0 0 0 1px ${S.border}`,
      }}>
        {/* macOS traffic lights header */}
        <div style={{
          background:    S.bg800,
          borderBottom:  `1px solid ${S.border}`,
          padding:       '12px 20px',
          display:       'flex',
          alignItems:    'center',
          gap:           8,
        }}>
          {/* Traffic lights */}
          <div style={{ display: 'flex', gap: 7, marginLeft: 'auto' }}>
            {[S.red, S.amber, S.green].map((c, i) => (
              <div key={i} style={{ width: 12, height: 12, borderRadius: '50%', background: c, boxShadow: `0 0 6px ${c}80` }} />
            ))}
          </div>

          {/* Title */}
          <div style={{ flex: 1, textAlign: 'center' }}>
            <span style={{ color: S.muted, fontSize: 12, fontFamily: 'IBM Plex Mono, monospace' }}>
              <Terminal size={12} style={{ display: 'inline', marginLeft: 6, verticalAlign: 'middle' }} />
              LexOps Genesis Terminal v1.0
            </span>
          </div>

          {/* Badge */}
          <div style={{
            background:   `${S.gold}20`,
            border:       `1px solid ${S.gold}40`,
            borderRadius: 99,
            padding:      '2px 10px',
            marginRight:  'auto',
          }}>
            <span style={{ color: S.gold, fontSize: 10, fontWeight: 700, letterSpacing: '0.08em' }}>SOVEREIGN ROOT</span>
          </div>
        </div>

        {/* Terminal body */}
        <div ref={terminalRef} style={{ padding: '24px 28px', minHeight: 340 }}>

          {/* Prompt header */}
          <p style={{ color: S.goldDim, fontSize: 12, fontFamily: 'IBM Plex Mono, monospace', margin: '0 0 16px' }}>
            $ lexops genesis --chain-verify --sovereign-mode --region me-central1
          </p>

          {/* Chain rows */}
          <div style={{ marginBottom: 20 }}>
            {CHAIN.map((entry, i) => (
              <ChainRow
                key={entry.tag}
                entry={entry}
                visible={i < visibleRows}
                isLast={i === CHAIN.length - 1}
                sealed={isSealed}
              />
            ))}
          </div>

          {/* Phase: computing */}
          {(phase === 'computing') && (
            <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 13, marginTop: 12 }}>
              <p style={{ color: S.amber, margin: '0 0 6px' }}>
                {'> Computing SHA-512 Master Hash…'} <Cursor />
              </p>
              <p style={{ color: S.muted, margin: '0 0 4px', fontSize: 11 }}>
                {'  Aggregating 8 module hashes…'}
              </p>
              <p style={{ color: S.muted, margin: 0, fontSize: 11 }}>
                {'  Applying HMAC-SHA256 C9 seal…'}
              </p>
            </div>
          )}

          {/* Phase: pulse (handled outside terminal) */}

          {/* Phase: revealed hash */}
          {isSealed && (
            <div style={{ marginTop: 16, fontFamily: 'IBM Plex Mono, monospace' }}>
              <p style={{ color: S.green, fontSize: 12, margin: '0 0 10px' }}>
                {'[✓] SHA-512 computation complete — 0 errors'}
              </p>
              <div style={{
                background:   `${S.gold}0d`,
                border:       `1px solid ${S.gold}40`,
                borderRadius: 10,
                padding:      '16px 20px',
              }}>
                <p style={{ color: S.gold, fontSize: 11, fontWeight: 700, margin: '0 0 10px', letterSpacing: '0.08em' }}>
                  SHA-512 MASTER HASH
                </p>
                <p style={{ color: S.muted, fontSize: 11, margin: '0 0 8px' }}>{'═'.repeat(50)}</p>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                  <p style={{
                    color:       S.green,
                    fontSize:    12,
                    margin:      0,
                    wordBreak:   'break-all',
                    lineHeight:  1.7,
                    flex:        1,
                    letterSpacing: '0.04em',
                  }}>
                    {SHA512_MASTER}
                  </p>
                  <button
                    onClick={handleCopy}
                    title="نسخ الهاش"
                    style={{
                      background:   S.bg700,
                      border:       `1px solid ${S.border}`,
                      borderRadius: 6,
                      padding:      '6px 8px',
                      cursor:       'pointer',
                      color:        copied ? S.green : S.muted,
                      flexShrink:   0,
                      transition:   'color 0.2s',
                    }}
                  >
                    {copied ? <CheckCheck size={14} /> : <Copy size={14} />}
                  </button>
                </div>
                <p style={{ color: S.muted, fontSize: 11, margin: '8px 0 0' }}>{'═'.repeat(50)}</p>
                <p style={{ color: S.muted, fontSize: 11, margin: '10px 0 0', letterSpacing: '0.04em' }}>
                  SEALED: 2026-04-01T00:00:00Z &nbsp;|&nbsp; me-central1 &nbsp;|&nbsp; Dammam, KSA
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── Pulse animation overlay ───────────────────────────────────────────── */}
      {phase === 'pulse' && (
        <div style={{
          position:       'fixed',
          inset:          0,
          background:     'rgba(3,5,8,0.88)',
          display:        'flex',
          alignItems:     'center',
          justifyContent: 'center',
          zIndex:         500,
          backdropFilter: 'blur(8px)',
        }}>
          <div style={{ textAlign: 'center' }}>
            <PulseRing />
            <p style={{ color: S.gold, fontFamily: 'IBM Plex Mono, monospace', fontSize: 14, marginTop: 24, letterSpacing: '0.1em' }}>
              SEALING GENESIS BLOCK…
            </p>
          </div>
        </div>
      )}

      {/* ── Seal button ───────────────────────────────────────────────────────── */}
      {!isSealed && (
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <button
            onClick={handleSeal}
            disabled={phase !== 'idle' || visibleRows < CHAIN.length}
            style={{
              background:    (phase !== 'idle' || visibleRows < CHAIN.length)
                               ? S.bg700
                               : `linear-gradient(135deg, ${S.gold}, ${S.goldDim})`,
              border:        `2px solid ${(phase !== 'idle' || visibleRows < CHAIN.length) ? S.border : S.gold}`,
              borderRadius:  16,
              padding:       '20px 48px',
              cursor:        (phase !== 'idle' || visibleRows < CHAIN.length) ? 'not-allowed' : 'pointer',
              color:         (phase !== 'idle' || visibleRows < CHAIN.length) ? S.muted : S.bg900,
              fontFamily:    'Cairo, sans-serif',
              fontSize:      16,
              fontWeight:    800,
              display:       'inline-flex',
              alignItems:    'center',
              gap:           14,
              boxShadow:     (phase !== 'idle' || visibleRows < CHAIN.length) ? 'none' : `0 8px 40px ${S.gold}50`,
              transition:    'all 0.3s',
            }}
          >
            <Scale size={22} />
            إصدار الختم السيادي النهائي
            <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 12, opacity: 0.7 }}>(Generate Genesis Hash)</span>
          </button>

          {visibleRows < CHAIN.length && (
            <p style={{ color: S.muted, fontSize: 11, marginTop: 10, fontFamily: 'IBM Plex Mono, monospace' }}>
              جارٍ التحقق من سلسلة التأسيس…
            </p>
          )}
        </div>
      )}

      {/* ── LEXI Sign-off banner ──────────────────────────────────────────────── */}
      {phase === 'lexi' && (
        <div style={{
          background:   `linear-gradient(135deg, ${S.gold}20, ${S.goldDim}12)`,
          border:       `1px solid ${S.gold}50`,
          borderRadius: 20,
          padding:      32,
          animation:    'slideUp 0.6s ease-out forwards',
          position:     'relative',
          overflow:     'hidden',
        }}>
          {/* Glow */}
          <div style={{ position: 'absolute', top: -40, right: -40, width: 200, height: 200, background: `${S.gold}12`, borderRadius: '50%', filter: 'blur(50px)' }} />

          <div style={{ position: 'relative', display: 'flex', alignItems: 'flex-start', gap: 20 }}>
            <div style={{
              background:   `${S.gold}25`,
              border:       `2px solid ${S.gold}50`,
              borderRadius: 14,
              padding:      14,
              flexShrink:   0,
            }}>
              <Scale size={28} color={S.gold} />
            </div>

            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
                <span style={{ color: S.gold, fontWeight: 800, fontSize: 16 }}>رسالة LEXI السيادية الختامية</span>
                <span style={{
                  background:   `${S.green}20`,
                  border:       `1px solid ${S.green}50`,
                  borderRadius: 99,
                  padding:      '2px 10px',
                  color:        S.green,
                  fontSize:     10,
                  fontWeight:   700,
                  letterSpacing: '0.06em',
                }}>
                  GENESIS SEALED ✓
                </span>
              </div>

              <p style={{
                color:      S.text,
                fontSize:   15,
                lineHeight: 2,
                margin:     '0 0 20px',
                fontStyle:  'italic',
                fontWeight: 500,
              }}>
                "النظام السيادي مكتمل وجاهز للانطلاق في السوق السعودية. تم توثيق جميع الوحدات العشرين في سجل C9 اللامتغير. المنصة تحمي حقوق العمال وتلتزم بنظام العمل السعودي والمرسوم الملكي 11438."
              </p>

              <div style={{ display: 'flex', gap: 28, flexWrap: 'wrap' }}>
                {[
                  { label: 'الوحدات الموثّقة', value: '20 / 20',    color: S.green },
                  { label: 'ختم C9',            value: 'VERIFIED',   color: S.gold  },
                  { label: 'المنطقة',            value: 'me-central1', color: S.text  },
                  { label: 'الامتثال',           value: '100%',       color: S.green },
                ].map(m => (
                  <div key={m.label}>
                    <p style={{ color: S.muted, fontSize: 11, margin: 0 }}>{m.label}</p>
                    <p style={{ color: m.color, fontSize: 18, fontWeight: 800, fontFamily: 'IBM Plex Mono, monospace', margin: '4px 0 0' }}>{m.value}</p>
                  </div>
                ))}
              </div>

              <div style={{ marginTop: 20, fontFamily: 'IBM Plex Mono, monospace', fontSize: 11, color: S.muted }}>
                <span style={{ color: S.gold }}>SHA-512:</span> {SHA512_MASTER.slice(0, 32)}…
                &nbsp;|&nbsp;
                <span style={{ color: S.green }}>SEALED 2026-04-01T00:00:00Z</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default TheGenesisBlock;
