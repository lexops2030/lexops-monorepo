import { Body, Controller, Post, Request, Version } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsOptional, IsString, IsNumber, Min } from 'class-validator';
import { LexiService, LexiDecision } from './lexi.service';
import { Roles } from '../auth/firebase.guard';
import { Request as ExpressRequest } from 'express';
import type { LexOpsClaims } from '../auth/firebase.guard';

class AnalyzeViolationDto {
  @IsEnum(['absence', 'lateness', 'misconduct', 'termination', 'grievance'])
  caseType: 'absence' | 'lateness' | 'misconduct' | 'termination' | 'grievance';

  @IsString()
  @IsNotEmpty()
  employeeExcuse: string;

  @IsString()
  @IsOptional()
  evidenceSummary?: string;

  @IsNumber()
  @Min(0)
  @IsOptional()
  priorViolations?: number;

  @IsString()
  @IsNotEmpty()
  caseRef: string;
}

@ApiTags('LEXI — Legal AI Engine')
@ApiBearerAuth('Firebase-JWT')
@Controller('lexi')
export class LexiController {
  constructor(private readonly lexiService: LexiService) {}

  @Post('analyze')
  @Version('1')
  @Roles('entity_admin', 'sovereign', 'freelancer')
  @ApiOperation({ summary: 'Analyze a violation/excuse via LEXI AI engine' })
  async analyzeViolation(
    @Body() dto: AnalyzeViolationDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ): Promise<LexiDecision> {
    return this.lexiService.analyzeViolation({
      ...dto,
      tenantId: req.user.tenantId ?? req.user.uid,
      useFlash: dto.caseType === 'lateness' || dto.caseType === 'absence',
    });
  }
}
