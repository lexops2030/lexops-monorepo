/**
 * LexOps — Rules Engine  (Sprint 6 — Compliance Engine)
 *
 * JSON Logic-based rule executor for Saudi Labor Law compliance automation.
 *
 * Architecture:
 *   - Rules are stored as JSON Logic scripts in /entities/{tenantId}/compliance_rules/{ruleId}
 *   - Each rule defines: trigger conditions, severity mapping, and penalty formula
 *   - ComplianceService builds a rich contextData object and passes it here for evaluation
 *
 * 180-Day Recurrence Rule (إدارة التكرار والعود):
 *   contextData MUST include `recentViolations` array (last 180 days) so rules can:
 *     a) Check `recentViolations.length > 0` to detect repetition
 *     b) Evaluate `daysSincePrior` to apply graduated escalation
 *     c) Override severity: minor → moderate → serious → gross per recurrence count
 *
 * Penalty multiplier table (Saudi Labor Law — Art. 66 + Royal Decree 11438):
 *   Recurrence 0  (first offence)  → multiplier 1.0   (standard penalty)
 *   Recurrence 1  (within 180d)    → multiplier 1.5   (مخالفة مكررة — 50% escalation)
 *   Recurrence 2  (within 180d)    → multiplier 2.0   (تحذير رسمي)
 *   Recurrence 3+ (within 180d)    → multiplier 3.0   + escalate to 'gross' + termination notice
 *
 * External dependency: `json-logic-js` — pure-JS, no eval(), OWASP-safe.
 */

import { Injectable, Logger, BadRequestException } from '@nestjs/common';
// @ts-expect-error — json-logic-js ships a CJS module with no official typings
import jsonLogic from 'json-logic-js';
import {
  ViolationDocument,
  ViolationSeverity,
  ViolationPenalty,
  ViolationType,
} from './violations.repository';

// ── Rule definition stored in Firestore ───────────────────────────────────────

export interface ComplianceRule {
  ruleId:       string;
  name:         string;           // Human-readable Arabic name
  violationType: ViolationType;
  enabled:      boolean;
  logic:        Record<string, unknown>;  // JSON Logic object
  baseSeverity: ViolationSeverity;
  basePenalty:  ViolationPenalty;
  description:  string;
}

// ── Context object injected into JSON Logic evaluation ────────────────────────

export interface RuleContext {
  // ── Employee ──────────────────────────────────────────────────────────────
  employeeId:           string;
  branchId:             string;
  baseSalary:           number;
  dailySalary:          number;   // baseSalary / 30 — precomputed by ComplianceService
  employmentType:       string;

  // ── Attendance (current month) ─────────────────────────────────────────────
  absenceDays:          number;
  consecutiveAbsence:   number;   // consecutive days without check-in
  lateMinutes:          number;
  lateOccurrences:      number;   // distinct days with lateness
  earlyDepartures:      number;
  totalWorkDays:        number;

  // ── Leaves ────────────────────────────────────────────────────────────────
  approvedLeaveDays:    number;
  pendingLeaveRequests: number;
  unpaidLeaveDays:      number;

  // ── 180-Day Disciplinary History (CRITICAL — recurrence rule) ─────────────
  recentViolations:     RecentViolationSummary[];  // last 180 days
  recurrenceCount:      number;    // count of same violationType in last 180 days
  daysSincePrior:       number;    // days since most recent same-type violation (999 if none)
  isRepeated:           boolean;   // true if recurrenceCount >= 1

  // ── Computed penalty helpers ───────────────────────────────────────────────
  penaltyMultiplier:    number;    // derived from recurrenceCount per the multiplier table
  todayIso:             string;    // 'YYYY-MM-DD'
  monthIso:             string;    // 'YYYY-MM'
}

export interface RecentViolationSummary {
  violationId:   string;
  violationType: ViolationType;
  severity:      ViolationSeverity;
  createdAt:     string;          // ISO string
  daysSince:     number;
}

// ── Execution result ──────────────────────────────────────────────────────────

export interface RuleExecutionResult {
  ruleId:           string;
  ruleName:         string;
  triggered:        boolean;
  violationType:    ViolationType;
  finalSeverity:    ViolationSeverity;
  finalPenalty:     ViolationPenalty;
  isRepeated:       boolean;
  recurrenceCount:  number;
  penaltyMultiplier: number;
  rawLogicOutput:   unknown;     // Raw output from json-logic-js for audit trail
  description:      string;     // Bilingual auto-generated description
}

// ── Severity escalation ladder ────────────────────────────────────────────────

const SEVERITY_LADDER: ViolationSeverity[] = ['minor', 'moderate', 'serious', 'gross'];

function escalateSeverity(base: ViolationSeverity, steps: number): ViolationSeverity {
  const idx = SEVERITY_LADDER.indexOf(base);
  return SEVERITY_LADDER[Math.min(idx + steps, SEVERITY_LADDER.length - 1)];
}

// ── Penalty multiplier table (Saudi Labor Law recurrence tiers) ───────────────

function resolvePenaltyMultiplier(recurrenceCount: number): number {
  if (recurrenceCount === 0) return 1.0;
  if (recurrenceCount === 1) return 1.5;
  if (recurrenceCount === 2) return 2.0;
  return 3.0; // 3+ recurrences within 180 days
}

// ── Severity escalation steps per recurrence count ────────────────────────────

function severityEscalationSteps(recurrenceCount: number): number {
  if (recurrenceCount === 0) return 0;
  if (recurrenceCount === 1) return 1;
  if (recurrenceCount === 2) return 2;
  return 3; // force 'gross' on 3rd repetition
}

// ── Rules Engine ──────────────────────────────────────────────────────────────

@Injectable()
export class RulesEngine {
  private readonly logger = new Logger(RulesEngine.name);

  /**
   * Execute a single JSON Logic rule against a fully-hydrated RuleContext.
   *
   * The context MUST contain recentViolations (180 days) injected by ComplianceService
   * before this method is called. This ensures:
   *   1. The JSON Logic script can reference recentViolations, recurrenceCount, isRepeated
   *   2. Severity and penalty are escalated according to the 180-day recurrence table
   *   3. The audit trail records penaltyMultiplier and raw logic output for C9 sealing
   */
  executeRule(rule: ComplianceRule, context: RuleContext): RuleExecutionResult {
    // ── Safety: verify rule is enabled ──────────────────────────────────────
    if (!rule.enabled) {
      return this.notTriggered(rule, context);
    }

    // ── Execute JSON Logic ────────────────────────────────────────────────────
    let rawOutput: unknown;
    try {
      rawOutput = jsonLogic.apply(rule.logic, context);
    } catch (err) {
      this.logger.error(
        `[RulesEngine] JSON Logic evaluation error for rule '${rule.ruleId}': ${err}`,
      );
      throw new BadRequestException(
        `خطأ في تنفيذ قاعدة الامتثال '${rule.ruleId}': ${String(err)}`,
      );
    }

    const triggered = Boolean(rawOutput);
    if (!triggered) {
      return this.notTriggered(rule, context);
    }

    // ── 180-Day Recurrence Rule ───────────────────────────────────────────────
    const recurrenceCount   = context.recurrenceCount;
    const penaltyMultiplier = resolvePenaltyMultiplier(recurrenceCount);
    const escalationSteps   = severityEscalationSteps(recurrenceCount);
    const finalSeverity     = escalateSeverity(rule.baseSeverity, escalationSteps);
    const isRepeated        = context.isRepeated;

    // ── Compute final penalty ─────────────────────────────────────────────────
    const finalPenalty = this.applyMultiplier(
      rule.basePenalty,
      penaltyMultiplier,
      context.dailySalary,
      finalSeverity,
    );

    // ── Build bilingual description ───────────────────────────────────────────
    const description = this.buildDescription({
      rule,
      context,
      finalSeverity,
      recurrenceCount,
      penaltyMultiplier,
    });

    this.logger.warn(
      `[RulesEngine] TRIGGERED — rule='${rule.ruleId}' ` +
      `employee='${context.employeeId}' ` +
      `severity=${finalSeverity} repeated=${isRepeated} ` +
      `recurrence=${recurrenceCount} multiplier=×${penaltyMultiplier}`,
    );

    return {
      ruleId:           rule.ruleId,
      ruleName:         rule.name,
      triggered:        true,
      violationType:    rule.violationType,
      finalSeverity,
      finalPenalty,
      isRepeated,
      recurrenceCount,
      penaltyMultiplier,
      rawLogicOutput:   rawOutput,
      description,
    };
  }

  /**
   * Execute a batch of rules for a single employee context.
   * Returns only triggered results, sorted by severity (gross first).
   */
  executeBatch(
    rules:   ComplianceRule[],
    context: RuleContext,
  ): RuleExecutionResult[] {
    const results = rules
      .map(r => this.executeRule(r, context))
      .filter(r => r.triggered);

    // Sort: most severe first
    results.sort(
      (a, b) =>
        SEVERITY_LADDER.indexOf(b.finalSeverity) -
        SEVERITY_LADDER.indexOf(a.finalSeverity),
    );

    return results;
  }

  // ── Private helpers ────────────────────────────────────────────────────────

  private notTriggered(rule: ComplianceRule, context: RuleContext): RuleExecutionResult {
    return {
      ruleId:           rule.ruleId,
      ruleName:         rule.name,
      triggered:        false,
      violationType:    rule.violationType,
      finalSeverity:    rule.baseSeverity,
      finalPenalty:     rule.basePenalty,
      isRepeated:       context.isRepeated,
      recurrenceCount:  context.recurrenceCount,
      penaltyMultiplier: 1.0,
      rawLogicOutput:   false,
      description:      '',
    };
  }

  /**
   * Apply the recurrence multiplier to the base penalty.
   * For deduction: deductionSar = baseSar * multiplier (capped at 0.5 × monthly salary).
   * For suspension: suspensionDays escalates with severity tier.
   * For termination_notice: no amount, just the notice itself.
   */
  private applyMultiplier(
    base:            ViolationPenalty,
    multiplier:      number,
    dailySalary:     number,
    finalSeverity:   ViolationSeverity,
  ): ViolationPenalty {
    if (base.type === 'deduction' && base.deductionSar !== undefined) {
      // Cap: max deduction per violation = 5 days salary (Saudi Labor Law Art. 66)
      const rawAmount = Math.round(base.deductionSar * multiplier * 100) / 100;
      const cap       = dailySalary * 5;
      return {
        ...base,
        deductionSar: Math.min(rawAmount, cap),
        description:  base.description +
          (multiplier > 1 ? ` [مخالفة مكررة ×${multiplier} — عقوبة مضاعفة]` : ''),
      };
    }

    if (base.type === 'suspension' && base.suspensionDays !== undefined) {
      const suspensionDays = Math.min(
        Math.ceil(base.suspensionDays * multiplier),
        finalSeverity === 'gross' ? 30 : 14,  // cap: 30d gross, 14d otherwise
      );
      return {
        ...base,
        suspensionDays,
        description: base.description +
          (multiplier > 1 ? ` [مخالفة مكررة — إيقاف ${suspensionDays} يوم]` : ''),
      };
    }

    // For 'gross' severity repeated violations: escalate to termination notice
    if (finalSeverity === 'gross' && multiplier >= 3.0) {
      return {
        type:        'termination_notice',
        description: 'إشعار بإنهاء الخدمة — مخالفة جسيمة متكررة وفق نظام العمل السعودي المادة 80.',
      };
    }

    return base;
  }

  private buildDescription(params: {
    rule:             ComplianceRule;
    context:          RuleContext;
    finalSeverity:    ViolationSeverity;
    recurrenceCount:  number;
    penaltyMultiplier: number;
  }): string {
    const { rule, context, finalSeverity, recurrenceCount, penaltyMultiplier } = params;

    const severityAr: Record<ViolationSeverity, string> = {
      minor:    'بسيطة',
      moderate: 'متوسطة',
      serious:  'جسيمة',
      gross:    'جسيمة جداً',
    };

    const base = `[${rule.name}] ` +
      `الموظف: ${context.employeeId} — ` +
      `درجة الخطورة: ${severityAr[finalSeverity]} — ` +
      `تاريخ: ${context.todayIso}`;

    if (recurrenceCount === 0) {
      return base + ` — مخالفة أولى.`;
    }

    return base +
      ` — مخالفة مكررة (التكرار رقم ${recurrenceCount} خلال 180 يوم)` +
      ` — مضاعف العقوبة: ×${penaltyMultiplier}` +
      (recurrenceCount >= 3
        ? ' — تحذير نهائي: تكرار المخالفة يستوجب إنهاء الخدمة.'
        : '');
  }
}

// ── Built-in Default Rules (seed data for new entities) ───────────────────────
// These are used as fallback when no custom rules exist in Firestore.

export const DEFAULT_COMPLIANCE_RULES: Omit<ComplianceRule, 'ruleId'>[] = [
  {
    name:          'غياب غير مبرر (3 أيام متصلة)',
    violationType: 'unauthorized_absence',
    enabled:       true,
    baseSeverity:  'serious',
    basePenalty: {
      type:         'deduction',
      description:  'خصم 3 أيام عمل من الراتب وفق المادة 80 من نظام العمل.',
      deductionSar: 0,  // ComplianceService will inject dailySalary * 3 dynamically
    },
    logic: { '>=': [{ var: 'consecutiveAbsence' }, 3] },
    description: 'يُطبَّق عند غياب الموظف 3 أيام متصلة أو أكثر بدون إذن.',
  },
  {
    name:          'تأخر متكرر (5 مرات في الشهر)',
    violationType: 'repeated_lateness',
    enabled:       true,
    baseSeverity:  'minor',
    basePenalty: {
      type:         'warning',
      description:  'إنذار كتابي رسمي بسبب التأخر المتكرر.',
    },
    logic: { '>=': [{ var: 'lateOccurrences' }, 5] },
    description: 'يُطبَّق عند التأخر 5 مرات أو أكثر في الشهر الواحد.',
  },
  {
    name:          'تأخر شديد (إجمالي > 120 دقيقة في الشهر)',
    violationType: 'repeated_lateness',
    enabled:       true,
    baseSeverity:  'moderate',
    basePenalty: {
      type:         'deduction',
      description:  'خصم يوم عمل واحد بسبب التأخر الشديد المتراكم.',
      deductionSar: 0,  // injected dynamically
    },
    logic: { '>=': [{ var: 'lateMinutes' }, 120] },
    description: 'يُطبَّق عند تجاوز إجمالي دقائق التأخر 120 دقيقة في الشهر.',
  },
  {
    name:          'تلاعب بالحضور (موقع وهمي)',
    violationType: 'attendance_fraud',
    enabled:       true,
    baseSeverity:  'serious',
    basePenalty: {
      type:         'suspension',
      description:  'إيقاف عن العمل يومان بسبب التلاعب بسجل الحضور.',
      suspensionDays: 2,
    },
    logic: { '>=': [{ var: 'spoofDetectedCount' }, 1] },
    description: 'يُطبَّق فور اكتشاف محاولة تلاعب بالموقع الجغرافي أثناء تسجيل الحضور.',
  },
  {
    name:          'غياب متكرر (أكثر من 10% من أيام العمل)',
    violationType: 'unauthorized_absence',
    enabled:       true,
    baseSeverity:  'moderate',
    basePenalty: {
      type:         'warning',
      description:  'إنذار رسمي بسبب تجاوز نسبة الغياب 10% من أيام العمل.',
    },
    logic: {
      '>': [
        { '/': [{ var: 'absenceDays' }, { var: 'totalWorkDays' }] },
        0.10,
      ],
    },
    description: 'يُطبَّق عند تجاوز نسبة الغياب 10% من إجمالي أيام العمل في الشهر.',
  },
];
