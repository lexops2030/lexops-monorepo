/**
 * LexOps — Compliance Service  (Sprint 6 — Compliance Engine)
 *
 * Orchestrates the full compliance evaluation pipeline:
 *
 *   1. buildEmployeeContext(tenantId, employeeId, month)
 *      Fetches and merges data from:
 *        a) EmployeesRepository   — base salary, branch, employment type
 *        b) AttendanceRepository  — absences, lateness, spoof counts
 *        c) LeavesService         — approved/pending/unpaid leaves
 *        d) ViolationsRepository  — findRecentByEmployee(180)  ← 180-Day Recurrence Rule
 *
 *   2. loadEntityRules(tenantId)
 *      Reads JSON Logic rules from Firestore (falls back to DEFAULT_COMPLIANCE_RULES).
 *
 *   3. runComplianceScan(tenantId, employeeId, month)
 *      Builds context → executes rules → for each triggered result:
 *        - Creates a ViolationDocument with isRepeated / priorViolationId
 *        - Seals event in C9 Ledger (AUTO_VIOLATION_GENERATED)
 *
 *   4. runEntityWideScan(tenantId, month)
 *      Iterates all active employees and calls runComplianceScan() for each.
 *      Designed to be called by Cloud Scheduler at month-end.
 */

import {
  Injectable, Logger, NotFoundException, Inject,
} from '@nestjs/common';
import { Firestore, FieldValue } from '@google-cloud/firestore';
import { getFirestore } from 'firebase-admin/firestore';
import {
  ViolationsRepository,
  ViolationDocument,
  ViolationSeverity,
  ViolationType,
  RecentViolationSummary as _Placeholder,
} from './violations.repository';
import {
  RulesEngine,
  ComplianceRule,
  RuleContext,
  RuleExecutionResult,
  RecentViolationSummary,
  DEFAULT_COMPLIANCE_RULES,
} from './rules.engine';
import { C9LedgerRepository } from '../../database/c9-ledger.repository';
import { LeavesService } from '../leaves/leaves.service';
import { randomUUID } from 'crypto';

// ── Output types ──────────────────────────────────────────────────────────────

export interface ComplianceScanResult {
  tenantId:      string;
  employeeId:    string;
  month:         string;
  scannedAt:     string;
  triggeredCount: number;
  violations:    ViolationDocument[];
  summary: {
    gross:    number;
    serious:  number;
    moderate: number;
    minor:    number;
  };
}

export interface EntityWideScanResult {
  tenantId:       string;
  month:          string;
  employeesScanned: number;
  totalViolations:  number;
  byEmployee:     ComplianceScanResult[];
}

// ── Service ───────────────────────────────────────────────────────────────────

@Injectable()
export class ComplianceService {
  private readonly logger = new Logger(ComplianceService.name);
  private db: Firestore;

  constructor(
    private readonly violationsRepo: ViolationsRepository,
    private readonly rulesEngine:    RulesEngine,
    private readonly c9:             C9LedgerRepository,
    private readonly leavesService:  LeavesService,
  ) {
    this.db = getFirestore();
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // CONTEXT BUILDER — Injects 180-Day Disciplinary History
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * Build a fully-hydrated RuleContext for a single employee in a given month.
   *
   * Data sources merged:
   *   1. Employee profile   (base salary, branch, employment type)
   *   2. Attendance stats   (absences, lateness, spoof detections, early departures)
   *   3. Leave summary      (approved/unpaid/pending leave days)
   *   4. Violations history (last 180 days — 180-Day Recurrence Rule)
   *
   * The violations history is injected LAST so it can inform:
   *   - recurrenceCount (same type in 180d window)
   *   - daysSincePrior  (days since most recent same-type violation)
   *   - isRepeated      (bool — drives penalty multiplier in RulesEngine)
   *
   * @param targetViolationType When provided, recurrenceCount/daysSincePrior are
   *   computed specifically for that type. Otherwise uses overall violations.
   */
  async buildEmployeeContext(
    tenantId:             string,
    employeeId:           string,
    month:                string,
    targetViolationType?: ViolationType,
  ): Promise<RuleContext> {
    const { monthStart, monthEnd } = this.monthRange(month);
    const todayIso = new Date().toISOString().slice(0, 10);

    // ── 1. Employee profile ──────────────────────────────────────────────────
    const empSnap = await this.db
      .collection('entities').doc(tenantId)
      .collection('employees').doc(employeeId)
      .get();

    if (!empSnap.exists) {
      throw new NotFoundException(
        `الموظف '${employeeId}' غير موجود في المنشأة '${tenantId}'.`,
      );
    }

    const emp     = empSnap.data()!;
    const baseSalary  = (emp['baseSalary']  as number) ?? 0;
    const dailySalary = Math.round((baseSalary / 30) * 100) / 100;

    // ── 2. Attendance stats for the month ────────────────────────────────────
    const attendanceStats = await this.fetchAttendanceStats(
      tenantId, employeeId, monthStart, monthEnd,
    );

    // ── 3. Leave summary ─────────────────────────────────────────────────────
    const leaveData = await this.leavesService.calculateLeaveDeductions(
      tenantId, employeeId, monthStart, monthEnd, dailySalary,
    );

    const allLeaves    = await this.leavesService.findMyLeaves(tenantId, employeeId);
    const pending      = allLeaves.filter(l =>
      l.status === 'requested' &&
      l.startDate >= monthStart &&
      l.endDate   <= monthEnd,
    );
    const approved     = allLeaves.filter(l =>
      l.status === 'approved' &&
      l.startDate >= monthStart &&
      l.endDate   <= monthEnd,
    );

    const approvedLeaveDays  = approved.reduce((s, l) => s + l.daysRequested, 0);
    const pendingLeaveRequests = pending.length;

    // ── 4. 180-Day Disciplinary History (CRITICAL — Recurrence Rule) ──────────
    //
    // This step MUST happen AFTER all other context is built so the context
    // passed to RulesEngine always contains the full violations array.
    //
    const RECURRENCE_WINDOW = 180;
    const recentAll = await this.violationsRepo.findRecentByEmployee(
      tenantId, employeeId, RECURRENCE_WINDOW,
    );

    // Filter to same violation type if scanning a specific rule
    const recentSameType = targetViolationType
      ? recentAll.filter(v => v.violationType === targetViolationType)
      : recentAll;

    const recentViolations: RecentViolationSummary[] = recentSameType.map(v => {
      const createdAt  = (v.createdAt as unknown as { toDate?: () => Date })?.toDate?.()
        ?? new Date();
      const daysSince  = Math.floor((Date.now() - createdAt.getTime()) / 86_400_000);
      return {
        violationId:   v.violationId,
        violationType: v.violationType,
        severity:      v.severity,
        createdAt:     createdAt.toISOString(),
        daysSince,
      };
    });

    const recurrenceCount = recentViolations.length;
    const isRepeated      = recurrenceCount > 0;
    const daysSincePrior  = isRepeated
      ? recentViolations[0].daysSince   // sorted desc by createdAt → [0] is most recent
      : 999;

    const penaltyMultiplier =
      recurrenceCount === 0 ? 1.0 :
      recurrenceCount === 1 ? 1.5 :
      recurrenceCount === 2 ? 2.0 : 3.0;

    return {
      employeeId,
      branchId:             (emp['branchId']       as string) ?? '',
      baseSalary,
      dailySalary,
      employmentType:       (emp['employmentType']  as string) ?? 'full_time',

      // Attendance
      absenceDays:          attendanceStats.absenceDays,
      consecutiveAbsence:   attendanceStats.consecutiveAbsence,
      lateMinutes:          attendanceStats.lateMinutes,
      lateOccurrences:      attendanceStats.lateOccurrences,
      earlyDepartures:      attendanceStats.earlyDepartures,
      totalWorkDays:        attendanceStats.totalWorkDays,
      // Expose spoof count for rules that reference it
      ...(({ spoofDetectedCount: attendanceStats.spoofDetectedCount }) as Record<string, unknown>),

      // Leaves
      approvedLeaveDays,
      pendingLeaveRequests,
      unpaidLeaveDays:      leaveData.unpaidDays,

      // 180-Day Disciplinary History
      recentViolations,
      recurrenceCount,
      daysSincePrior,
      isRepeated,
      penaltyMultiplier,

      todayIso,
      monthIso: month,
    };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // RULE LOADING
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * Load enabled compliance rules for a tenant from Firestore.
   * Falls back to DEFAULT_COMPLIANCE_RULES if no custom rules are defined.
   */
  async loadEntityRules(tenantId: string): Promise<ComplianceRule[]> {
    const snap = await this.db
      .collection('entities').doc(tenantId)
      .collection('compliance_rules')
      .where('enabled', '==', true)
      .get();

    if (!snap.empty) {
      return snap.docs.map(d => d.data() as ComplianceRule);
    }

    // Seed defaults with generated IDs
    this.logger.log(`[Compliance] No custom rules for tenant ${tenantId} — using defaults.`);
    return DEFAULT_COMPLIANCE_RULES.map((r, i) => ({
      ...r,
      ruleId: `default_rule_${String(i + 1).padStart(2, '0')}`,
    }));
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // COMPLIANCE SCAN — Single Employee
  // ══════════════════════════════════════════════════════════════════════════════

  async runComplianceScan(
    tenantId:   string,
    employeeId: string,
    month:      string,
    actorUid    = 'system',
  ): Promise<ComplianceScanResult> {
    this.logger.log(`[Compliance] Scanning employee=${employeeId} tenant=${tenantId} month=${month}`);

    const rules = await this.loadEntityRules(tenantId);

    // Build context with full 180-day history
    const context = await this.buildEmployeeContext(tenantId, employeeId, month);

    // Execute all rules
    const triggered = this.rulesEngine.executeBatch(rules, context);

    const violations: ViolationDocument[] = [];

    for (const result of triggered) {
      // Re-compute context scoped to this violation type for accurate recurrence
      const scopedContext = await this.buildEmployeeContext(
        tenantId, employeeId, month, result.violationType,
      );

      // Resolve prior violation ID for audit trail
      const priorViolationId = scopedContext.recentViolations[0]?.violationId;
      const daysSincePrior   = scopedContext.recentViolations[0]?.daysSince;

      // Dynamically inject dailySalary into deduction penalty (for default rules with SAR=0)
      const finalPenalty = this.hydratePenalty(result.finalPenalty, scopedContext.dailySalary);

      const violation = await this.violationsRepo.create(tenantId, {
        employeeId,
        branchId:          context.branchId,
        violationType:     result.violationType,
        severity:          result.finalSeverity,
        source:            'auto_rule',
        status:            'open',
        ruleId:            result.ruleId,
        isRepeated:        result.isRepeated,
        priorViolationId,
        daysSincePrior,
        penalty:           finalPenalty,
        description:       result.description,
        evidenceRefs:      [],
        createdBy:         actorUid,
      });

      violations.push(violation);

      // C9 Seal: AUTO_VIOLATION_GENERATED
      await this.c9.append({
        tenantId,
        eventType:   'AUTO_VIOLATION_GENERATED',
        actorUid:    actorUid,
        actorRole:   'system',
        subjectUid:  employeeId,
        subjectType: 'violation',
        payload: {
          violationId:      violation.violationId,
          ruleId:           result.ruleId,
          ruleName:         result.ruleName,
          violationType:    result.violationType,
          severity:         result.finalSeverity,
          isRepeated:       result.isRepeated,
          recurrenceCount:  result.recurrenceCount,
          penaltyMultiplier: result.penaltyMultiplier,
          daysSincePrior,
          priorViolationId,
          month,
        },
      });

      this.logger.warn(
        `[Compliance] Violation created: ${violation.violationId} ` +
        `type=${result.violationType} severity=${result.finalSeverity} ` +
        `repeated=${result.isRepeated} multiplier=×${result.penaltyMultiplier}`,
      );
    }

    const summary = this.buildSummary(violations);

    return {
      tenantId,
      employeeId,
      month,
      scannedAt:     new Date().toISOString(),
      triggeredCount: violations.length,
      violations,
      summary,
    };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // ENTITY-WIDE SCAN — Cloud Scheduler month-end
  // ══════════════════════════════════════════════════════════════════════════════

  async runEntityWideScan(
    tenantId:  string,
    month:     string,
    actorUid = 'system',
  ): Promise<EntityWideScanResult> {
    this.logger.log(`[Compliance] Entity-wide scan: tenant=${tenantId} month=${month}`);

    const empSnap = await this.db
      .collection('entities').doc(tenantId)
      .collection('employees')
      .where('status', '==', 'active')
      .get();

    const byEmployee: ComplianceScanResult[] = [];
    let totalViolations = 0;

    for (const doc of empSnap.docs) {
      const employeeId = doc.id;
      try {
        const result = await this.runComplianceScan(tenantId, employeeId, month, actorUid);
        byEmployee.push(result);
        totalViolations += result.triggeredCount;
      } catch (err) {
        this.logger.error(
          `[Compliance] Scan failed for employee=${employeeId}: ${err}`,
        );
      }
    }

    // C9 Seal: ENTITY_COMPLIANCE_SCAN_COMPLETED
    await this.c9.append({
      tenantId,
      eventType:   'ENTITY_COMPLIANCE_SCAN_COMPLETED',
      actorUid,
      actorRole:   'system',
      subjectUid:  tenantId,
      subjectType: 'compliance_scan',
      payload: {
        month,
        employeesScanned: empSnap.size,
        totalViolations,
      },
    });

    return {
      tenantId,
      month,
      employeesScanned: empSnap.size,
      totalViolations,
      byEmployee,
    };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // QUERIES
  // ══════════════════════════════════════════════════════════════════════════════

  getOpenViolations(tenantId: string) {
    return this.violationsRepo.findOpenByTenant(tenantId);
  }

  getEmployeeViolations(tenantId: string, employeeId: string) {
    return this.violationsRepo.findByEmployee(tenantId, employeeId);
  }

  getRecentViolations(tenantId: string, employeeId: string, windowDays = 180) {
    return this.violationsRepo.findRecentByEmployee(tenantId, employeeId, windowDays);
  }

  async resolveViolation(
    tenantId:       string,
    violationId:    string,
    resolvedBy:     string,
    resolutionNote: string,
  ) {
    await this.violationsRepo.resolve(tenantId, violationId, resolvedBy, resolutionNote);

    await this.c9.append({
      tenantId,
      eventType:   'VIOLATION_RESOLVED',
      actorUid:    resolvedBy,
      actorRole:   'entity_admin',
      subjectUid:  violationId,
      subjectType: 'violation',
      payload:     { violationId, resolutionNote },
    });

    return { message: `تم حل المخالفة '${violationId}' وختمها في C9.` };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // PRIVATE HELPERS
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * Fetch attendance stats for a single employee in a date range.
   * Reads accepted check-in records from Firestore.
   */
  private async fetchAttendanceStats(
    tenantId:   string,
    employeeId: string,
    monthStart: string,
    monthEnd:   string,
  ) {
    const snap = await this.db
      .collection('entities').doc(tenantId)
      .collection('attendance')
      .where('employeeUid', '==', employeeId)
      .where('eventType', '==', 'check_in')
      .get();

    const records = snap.docs
      .map(d => d.data())
      .filter(d => {
        const ts  = new Date(d['serverTimestampMs'] as number).toISOString().slice(0, 10);
        return ts >= monthStart && ts <= monthEnd;
      });

    const acceptedRecords = records.filter(d => d['status'] === 'accepted');

    const presentDays = new Set(
      acceptedRecords.map(d =>
        new Date(d['serverTimestampMs'] as number).toISOString().slice(0, 10),
      ),
    );

    const totalWorkDays  = this.countWorkingDays(monthStart, monthEnd);
    const absenceDays    = Math.max(0, totalWorkDays - presentDays.size);
    const lateMinutes    = acceptedRecords.reduce((s, d) => s + ((d['lateMinutes'] as number) ?? 0), 0);
    const lateOccurrences = acceptedRecords.filter(d => ((d['lateMinutes'] as number) ?? 0) > 0).length;
    const earlyDepartures = records.filter(d => d['earlyDepartureMinutes'] as number > 0).length;
    const spoofDetectedCount = records.filter(d => d['isMockSuspected'] === true).length;

    // Consecutive absence: max streak of absent working days
    const consecutiveAbsence = this.maxConsecutiveAbsence(
      monthStart, monthEnd, presentDays,
    );

    return {
      absenceDays,
      consecutiveAbsence,
      lateMinutes,
      lateOccurrences,
      earlyDepartures,
      totalWorkDays,
      spoofDetectedCount,
    };
  }

  private maxConsecutiveAbsence(
    monthStart: string,
    monthEnd:   string,
    presentDays: Set<string>,
  ): number {
    let maxStreak = 0;
    let streak    = 0;
    const cursor  = new Date(monthStart);
    const end     = new Date(monthEnd);

    while (cursor <= end) {
      const iso = cursor.toISOString().slice(0, 10);
      const day = cursor.getDay();
      if (day !== 5 && day !== 6) {  // skip Friday/Saturday (Saudi weekend)
        if (!presentDays.has(iso)) {
          streak++;
          maxStreak = Math.max(maxStreak, streak);
        } else {
          streak = 0;
        }
      }
      cursor.setDate(cursor.getDate() + 1);
    }
    return maxStreak;
  }

  private countWorkingDays(startDate: string, endDate: string): number {
    let count  = 0;
    const cursor = new Date(startDate);
    const end    = new Date(endDate);
    while (cursor <= end) {
      const day = cursor.getDay();
      if (day !== 5 && day !== 6) count++;
      cursor.setDate(cursor.getDate() + 1);
    }
    return count;
  }

  private monthRange(month: string): { monthStart: string; monthEnd: string } {
    const [y, m]  = month.split('-').map(Number);
    const lastDay = new Date(y, m, 0).getDate();
    return {
      monthStart: `${month}-01`,
      monthEnd:   `${month}-${String(lastDay).padStart(2, '0')}`,
    };
  }

  /**
   * Inject the actual dailySalary into penalty.deductionSar for default rules
   * that store deductionSar = 0 as a placeholder.
   */
  private hydratePenalty(
    penalty:     ViolationDocument['penalty'],
    dailySalary: number,
  ): ViolationDocument['penalty'] {
    if (penalty.type === 'deduction' && (penalty.deductionSar ?? 0) === 0) {
      return {
        ...penalty,
        deductionSar: Math.round(dailySalary * 3 * 100) / 100, // default: 3 days
      };
    }
    return penalty;
  }

  private buildSummary(violations: ViolationDocument[]) {
    return {
      gross:    violations.filter(v => v.severity === 'gross').length,
      serious:  violations.filter(v => v.severity === 'serious').length,
      moderate: violations.filter(v => v.severity === 'moderate').length,
      minor:    violations.filter(v => v.severity === 'minor').length,
    };
  }
}
