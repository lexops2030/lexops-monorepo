import { Module } from '@nestjs/common';
import { GlobalLedgerService } from './global-ledger.service';
import { GlobalLedgerController } from './global-ledger.module';
import { DatabaseModule } from '../../database/database.module';

@Module({
  imports:     [DatabaseModule],
  providers:   [GlobalLedgerService],
  controllers: [GlobalLedgerController],
  exports:     [GlobalLedgerService],
})
export class GlobalLedgerModule {}
