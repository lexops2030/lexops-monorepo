import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  CalendarDays, CheckCircle2, AlertCircle,
  ShieldAlert, Info, XCircle,
} from 'lucide-react';
import { differenceInCalendarDays, parseISO, format } from 'date-fns';
import { ar } from 'date-fns/locale';
import { Button } from '../../../components/ui/Button';
import { Input } from '../../../components/ui/Input';
import { Select } from '../../../components/ui/Select';
import api from '../../../lib/api';
import { cn } from '../../../lib/utils';

// ── Schema ────────────────────────────────────────────────────────────────────

const today = new Date().toISOString().slice(0, 10);

const leaveSchema = z.object({
  leaveType: z.enum(['annual', 'sick', 'unpaid', 'other']),
  startDate: z.string().min(1, 'تاريخ البداية مطلوب'),
  endDate:   z.string().min(1, 'تاريخ النهاية مطلوب'),
  reason:    z.string().min(5, 'السبب يجب أن يكون 5 أحرف على الأقل'),
}).refine(
  (d) => d.startDate <= d.endDate,
  { message: 'تاريخ البداية يجب أن يكون قبل أو يساوي تاريخ النهاية', path: ['endDate'] },
).refine(
  (d) => d.startDate >= today,
  { message: 'لا يمكن تقديم إجازة بأثر رجعي', path: ['startDate'] },
);

type LeaveFormValues = z.infer<typeof leaveSchema>;

// ── Helpers ───────────────────────────────────────────────────────────────────

const LEAVE_TYPE_LABELS: Record<string, { label: string; color: string; description: string }> = {
  annual:  { label: 'سنوية',         color: 'bg-primary/10 text-primary',         description: '21 يوم/سنة — مدفوعة (نظام العمل م. 109)' },
  sick:    { label: 'مرضية',         color: 'bg-blue-50 text-blue-700',           description: 'مدفوعة — يُشترط شهادة طبية' },
  unpaid:  { label: 'بدون راتب',    color: 'bg-red-50 text-red-700',             description: 'خصم يومي من الراتب' },
  other:   { label: 'أخرى',          color: 'bg-neutral-100 text-neutral-600',    description: 'بتقدير المنشأة' },
};

const LEAVE_TYPE_OPTIONS = [
  { value: '',        label: '-- اختر نوع الإجازة --' },
  { value: 'annual',  label: 'إجازة سنوية (مدفوعة)' },
  { value: 'sick',    label: 'إجازة مرضية (مدفوعة)' },
  { value: 'unpaid',  label: 'إجازة بدون راتب' },
  { value: 'other',   label: 'إجازة أخرى' },
];

interface LeaveDocument {
  leaveId: string;
  leaveType: string;
  status: string;
  startDate: string;
  endDate: string;
  daysRequested: number;
  reason: string;
}

const STATUS_STYLES: Record<string, string> = {
  requested: 'bg-amber-50 text-amber-700 border-amber-200',
  approved:  'bg-green-50 text-green-700 border-green-200',
  rejected:  'bg-red-50 text-red-700 border-red-200',
  cancelled: 'bg-neutral-100 text-neutral-500 border-neutral-200',
};
const STATUS_LABELS: Record<string, string> = {
  requested: 'قيد المراجعة',
  approved:  'معتمدة',
  rejected:  'مرفوضة',
  cancelled: 'ملغاة',
};

const TENANT_ID = import.meta.env.VITE_DEMO_TENANT_ID ?? 'ENTITY_700';

// ── Component ─────────────────────────────────────────────────────────────────

export default function LeaveRequestForm() {
  const queryClient = useQueryClient();
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [violations, setViolations] = useState<string[]>([]);

  const { data: myLeaves = [], isLoading: leavesLoading } = useQuery<LeaveDocument[]>({
    queryKey: ['my-leaves', TENANT_ID],
    queryFn: () => api.get(`/entities/${TENANT_ID}/leaves/my`).then((r) => r.data),
  });

  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm<LeaveFormValues>({
    resolver: zodResolver(leaveSchema),
    defaultValues: { leaveType: 'annual', startDate: today, endDate: today },
  });

  const startDate  = watch('startDate');
  const endDate    = watch('endDate');
  const leaveType  = watch('leaveType');

  const daysPreview = startDate && endDate && startDate <= endDate
    ? differenceInCalendarDays(parseISO(endDate), parseISO(startDate)) + 1
    : 0;

  const selectedTypeInfo = LEAVE_TYPE_LABELS[leaveType];

  const mutation = useMutation({
    mutationFn: (data: LeaveFormValues) =>
      api.post(`/entities/${TENANT_ID}/leaves`, data).then((r) => r.data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-leaves', TENANT_ID] });
      setViolations([]);
      setSuccessMsg(`تم تقديم طلب الإجازة بنجاح. (${daysPreview} يوم)`);
      reset({ leaveType: 'annual', startDate: today, endDate: today, reason: '' });
      setTimeout(() => setSuccessMsg(null), 5000);
    },
    onError: (err: unknown) => {
      const resp = (err as { response?: { data?: { violations?: string[]; message?: string } } })?.response?.data;
      if (resp?.violations?.length) {
        setViolations(resp.violations);
      } else {
        setViolations([resp?.message ?? 'حدث خطأ أثناء تقديم الطلب']);
      }
    },
  });

  const cancelMutation = useMutation({
    mutationFn: (leaveId: string) =>
      api.delete(`/entities/${TENANT_ID}/leaves/${leaveId}`).then((r) => r.data),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ['my-leaves', TENANT_ID] }),
  });

  return (
    <div className="grid grid-cols-1 gap-8 lg:grid-cols-5">
      {/* ── Left: Request Form ── */}
      <div className="lg:col-span-2">
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10">
            <CalendarDays className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-neutral-900">طلب إجازة جديدة</h2>
            <p className="text-sm text-neutral-500">يُطبَّق محرك السياسات تلقائياً</p>
          </div>
        </div>

        {/* Success */}
        {successMsg && (
          <div className="mb-5 flex items-center gap-3 rounded-xl border border-green-200 bg-green-50 p-4 animate-fade-in">
            <CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" />
            <p className="text-sm font-medium text-green-800">{successMsg}</p>
          </div>
        )}

        {/* Policy violations (422) */}
        {violations.length > 0 && (
          <div className="mb-5 rounded-xl border border-amber-300 bg-amber-50 p-4 animate-fade-in">
            <div className="flex items-center gap-2 mb-2">
              <ShieldAlert className="h-5 w-5 text-amber-600 shrink-0" />
              <p className="text-sm font-bold text-amber-800">انتهاك سياسة الإجازات (422)</p>
            </div>
            <ul className="space-y-1.5">
              {violations.map((v, i) => (
                <li key={i} className="flex items-start gap-1.5 text-xs text-amber-700">
                  <span className="mt-0.5 shrink-0">•</span>
                  {v}
                </li>
              ))}
            </ul>
          </div>
        )}

        <form onSubmit={handleSubmit((d) => mutation.mutate(d))} noValidate>
          <div className="card-sovereign space-y-5">

            <Select
              id="leaveType"
              label="نوع الإجازة"
              required
              options={LEAVE_TYPE_OPTIONS}
              error={errors.leaveType?.message}
              {...register('leaveType')}
            />

            {/* Type info badge */}
            {selectedTypeInfo && (
              <div className={cn(
                'flex items-start gap-2 rounded-lg border px-4 py-3 text-xs',
                selectedTypeInfo.color,
                leaveType === 'unpaid' ? 'border-red-200' : 'border-current/20',
              )}>
                <Info className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                <div>
                  <span className="font-semibold">{selectedTypeInfo.label}: </span>
                  {selectedTypeInfo.description}
                  {leaveType === 'unpaid' && (
                    <p className="mt-1 font-semibold text-red-700">
                      سيُخصم {daysPreview} يوم من راتبك الشهري
                    </p>
                  )}
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <Input
                id="startDate"
                label="تاريخ البداية"
                type="date"
                min={today}
                required
                error={errors.startDate?.message}
                {...register('startDate')}
              />
              <Input
                id="endDate"
                label="تاريخ النهاية"
                type="date"
                min={startDate || today}
                required
                error={errors.endDate?.message}
                {...register('endDate')}
              />
            </div>

            {/* Days preview */}
            {daysPreview > 0 && (
              <div className="flex items-center justify-between rounded-lg bg-primary/5 border border-primary/20 px-4 py-2.5">
                <span className="text-sm text-primary-dark">مدة الإجازة</span>
                <span className="text-lg font-bold text-primary">{daysPreview} يوم</span>
              </div>
            )}

            <Input
              id="reason"
              label="سبب الإجازة"
              placeholder="وصف مختصر لسبب الإجازة..."
              required
              error={errors.reason?.message}
              {...register('reason')}
            />

            <Button
              type="submit"
              loading={mutation.isPending}
              className="w-full"
            >
              <CalendarDays className="h-4 w-4" />
              تقديم الطلب
            </Button>
          </div>
        </form>
      </div>

      {/* ── Right: My Leave History ── */}
      <div className="lg:col-span-3">
        <h2 className="text-xl font-bold text-neutral-900 mb-6">سجل إجازاتي</h2>

        {leavesLoading ? (
          <div className="flex items-center justify-center py-16">
            <div className="h-7 w-7 animate-spin rounded-full border-4 border-primary border-t-transparent" />
          </div>
        ) : myLeaves.length === 0 ? (
          <div className="card-sovereign flex flex-col items-center justify-center py-14 text-center">
            <CalendarDays className="h-12 w-12 text-neutral-300 mb-3" />
            <p className="text-neutral-500">لا توجد طلبات إجازة مسبقة</p>
          </div>
        ) : (
          <div className="space-y-3">
            {myLeaves.map((leave) => (
              <div key={leave.leaveId}
                className="card-sovereign flex items-start justify-between gap-4 py-4">
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span className={cn(
                      'inline-flex items-center rounded-full border px-3 py-0.5 text-xs font-semibold',
                      STATUS_STYLES[leave.status] ?? 'bg-neutral-100',
                    )}>
                      {STATUS_LABELS[leave.status] ?? leave.status}
                    </span>
                    <span className="text-xs font-medium text-neutral-500">
                      {LEAVE_TYPE_LABELS[leave.leaveType]?.label ?? leave.leaveType}
                    </span>
                    <span className="text-xs text-neutral-400 font-mono">
                      {leave.daysRequested} يوم
                    </span>
                  </div>
                  <p className="text-sm font-medium text-neutral-700">
                    {leave.startDate} ← {leave.endDate}
                  </p>
                  <p className="text-xs text-neutral-400 mt-0.5 truncate">{leave.reason}</p>
                </div>

                {leave.status === 'requested' && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-red-500 hover:bg-red-50 hover:text-red-600 shrink-0"
                    loading={cancelMutation.isPending}
                    onClick={() => cancelMutation.mutate(leave.leaveId)}
                  >
                    <XCircle className="h-3.5 w-3.5" />
                    إلغاء
                  </Button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
