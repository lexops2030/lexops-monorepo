/**
 * LexOps — Objections Service  (Sprint 7 — Legal Engine)
 *
 * Orchestrates the full objection lifecycle:
 *
 *   createDraft()      → POST /violations/:violationId/objections
 *   submitObjection()  → PATCH /objections/:id/submit
 *                          ↳ calls ViolationsRepository.markContested() on the linked violation
 *   addDocument()      → POST /objections/:id/documents
 *   reviewObjection()  → PATCH /objections/:id/review (entity_admin)
 *
 * All mutations are sealed in C9 Ledger:
 *   OBJECTION_CREATED, OBJECTION_SUBMITTED, OBJECTION_DOCUMENT_ADDED,
 *   OBJECTION_ACCEPTED, OBJECTION_REJECTED
 */

import {
  Injectable, Logger,
  NotFoundException, ForbiddenException,
} from '@nestjs/common';
import { getFirestore } from 'firebase-admin/firestore';
import {
  ObjectionsRepository,
  ObjectionRecord,
  ObjectionDocument,
  ObjectionStatus,
} from './objections.repository';
import { ViolationsRepository } from '../compliance/violations.repository';
import { C9LedgerRepository } from '../../database/c9-ledger.repository';

// ── Input shapes ──────────────────────────────────────────────────────────────

export interface CreateObjectionInput {
  violationId: string;
  employeeId:  string;
  branchId?:   string;
  content:     string;
  createdBy:   string;
}

export interface AddDocumentInput {
  label:      string;
  fileUrl:    string;
  uploadedBy: string;
}

export interface ReviewObjectionInput {
  decision:   'accepted' | 'rejected';
  reviewedBy: string;
  reviewNote: string;
}

// ── Service ───────────────────────────────────────────────────────────────────

@Injectable()
export class ObjectionsService {
  private readonly logger = new Logger(ObjectionsService.name);

  constructor(
    private readonly objectionsRepo: ObjectionsRepository,
    private readonly violationsRepo: ViolationsRepository,
    private readonly c9:             C9LedgerRepository,
  ) {}

  // ══════════════════════════════════════════════════════════════════════════════
  // CREATE DRAFT
  // ══════════════════════════════════════════════════════════════════════════════

  async createDraft(
    tenantId: string,
    input:    CreateObjectionInput,
  ): Promise<ObjectionRecord> {
    // Verify the violation exists and belongs to this tenant
    const violation = await this.violationsRepo.findById(tenantId, input.violationId);
    if (!violation) {
      throw new NotFoundException(
        `المخالفة '${input.violationId}' غير موجودة في المنشأة '${tenantId}'.`,
      );
    }

    // Guard: employee can only object to their own violations
    if (
      input.createdBy !== input.employeeId &&
      violation.employeeId !== input.employeeId
    ) {
      throw new ForbiddenException(
        'لا يمكنك الاعتراض على مخالفة لا تخصك.',
      );
    }

    const objection = await this.objectionsRepo.create(tenantId, {
      violationId: input.violationId,
      employeeId:  input.employeeId,
      branchId:    input.branchId,
      content:     input.content,
      status:      'draft',
      createdBy:   input.createdBy,
    });

    // C9 Seal: OBJECTION_CREATED
    await this.c9.append({
      tenantId,
      eventType:   'OBJECTION_CREATED',
      actorUid:    input.createdBy,
      actorRole:   'employee',
      subjectUid:  objection.objectionId,
      subjectType: 'objection',
      payload: {
        objectionId: objection.objectionId,
        violationId: input.violationId,
        employeeId:  input.employeeId,
        status:      'draft',
      },
    });

    this.logger.log(
      `[Objections] Draft created: ${objection.objectionId} ` +
      `violation=${input.violationId} employee=${input.employeeId}`,
    );

    return objection;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // SUBMIT OBJECTION
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * Submit a draft objection.
   * Side-effect: transitions the linked violation to 'contested' status,
   * signalling to ComplianceService that the violation is under dispute.
   */
  async submitObjection(
    tenantId:    string,
    objectionId: string,
    actorUid:    string,
  ): Promise<{ message: string; objection: ObjectionRecord | null }> {
    const objection = await this.objectionsRepo.assertExists(tenantId, objectionId);

    // Only the employee who created it (or entity_admin) may submit
    if (objection.createdBy !== actorUid && objection.employeeId !== actorUid) {
      // Allow entity_admin to submit on behalf — guard is enforced in controller via RBAC
    }

    // Submit the objection
    await this.objectionsRepo.submit(tenantId, objectionId);

    // Update violation status to 'contested' (under dispute)
    await this.violationsRepo.markContested(tenantId, objection.violationId);

    // C9 Seal: OBJECTION_SUBMITTED
    await this.c9.append({
      tenantId,
      eventType:   'OBJECTION_SUBMITTED',
      actorUid,
      actorRole:   'employee',
      subjectUid:  objectionId,
      subjectType: 'objection',
      payload: {
        objectionId,
        violationId:   objection.violationId,
        employeeId:    objection.employeeId,
        violationNote: 'violation status → contested',
      },
    });

    this.logger.log(
      `[Objections] Submitted: ${objectionId} — violation ${objection.violationId} → contested`,
    );

    const updated = await this.objectionsRepo.findById(tenantId, objectionId);
    return {
      message: `تم تقديم الاعتراض '${objectionId}' وتحويل المخالفة '${objection.violationId}' ` +
               `إلى وضع (قيد الاعتراض). تم الختم في C9.`,
      objection: updated,
    };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // ADD DOCUMENT
  // ══════════════════════════════════════════════════════════════════════════════

  async addDocument(
    tenantId:    string,
    objectionId: string,
    input:       AddDocumentInput,
  ): Promise<ObjectionDocument> {
    await this.objectionsRepo.assertExists(tenantId, objectionId);

    const doc = await this.objectionsRepo.addDocument(tenantId, objectionId, {
      label:      input.label,
      fileUrl:    input.fileUrl,
      uploadedBy: input.uploadedBy,
    });

    // C9 Seal: OBJECTION_DOCUMENT_ADDED
    await this.c9.append({
      tenantId,
      eventType:   'OBJECTION_DOCUMENT_ADDED',
      actorUid:    input.uploadedBy,
      actorRole:   'employee',
      subjectUid:  objectionId,
      subjectType: 'objection',
      payload: {
        objectionId,
        docId:   doc.docId,
        label:   input.label,
        fileUrl: input.fileUrl,
      },
    });

    return doc;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // REVIEW — entity_admin only
  // ══════════════════════════════════════════════════════════════════════════════

  async reviewObjection(
    tenantId:    string,
    objectionId: string,
    input:       ReviewObjectionInput,
  ): Promise<{ message: string }> {
    const objection = await this.objectionsRepo.assertExists(tenantId, objectionId);

    await this.objectionsRepo.review(
      tenantId, objectionId,
      input.decision, input.reviewedBy, input.reviewNote,
    );

    // If accepted: resolve the linked violation
    if (input.decision === 'accepted') {
      await this.violationsRepo.resolve(
        tenantId,
        objection.violationId,
        input.reviewedBy,
        `قُبل الاعتراض '${objectionId}' — ${input.reviewNote}`,
      );
    }

    // C9 Seal: OBJECTION_ACCEPTED / OBJECTION_REJECTED
    await this.c9.append({
      tenantId,
      eventType:   input.decision === 'accepted' ? 'OBJECTION_ACCEPTED' : 'OBJECTION_REJECTED',
      actorUid:    input.reviewedBy,
      actorRole:   'entity_admin',
      subjectUid:  objectionId,
      subjectType: 'objection',
      payload: {
        objectionId,
        violationId: objection.violationId,
        employeeId:  objection.employeeId,
        decision:    input.decision,
        reviewNote:  input.reviewNote,
        violationResolved: input.decision === 'accepted',
      },
    });

    const verb = input.decision === 'accepted' ? 'قُبل' : 'رُفض';
    return {
      message: `${verb} الاعتراض '${objectionId}' وتم ختمه في C9.` +
        (input.decision === 'accepted'
          ? ` تم إغلاق المخالفة '${objection.violationId}' تلقائياً.`
          : ''),
    };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // QUERIES
  // ══════════════════════════════════════════════════════════════════════════════

  findById(tenantId: string, objectionId: string) {
    return this.objectionsRepo.findById(tenantId, objectionId);
  }

  findByViolation(tenantId: string, violationId: string) {
    return this.objectionsRepo.findByViolation(tenantId, violationId);
  }

  findMyObjections(tenantId: string, employeeId: string) {
    return this.objectionsRepo.findByEmployee(tenantId, employeeId);
  }

  findAll(tenantId: string, status?: ObjectionStatus) {
    return this.objectionsRepo.findAllByTenant(tenantId, status);
  }

  listDocuments(tenantId: string, objectionId: string) {
    return this.objectionsRepo.listDocuments(tenantId, objectionId);
  }

  updateContent(tenantId: string, objectionId: string, content: string, editorUid: string) {
    return this.objectionsRepo.updateContent(tenantId, objectionId, content, editorUid);
  }
}
