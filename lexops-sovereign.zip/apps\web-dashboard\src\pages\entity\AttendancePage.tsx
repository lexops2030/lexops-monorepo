import { useState } from 'react';
import { ShieldAlert, Navigation, ChevronLeft } from 'lucide-react';
import AttendanceReviewPage from './attendance/AttendanceReviewPage';
import CheckInForm from './attendance/CheckInForm';
import { cn } from '../../lib/utils';

type Tab = 'review' | 'checkin';

export default function AttendancePage() {
  const [tab, setTab] = useState<Tab>('review');

  const tabs: { key: Tab; label: string; icon: typeof ShieldAlert }[] = [
    { key: 'review',  label: 'مراجعة الحضور الميداني', icon: ShieldAlert },
    { key: 'checkin', label: 'محاكاة تسجيل الحضور',    icon: Navigation },
  ];

  return (
    <div>
      {/* ── Tabs ── */}
      <div className="mb-8 flex gap-1 rounded-xl bg-neutral-100 p-1 max-w-md">
        {tabs.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={cn(
              'flex flex-1 items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-semibold transition-all duration-200',
              tab === key
                ? 'bg-white text-primary shadow-card'
                : 'text-neutral-500 hover:text-neutral-700',
            )}
          >
            <Icon className="h-4 w-4" />
            {label}
          </button>
        ))}
      </div>

      {tab === 'review'  && <AttendanceReviewPage />}
      {tab === 'checkin' && <CheckInForm />}
    </div>
  );
}
