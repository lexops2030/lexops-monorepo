import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { UserPlus, CheckCircle2, AlertCircle, ShieldAlert } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Select } from '../../components/ui/Select';
import api from '../../lib/api';
import type { BranchDocument } from '../../../../api-service/src/modules/branches/branches.repository';

// ── Validation Schema ─────────────────────────────────────────────────────────

const employeeSchema = z.object({
  branchId:       z.string().min(1, 'يجب اختيار الفرع'),
  nationalId:     z.string().min(10, 'رقم الهوية / الإقامة يجب أن يكون 10 أرقام على الأقل'),
  name:           z.string().min(2, 'الاسم مطلوب'),
  nameEn:         z.string().optional(),
  position:       z.string().min(2, 'المسمى الوظيفي مطلوب'),
  department:     z.string().optional(),
  employmentType: z.enum(['full_time', 'part_time', 'contract', 'seasonal']),
  joinedAt:       z.string().min(1, 'تاريخ الالتحاق مطلوب'),
  phone:          z.string().optional(),
  email:          z.string().email('بريد إلكتروني غير صالح').optional().or(z.literal('')),
  iqamaExpiry:    z.string().optional(),
  baseSalary:     z.number({ invalid_type_error: 'الراتب يجب أن يكون رقماً' })
                    .positive('يجب أن يكون الراتب قيمة موجبة')
                    .optional(),
});

type EmployeeFormValues = z.infer<typeof employeeSchema>;

// ── Component ─────────────────────────────────────────────────────────────────

interface EmployeeFormPageProps {
  tenantId: string;
  onSuccess?: () => void;
}

export default function EmployeeFormPage({ tenantId, onSuccess }: EmployeeFormPageProps) {
  const queryClient = useQueryClient();
  const [success, setSuccess] = useState(false);

  // Fetch branches for this tenant to populate the selector
  const { data: branches = [], isLoading: branchesLoading } = useQuery<BranchDocument[]>({
    queryKey: ['branches', tenantId],
    queryFn: () => api.get(`/entities/${tenantId}/branches`).then((r) => r.data),
  });

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<EmployeeFormValues>({
    resolver: zodResolver(employeeSchema),
    defaultValues: { employmentType: 'full_time' },
  });

  const mutation = useMutation({
    mutationFn: (data: EmployeeFormValues) =>
      api.post(`/entities/${tenantId}/employees`, data).then((r) => r.data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employees', tenantId] });
      setSuccess(true);
      reset();
      setTimeout(() => { setSuccess(false); onSuccess?.(); }, 2500);
    },
  });

  // Detect HTTP 422 (cross-branch violation)
  const is422 = (mutation.error as { response?: { status?: number } })?.response?.status === 422;

  const employmentTypeOptions = [
    { value: 'full_time',  label: 'دوام كامل' },
    { value: 'part_time',  label: 'دوام جزئي' },
    { value: 'contract',   label: 'عقد محدد المدة' },
    { value: 'seasonal',   label: 'موسمي' },
  ];

  const branchOptions = branchesLoading
    ? [{ value: '', label: 'جارٍ التحميل...' }]
    : [
        { value: '', label: '-- اختر الفرع --' },
        ...branches.map((b) => ({ value: b.branchId, label: b.name })),
      ];

  return (
    <div className="mx-auto max-w-2xl">
      {/* ── Header ── */}
      <div className="mb-8 flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-secondary/20">
          <UserPlus className="h-6 w-6 text-secondary-dark" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">تسجيل موظف جديد</h1>
          <p className="text-sm text-neutral-500">
            سيُختم تسجيل الموظف في سجل C9 فور الحفظ
          </p>
        </div>
      </div>

      {/* ── Success Banner ── */}
      {success && (
        <div className="mb-6 flex items-center gap-3 rounded-xl border border-green-200 bg-green-50 px-5 py-4 animate-fade-in">
          <CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" />
          <p className="text-sm font-medium text-green-800">تم تسجيل الموظف وختم الحدث في سجل C9</p>
        </div>
      )}

      {/* ── Error Banner (generic or 422 Fortress violation) ── */}
      {mutation.isError && (
        <div className={`mb-6 flex items-start gap-3 rounded-xl border px-5 py-4 animate-fade-in ${
          is422 ? 'border-amber-300 bg-amber-50' : 'border-red-200 bg-red-50'
        }`}>
          {is422
            ? <ShieldAlert className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
            : <AlertCircle className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
          }
          <div>
            {is422 && (
              <p className="text-xs font-bold text-amber-800 mb-1">
                انتهاك بروتوكول Fortress 700
              </p>
            )}
            <p className={`text-sm ${is422 ? 'text-amber-700' : 'text-red-700'}`}>
              {(mutation.error as { response?: { data?: { message?: string } } })
                ?.response?.data?.message ??
                (is422
                  ? 'الفرع المختار لا ينتمي إلى هذه المنشأة. لا يُسمح بالربط العابر للحدود.'
                  : 'حدث خطأ أثناء تسجيل الموظف')}
            </p>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit((d) => mutation.mutate(d))} noValidate>
        <div className="card-sovereign space-y-6">

          {/* ── Section: Branch Assignment ── */}
          <div>
            <h2 className="mb-4 text-sm font-semibold uppercase tracking-wider text-neutral-400">
              ربط الموظف بالفرع
            </h2>
            <Select
              id="branchId"
              label="الفرع"
              required
              options={branchOptions}
              error={errors.branchId?.message}
              {...register('branchId')}
            />
            <p className="mt-2 text-xs text-neutral-400">
              يُمنع ربط موظف بفرع خارج حدود منشأتك (خطأ 422)
            </p>
          </div>

          <hr className="border-neutral-100" />

          {/* ── Section: Identity ── */}
          <div>
            <h2 className="mb-4 text-sm font-semibold uppercase tracking-wider text-neutral-400">
              البيانات الشخصية
            </h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Input
                id="nationalId"
                label="رقم الهوية / الإقامة"
                placeholder="1XXXXXXXXX"
                required
                error={errors.nationalId?.message}
                {...register('nationalId')}
              />
              <Input
                id="iqamaExpiry"
                label="تاريخ انتهاء الإقامة"
                type="date"
                error={errors.iqamaExpiry?.message}
                {...register('iqamaExpiry')}
              />
              <Input
                id="name"
                label="الاسم الكامل (عربي)"
                placeholder="محمد بن عبدالله"
                required
                error={errors.name?.message}
                {...register('name')}
              />
              <Input
                id="nameEn"
                label="الاسم الكامل (إنجليزي)"
                placeholder="Mohammed Abdullah"
                error={errors.nameEn?.message}
                {...register('nameEn')}
              />
              <Input
                id="phone"
                label="رقم الجوال"
                type="tel"
                placeholder="05XXXXXXXX"
                dir="ltr"
                error={errors.phone?.message}
                {...register('phone')}
              />
              <Input
                id="email"
                label="البريد الإلكتروني"
                type="email"
                placeholder="employee@company.sa"
                dir="ltr"
                error={errors.email?.message}
                {...register('email')}
              />
            </div>
          </div>

          <hr className="border-neutral-100" />

          {/* ── Section: Job Info ── */}
          <div>
            <h2 className="mb-4 text-sm font-semibold uppercase tracking-wider text-neutral-400">
              بيانات الوظيفة
            </h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Input
                id="position"
                label="المسمى الوظيفي"
                placeholder="مدير مبيعات"
                required
                error={errors.position?.message}
                {...register('position')}
              />
              <Input
                id="department"
                label="القسم / الإدارة"
                placeholder="المبيعات"
                error={errors.department?.message}
                {...register('department')}
              />
              <Select
                id="employmentType"
                label="نوع التوظيف"
                required
                options={employmentTypeOptions}
                error={errors.employmentType?.message}
                {...register('employmentType')}
              />
              <Input
                id="joinedAt"
                label="تاريخ الالتحاق"
                type="date"
                required
                error={errors.joinedAt?.message}
                {...register('joinedAt')}
              />
              <Input
                id="baseSalary"
                label="الراتب الأساسي (ريال)"
                type="number"
                placeholder="5000"
                hint="يُستخدم في محرك الرواتب"
                error={errors.baseSalary?.message}
                {...register('baseSalary', { valueAsNumber: true })}
              />
            </div>
          </div>

          {/* ── Actions ── */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <Button type="button" variant="ghost" onClick={() => reset()}>
              مسح البيانات
            </Button>
            <Button
              type="submit"
              loading={mutation.isPending}
              className="bg-secondary-dark hover:bg-secondary text-white"
            >
              تسجيل الموظف وختم C9
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
