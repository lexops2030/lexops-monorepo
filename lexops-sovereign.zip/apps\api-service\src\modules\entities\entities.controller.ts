import { Controller, Get, Post, Body, Param, Request, Version } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { IsNotEmpty, IsString, IsEnum, IsDateString } from 'class-validator';
import { EntitiesService } from './entities.service';
import { Roles } from '../auth/firebase.guard';
import { Request as ExpressRequest } from 'express';
import type { LexOpsClaims } from '../auth/firebase.guard';

class CreateEntityDto {
  @IsString() @IsNotEmpty() tenantId: string;
  @IsString() @IsNotEmpty() nameAr: string;
  @IsString() @IsNotEmpty() nameEn: string;
  @IsString() @IsNotEmpty() commercialRegNumber: string;
  @IsDateString() licenseExpiry: string;
  @IsEnum(['starter', 'growth', 'enterprise']) subscriptionTier: 'starter' | 'growth' | 'enterprise';
}

@ApiTags('Entities — Fortress 700')
@ApiBearerAuth('Firebase-JWT')
@Controller('entities')
export class EntitiesController {
  constructor(private readonly entitiesService: EntitiesService) {}

  @Get()
  @Version('1')
  @Roles('sovereign')
  @ApiOperation({ summary: 'List all active entities (Sovereign only)' })
  findAll() {
    return this.entitiesService.findAll();
  }

  @Get(':tenantId')
  @Version('1')
  @Roles('sovereign', 'entity_admin')
  @ApiOperation({ summary: 'Get entity by tenant ID' })
  findOne(@Param('tenantId') tenantId: string) {
    return this.entitiesService.findById(tenantId);
  }

  @Post()
  @Version('1')
  @Roles('sovereign')
  @ApiOperation({ summary: 'Register new entity (Sovereign only)' })
  create(
    @Body() dto: CreateEntityDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.entitiesService.create(
      dto.tenantId,
      { ...dto, activeBranchCount: 0, isActive: true },
      req.user.uid,
    );
  }
}
