export default function SovereignPage() {
  return <div className="card-sovereign"><p className="text-neutral-500">لوحة السيادة — Sprint 4</p></div>;
}
