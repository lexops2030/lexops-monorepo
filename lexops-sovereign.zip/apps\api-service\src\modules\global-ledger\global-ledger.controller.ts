/**
 * LexOps — Global Ledger Controller  (Sprint 8)
 *
 * Routes (sovereign-only — cross-entity):
 *   GET   /v1/global/genesis              → get the Genesis Block
 *   POST  /v1/global/genesis/verify       → verify platform integrity
 *   GET   /v1/global/genesis/manifest     → list all registered sprint modules
 */

import {
  Controller, Get, Post, Version, UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { GlobalLedgerService } from './global-ledger.service';
import { FirebaseAuthGuard, Roles } from '../auth/firebase.guard';

@ApiTags('Global Truth Ledger — الختم السيادي العالمي')
@ApiBearerAuth('Firebase-JWT')
@Controller('global')
@UseGuards(FirebaseAuthGuard)
export class GlobalLedgerController {
  constructor(private readonly globalLedger: GlobalLedgerService) {}

  @Get('genesis')
  @Version('1')
  @Roles('sovereign')
  @ApiOperation({ summary: 'الكتلة الجينية — سجل التأسيس السيادي للمنصة' })
  getGenesis() {
    return this.globalLedger.getGenesis();
  }

  @Post('genesis/verify')
  @Version('1')
  @Roles('sovereign')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'التحقق من سلامة المنصة — إعادة حساب SHA-512 ومقارنته بالختم المخزن',
    description:
      'يُعيد حساب التوقيع الرقمي للمنصة ويقارنه بالختم المحفوظ. ' +
      'أي اختلاف يعني تلاعباً في كود المنصة ويُطلق تنبيهاً سيادياً فورياً.',
  })
  verifyIntegrity() {
    return this.globalLedger.verifyGenesisIntegrity();
  }

  @Get('genesis/manifest')
  @Version('1')
  @Roles('sovereign')
  @ApiOperation({ summary: 'قائمة الوحدات المسجّلة في الكتلة الجينية (20 Sprint Module)' })
  getManifest() {
    return { modules: this.globalLedger.getModuleManifest() };
  }
}
