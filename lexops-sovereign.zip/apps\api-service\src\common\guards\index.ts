export { TenantScopeGuard, TenantParam, TENANT_PARAM_KEY } from './tenant-scope.guard';
