/**
 * LexOps — Lifecycle Repository
 *
 * Manages three Firestore collections:
 *   - establishment_lifecycle : tracks the legal lifecycle phases of an entity
 *   - employee_lifecycle      : tracks per-employee contract / probation / termination phases
 *   - compliance_kpis         : append-only snapshots of entity KPI metrics
 */

import { Injectable, Inject } from '@nestjs/common';
import { Firestore, FieldValue } from '@google-cloud/firestore';

// ── Types ─────────────────────────────────────────────────────────────────────

export type EstablishmentPhase =
  | 'setup'
  | 'contract'
  | 'operational'
  | 'under_review'
  | 'suspended'
  | 'dissolved';

export type EmployeePhase =
  | 'contract'
  | 'probation'
  | 'active'
  | 'on_leave'
  | 'suspended'
  | 'terminated';

export interface LifecycleAlert {
  alertType:   string;
  message:     string;
  triggeredAt: FirebaseFirestore.Timestamp;
  isRead:      boolean;
  targetDate?: string;   // ISO 8601
  daysRemaining?: number;
}

export interface EstablishmentLifecycle {
  tenantId:             string;
  phase:                EstablishmentPhase;
  licenseExpiry:        string;
  commercialRegExpiry?: string;
  vatExpiry?:           string;
  alerts:               LifecycleAlert[];
  lastUpdatedAt:        FirebaseFirestore.Timestamp;
  createdAt:            FirebaseFirestore.Timestamp;
}

export interface EmployeeLifecycle {
  employeeId:         string;
  tenantId:           string;
  phase:              EmployeePhase;
  contractStartDate:  string;
  contractEndDate?:   string;
  probationStartDate?: string;
  probationEndDate?:  string;    // contractStartDate + 90 days
  probationAlertSent: boolean;   // true when day-80 alert fired
  alerts:             LifecycleAlert[];
  lastUpdatedAt:      FirebaseFirestore.Timestamp;
  createdAt:          FirebaseFirestore.Timestamp;
}

export interface ComplianceKpiSnapshot {
  snapshotId:           string;
  tenantId:             string;
  snapshotDate:         string;   // ISO 8601 date
  attendanceRate:       number;   // 0–100 %
  leaveComplianceRate:  number;   // 0–100 %
  violationCount:       number;
  pendingReviewCount:   number;
  payrollClosedOnTime:  boolean;
  overallScore:         number;   // 0–100 composite
  createdAt:            FirebaseFirestore.Timestamp;
}

// ── Repository ────────────────────────────────────────────────────────────────

@Injectable()
export class LifecycleRepository {
  constructor(@Inject('FIRESTORE') private readonly db: Firestore) {}

  // ── Establishment Lifecycle ──────────────────────────────────────────────────

  private estLifecycleRef(tenantId: string) {
    return this.db.collection('establishment_lifecycle').doc(tenantId);
  }

  async getEstablishment(tenantId: string): Promise<EstablishmentLifecycle | null> {
    const snap = await this.estLifecycleRef(tenantId).get();
    return snap.exists ? (snap.data() as EstablishmentLifecycle) : null;
  }

  async upsertEstablishment(
    tenantId: string,
    data: Partial<Omit<EstablishmentLifecycle, 'tenantId' | 'createdAt'>>,
  ): Promise<void> {
    const ref  = this.estLifecycleRef(tenantId);
    const snap = await ref.get();

    if (snap.exists) {
      await ref.update({ ...data, lastUpdatedAt: FieldValue.serverTimestamp() });
    } else {
      await ref.set({
        tenantId,
        phase:          'setup',
        alerts:         [],
        ...data,
        lastUpdatedAt:  FieldValue.serverTimestamp(),
        createdAt:      FieldValue.serverTimestamp(),
      });
    }
  }

  async pushEstablishmentAlert(tenantId: string, alert: LifecycleAlert): Promise<void> {
    await this.estLifecycleRef(tenantId).update({
      alerts:       FieldValue.arrayUnion(alert),
      lastUpdatedAt: FieldValue.serverTimestamp(),
    });
  }

  // ── Employee Lifecycle ──────────────────────────────────────────────────────

  private empLifecycleRef(tenantId: string, employeeId: string) {
    return this.db.collection('employee_lifecycle').doc(`${tenantId}_${employeeId}`);
  }

  async getEmployee(tenantId: string, employeeId: string): Promise<EmployeeLifecycle | null> {
    const snap = await this.empLifecycleRef(tenantId, employeeId).get();
    return snap.exists ? (snap.data() as EmployeeLifecycle) : null;
  }

  async upsertEmployee(
    tenantId: string,
    employeeId: string,
    data: Partial<Omit<EmployeeLifecycle, 'employeeId' | 'tenantId' | 'createdAt'>>,
  ): Promise<void> {
    const ref  = this.empLifecycleRef(tenantId, employeeId);
    const snap = await ref.get();

    if (snap.exists) {
      await ref.update({ ...data, lastUpdatedAt: FieldValue.serverTimestamp() });
    } else {
      await ref.set({
        employeeId,
        tenantId,
        phase:              'contract',
        probationAlertSent: false,
        alerts:             [],
        ...data,
        lastUpdatedAt:      FieldValue.serverTimestamp(),
        createdAt:          FieldValue.serverTimestamp(),
      });
    }
  }

  async pushEmployeeAlert(
    tenantId: string,
    employeeId: string,
    alert: LifecycleAlert,
  ): Promise<void> {
    await this.empLifecycleRef(tenantId, employeeId).update({
      alerts:       FieldValue.arrayUnion(alert),
      lastUpdatedAt: FieldValue.serverTimestamp(),
    });
  }

  async markProbationAlertSent(tenantId: string, employeeId: string): Promise<void> {
    await this.empLifecycleRef(tenantId, employeeId).update({
      probationAlertSent: true,
      lastUpdatedAt:      FieldValue.serverTimestamp(),
    });
  }

  /** Query all employees whose probation ends within [start, end] */
  async findEmployeesWithProbationEndingBetween(
    startDate: string,
    endDate: string,
  ): Promise<EmployeeLifecycle[]> {
    const snap = await this.db
      .collection('employee_lifecycle')
      .where('phase', '==', 'probation')
      .where('probationAlertSent', '==', false)
      .where('probationEndDate', '>=', startDate)
      .where('probationEndDate', '<=', endDate)
      .get();
    return snap.docs.map((d) => d.data() as EmployeeLifecycle);
  }

  // ── Compliance KPIs (append-only) ─────────────────────────────────────────

  private kpiCol() {
    return this.db.collection('compliance_kpis');
  }

  async appendKpiSnapshot(snapshot: Omit<ComplianceKpiSnapshot, 'createdAt'>): Promise<void> {
    await this.kpiCol().doc(snapshot.snapshotId).set({
      ...snapshot,
      createdAt: FieldValue.serverTimestamp(),
    });
  }

  async getKpiHistory(tenantId: string, limit = 12): Promise<ComplianceKpiSnapshot[]> {
    const snap = await this.kpiCol()
      .where('tenantId', '==', tenantId)
      .orderBy('snapshotDate', 'desc')
      .limit(limit)
      .get();
    return snap.docs.map((d) => d.data() as ComplianceKpiSnapshot);
  }
}
