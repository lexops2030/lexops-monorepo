/**
 * SovereignDocumentRenderer — المُصيِّر السيادي الموحَّد
 *
 * مكوّن شامل وقابل للإعادة الاستخدام يعمل في وضعين:
 *   1. عرض الشاشة (Web/App UI) — تصميم سيادي بالثيم الكحلي/الذهبي
 *   2. طباعة PDF (A4) — ديباجة رسمية + ختوم + توقيع رقمي C9
 *
 * يُستخدم كـ Wrapper لأي تقرير في المنصة:
 *   مسير رواتب / تقرير امتثال / مذكرة اعتراض / تحليل LEXI / فاتورة ضريبية
 *
 * المنطق السيادي لمعرّف الهوية (Sovereign ID Block):
 *   - Sovereign / entity_admin → Entity SEI + Admin SEI
 *   - employee              → Entity SEI + Employee SEI
 *   - freelancer (IND_)     → Independent SEI فقط (عزل كامل)
 */

import React, { useRef, useCallback } from 'react';
import { useReactToPrint } from 'react-to-print';
import { Scale, Printer, ShieldCheck, CheckCircle2, Hash } from 'lucide-react';
import { cn } from '../../lib/utils';

// ── Types ─────────────────────────────────────────────────────────────────────

export type DocumentRole = 'sovereign' | 'entity_admin' | 'employee' | 'freelancer';

export interface RequesterInfo {
  uid:         string;
  displayName: string;
  role:        DocumentRole;
  tenantId:    string | null;       // null for sovereign cross-entity context
  entityName?: string;
  entitySei?:  string;              // Entity Sovereign ID (700-series)
  employeeSei?: string;             // Employee's own Sovereign ID
}

export interface C9SealInfo {
  eventId:    string;
  hmacHash:   string;               // HMAC-SHA256 signature from C9 Ledger
  eventType:  string;
  sealedAt:   string;               // ISO timestamp
}

export interface SovereignDocumentRendererProps {
  /** Document type displayed in the sovereign header */
  documentTitle: string;
  /** Optional subtitle (e.g., "شهر: 2026-03", "الفرع: الرياض") */
  documentSubtitle?: string;
  /** Who is requesting / viewing this document */
  requester: RequesterInfo;
  /** C9 immutable ledger seal — mandatory for all documents */
  c9Seal: C9SealInfo;
  /** Body content — any report, table, chart injected by the caller module */
  children: React.ReactNode;
  /** Whether to show the entity seal in the footer (false for freelancers) */
  showEntitySeal?: boolean;
  /** Extra class names for the outer wrapper */
  className?: string;
  /** Callback fired after print dialog closes */
  onAfterPrint?: () => void;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function formatDate(iso: string): string {
  return new Intl.DateTimeFormat('ar-SA', {
    year: 'numeric', month: 'long', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
    calendar: 'gregory',
  }).format(new Date(iso));
}

function truncateHash(hash: string, len = 32): string {
  return hash.length > len ? `${hash.slice(0, len)}…` : hash;
}

const ROLE_LABELS: Record<DocumentRole, string> = {
  sovereign:    'المدير السيادي',
  entity_admin: 'مدير المنشأة',
  employee:     'موظف',
  freelancer:   'عامل مستقل',
};

// ── Sub-components ────────────────────────────────────────────────────────────

/** Sovereign header — الديباجة الرسمية */
function SovereignHeader({
  documentTitle,
  documentSubtitle,
  requester,
  issuedAt,
}: {
  documentTitle:    string;
  documentSubtitle?: string;
  requester:        RequesterInfo;
  issuedAt:         string;
}) {
  return (
    <header className="flex flex-col items-center gap-3 pb-6 border-b-2 border-secondary print:pb-4">
      {/* Logo row */}
      <div className="flex items-center gap-3">
        <div className="h-12 w-12 rounded-xl bg-primary flex items-center justify-center shadow-lg print:shadow-none">
          <Scale className="h-7 w-7 text-white" />
        </div>
        <div className="text-right">
          <p className="text-xs font-medium text-neutral-400 tracking-widest uppercase">
            LexOps Sovereign OS
          </p>
          <p className="text-[10px] text-neutral-400">
            نظام التشغيل القانوني السيادي — المملكة العربية السعودية
          </p>
        </div>
      </div>

      {/* Document title */}
      <div className="text-center mt-1">
        <h1 className="text-2xl font-bold text-primary print:text-xl">
          {documentTitle}
        </h1>
        {documentSubtitle && (
          <p className="text-sm text-secondary-dark font-medium mt-0.5">{documentSubtitle}</p>
        )}
      </div>

      {/* Meta row */}
      <div className="flex flex-wrap justify-center gap-x-6 gap-y-1 text-xs text-neutral-500 mt-1">
        <span>
          <span className="font-semibold text-neutral-700">تاريخ الإصدار: </span>
          {formatDate(issuedAt)}
        </span>
        <span>
          <span className="font-semibold text-neutral-700">طالب الوثيقة: </span>
          {requester.displayName}
        </span>
        <span>
          <span className="font-semibold text-neutral-700">الصفة: </span>
          {ROLE_LABELS[requester.role]}
        </span>
      </div>
    </header>
  );
}

/** Sovereign ID Block — المنطق السيادي للأرقام (RBAC-driven) */
function SovereignIdBlock({ requester }: { requester: RequesterInfo }) {
  const isFreelancer =
    requester.role === 'freelancer' ||
    (requester.tenantId?.startsWith('IND_') ?? false);

  return (
    <section
      className={cn(
        'rounded-xl border p-4 text-sm print:rounded-none print:border-neutral-300',
        isFreelancer
          ? 'border-secondary/40 bg-secondary/5'
          : 'border-primary/20 bg-primary/5',
      )}
    >
      <p className="font-bold text-primary mb-3 text-xs uppercase tracking-wider">
        {isFreelancer ? '⚡ هوية المستقل السيادية' : '🏛 المعرّفات السيادية'}
      </p>

      {isFreelancer ? (
        /* ── Freelancer: Independent SEI only (data isolation) ──────────── */
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-lg bg-secondary/20 flex items-center justify-center">
            <ShieldCheck className="h-5 w-5 text-secondary-dark" />
          </div>
          <div>
            <p className="text-[10px] text-neutral-400 uppercase tracking-wide">
              Independent Sovereign Entity ID
            </p>
            <p className="font-mono font-bold text-primary text-sm">
              {requester.tenantId ?? requester.uid}
            </p>
            <p className="text-[10px] text-neutral-400 mt-0.5">
              بيانات معزولة بالكامل — لا مشاركة مع المنشآت
            </p>
          </div>
        </div>
      ) : (
        /* ── Entity-linked users: Entity SEI + personal SEI ─────────────── */
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {/* Entity SEI */}
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center">
              <ShieldCheck className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-[10px] text-neutral-400 uppercase tracking-wide">
                Entity Sovereign ID (SEI)
              </p>
              <p className="font-mono font-bold text-primary text-sm">
                {requester.entitySei ?? requester.tenantId ?? '—'}
              </p>
              {requester.entityName && (
                <p className="text-[10px] text-neutral-500">{requester.entityName}</p>
              )}
            </div>
          </div>

          {/* Employee / Admin SEI */}
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-secondary/10 flex items-center justify-center">
              <ShieldCheck className="h-5 w-5 text-secondary-dark" />
            </div>
            <div>
              <p className="text-[10px] text-neutral-400 uppercase tracking-wide">
                {requester.role === 'employee' ? 'Employee SEI' : 'Admin SEI'}
              </p>
              <p className="font-mono font-bold text-primary text-sm">
                {requester.employeeSei ?? requester.uid}
              </p>
              <p className="text-[10px] text-neutral-500">{requester.displayName}</p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

/** Document footer — الختوم والتوقيعات */
function SovereignFooter({
  requester,
  c9Seal,
  showEntitySeal,
}: {
  requester:      RequesterInfo;
  c9Seal:         C9SealInfo;
  showEntitySeal: boolean;
}) {
  const isEntityLinked =
    showEntitySeal &&
    requester.role !== 'freelancer' &&
    !requester.tenantId?.startsWith('IND_');

  return (
    <footer className="pt-6 border-t-2 border-secondary space-y-5 print:pt-4">
      {/* ── Seals row ──────────────────────────────────────────────────── */}
      <div className={cn('grid gap-4', isEntityLinked ? 'grid-cols-1 sm:grid-cols-2' : 'grid-cols-1')}>
        {/* Entity seal */}
        {isEntityLinked && (
          <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 flex flex-col items-center gap-2 text-center print:rounded-none">
            <div className="h-12 w-12 rounded-full border-2 border-primary/30 flex items-center justify-center">
              <ShieldCheck className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="font-bold text-primary text-xs uppercase tracking-wider">
                الختم العام للمنشأة
              </p>
              <p className="text-[10px] text-neutral-500 mt-0.5">
                {requester.entityName ?? requester.tenantId}
              </p>
            </div>
            <div className="text-[10px] text-secondary-dark font-mono border border-secondary/30 rounded px-2 py-0.5 bg-white">
              SEI: {requester.entitySei ?? requester.tenantId}
            </div>
          </div>
        )}

        {/* C9 Immutable Seal — mandatory for ALL documents */}
        <div className="rounded-xl border-2 border-secondary bg-gradient-to-br from-primary/5 to-secondary/10 p-4 print:rounded-none">
          <div className="flex items-start gap-3">
            {/* QR placeholder */}
            <div className="shrink-0 h-16 w-16 border-2 border-dashed border-secondary/50 rounded-lg flex flex-col items-center justify-center text-center print:h-14 print:w-14">
              <Hash className="h-4 w-4 text-secondary-dark mb-0.5" />
              <span className="text-[8px] text-neutral-500 leading-tight">QR<br />سجل C9</span>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 mb-1">
                <CheckCircle2 className="h-4 w-4 text-green-600 shrink-0" />
                <p className="font-bold text-primary text-xs uppercase tracking-wide">
                  الختم السيادي — سجل C9 اللامتغير
                </p>
              </div>

              <p className="text-[10px] text-neutral-500 mb-2">
                تم تسجيل هذه الوثيقة وختمها في سجل الحقيقة غير القابل للتعديل.
                أي تغيير في البيانات يُبطل التوقيع الرقمي.
              </p>

              <div className="space-y-1 font-mono text-[10px]">
                <div className="flex gap-1">
                  <span className="text-neutral-400 shrink-0">Event:</span>
                  <span className="text-primary font-semibold truncate">{c9Seal.eventType}</span>
                </div>
                <div className="flex gap-1">
                  <span className="text-neutral-400 shrink-0">ID:</span>
                  <span className="text-neutral-600 truncate">{c9Seal.eventId}</span>
                </div>
                <div className="flex gap-1">
                  <span className="text-neutral-400 shrink-0">Sealed:</span>
                  <span className="text-neutral-600">{formatDate(c9Seal.sealedAt)}</span>
                </div>
                <div className="flex gap-1 items-start">
                  <span className="text-neutral-400 shrink-0">HMAC-SHA256:</span>
                  <span
                    className="text-secondary-dark font-bold break-all leading-tight"
                    title={c9Seal.hmacHash}
                  >
                    {truncateHash(c9Seal.hmacHash)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-secondary/20 text-center">
            <p className="text-[9px] text-neutral-400 leading-relaxed">
              Digital_Signature: HMAC-SHA256 &mdash; Verified by LexOps C9 Ledger &mdash; Tamper-Evident
            </p>
          </div>
        </div>
      </div>

      {/* Platform watermark */}
      <p className="text-center text-[9px] text-neutral-300 print:text-neutral-400">
        LexOps Sovereign Legal OS — نظام العمل القانوني السيادي &mdash; جميع الحقوق محفوظة &copy; {new Date().getFullYear()}
      </p>
    </footer>
  );
}

// ── Print Stylesheet (injected into <head> during print only) ─────────────────

const PRINT_STYLES = `
@media print {
  @page {
    size: A4 portrait;
    margin: 18mm 20mm;
  }
  body {
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }
  .no-print { display: none !important; }
  .sovereign-document {
    box-shadow: none !important;
    border: none !important;
    padding: 0 !important;
  }
}
`;

// ── Main Component ────────────────────────────────────────────────────────────

export function SovereignDocumentRenderer({
  documentTitle,
  documentSubtitle,
  requester,
  c9Seal,
  children,
  showEntitySeal = true,
  className,
  onAfterPrint,
}: SovereignDocumentRendererProps) {
  const printRef = useRef<HTMLDivElement>(null);
  const issuedAt = new Date().toISOString();

  const handlePrint = useReactToPrint({
    contentRef: printRef,
    documentTitle: `LexOps — ${documentTitle}`,
    onAfterPrint,
    pageStyle: PRINT_STYLES,
  });

  return (
    <div className={cn('relative', className)} dir="rtl">
      {/* ── Print trigger (hidden in print) ─────────────────────────────── */}
      <div className="no-print mb-4 flex justify-end">
        <button
          onClick={() => handlePrint()}
          className={cn(
            'inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold',
            'bg-primary text-white hover:bg-primary-light transition-colors shadow-sovereign',
            'focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2',
          )}
        >
          <Printer className="h-4 w-4" />
          طباعة / تصدير PDF
        </button>
      </div>

      {/* ── Printable document container ─────────────────────────────────── */}
      <div
        ref={printRef}
        className={cn(
          'sovereign-document bg-white rounded-2xl shadow-xl border border-neutral-100',
          'p-8 print:p-0 print:shadow-none print:rounded-none print:border-0',
          // Typography: Cairo for formal Arabic legal text
          'font-cairo text-neutral-800',
        )}
      >
        {/* ── Header / الديباجة ────────────────────────────────────────── */}
        <SovereignHeader
          documentTitle={documentTitle}
          documentSubtitle={documentSubtitle}
          requester={requester}
          issuedAt={issuedAt}
        />

        {/* ── Sovereign ID Block ───────────────────────────────────────── */}
        <div className="my-6 print:my-4">
          <SovereignIdBlock requester={requester} />
        </div>

        {/* ── Divider ─────────────────────────────────────────────────── */}
        <div className="flex items-center gap-3 my-5 print:my-3">
          <div className="flex-1 h-px bg-neutral-200" />
          <span className="text-xs text-secondary-dark font-semibold uppercase tracking-widest">
            محتوى الوثيقة
          </span>
          <div className="flex-1 h-px bg-neutral-200" />
        </div>

        {/* ── Document body — injected by caller module ─────────────────── */}
        <main className="min-h-[200px] print:min-h-0">
          {children}
        </main>

        {/* ── Divider ─────────────────────────────────────────────────── */}
        <div className="flex items-center gap-3 mt-8 mb-6 print:mt-5 print:mb-4">
          <div className="flex-1 h-px bg-neutral-200" />
          <span className="text-xs text-secondary-dark font-semibold uppercase tracking-widest">
            الختوم والتوقيعات
          </span>
          <div className="flex-1 h-px bg-neutral-200" />
        </div>

        {/* ── Footer / الختوم ──────────────────────────────────────────── */}
        <SovereignFooter
          requester={requester}
          c9Seal={c9Seal}
          showEntitySeal={showEntitySeal}
        />
      </div>
    </div>
  );
}

export default SovereignDocumentRenderer;
