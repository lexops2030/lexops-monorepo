/**
 * LexOps — Objections Controller  (Sprint 7 — Legal Engine)
 *
 * Routes (all under /v1/entities/:tenantId):
 *
 *   POST   /violations/:violationId/objections     → create draft
 *   GET    /violations/:violationId/objections     → list objections for a violation
 *   GET    /objections                             → all tenant objections (admin board)
 *   GET    /objections/my                          → employee's own objections
 *   GET    /objections/:id                         → get single objection
 *   PATCH  /objections/:id/content                 → update draft content
 *   PATCH  /objections/:id/submit                  → submit objection (draft → submitted)
 *   PATCH  /objections/:id/review                  → admin: accept | reject
 *   POST   /objections/:id/documents               → attach evidence document
 *   GET    /objections/:id/documents               → list attached documents
 */

import {
  Controller, Get, Post, Patch,
  Param, Body, Request, Query, Version, UseGuards,
  HttpCode, HttpStatus,
} from '@nestjs/common';
import {
  ApiTags, ApiBearerAuth, ApiOperation, ApiParam, ApiQuery,
} from '@nestjs/swagger';
import {
  IsString, IsNotEmpty, IsUrl, IsOptional, IsIn,
} from 'class-validator';
import { ObjectionsService } from './objections.service';
import { ObjectionStatus } from './objections.repository';
import {
  FirebaseAuthGuard, TenantScopeGuard, Roles, LexOpsClaims,
} from '../auth/firebase.guard';
import { Request as ExpressRequest } from 'express';

// ── DTOs ─────────────────────────────────────────────────────────────────────

class CreateObjectionDto {
  @IsString() @IsNotEmpty()
  content: string;      // Employee's written objection (Arabic)

  @IsString() @IsOptional()
  branchId?: string;
}

class UpdateContentDto {
  @IsString() @IsNotEmpty()
  content: string;
}

class ReviewObjectionDto {
  @IsIn(['accepted', 'rejected'])
  decision: 'accepted' | 'rejected';

  @IsString() @IsNotEmpty()
  reviewNote: string;
}

class AddDocumentDto {
  @IsString() @IsNotEmpty()
  label: string;      // e.g. 'شهادة طبية', 'عقد عمل'

  @IsString() @IsNotEmpty()
  fileUrl: string;
}

// ── Controller ─────────────────────────────────────────────────────────────────

@ApiTags('Objections — الاعتراضات القانونية')
@ApiBearerAuth('Firebase-JWT')
@Controller('entities/:tenantId')
@UseGuards(FirebaseAuthGuard, TenantScopeGuard)
export class ObjectionsController {
  constructor(private readonly objectionsService: ObjectionsService) {}

  // ── Create draft under a violation ───────────────────────────────────────────

  @Post('violations/:violationId/objections')
  @Version('1')
  @Roles('employee', 'entity_admin', 'sovereign')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'إنشاء مسودة اعتراض على مخالفة + C9 Seal' })
  createDraft(
    @Param('tenantId')    tenantId:    string,
    @Param('violationId') violationId: string,
    @Body() dto: CreateObjectionDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.objectionsService.createDraft(tenantId, {
      violationId,
      employeeId: req.user.uid,
      branchId:   dto.branchId,
      content:    dto.content,
      createdBy:  req.user.uid,
    });
  }

  // ── List objections for a violation ──────────────────────────────────────────

  @Get('violations/:violationId/objections')
  @Version('1')
  @Roles('entity_admin', 'sovereign', 'employee')
  @ApiOperation({ summary: 'قائمة الاعتراضات المرتبطة بمخالفة' })
  findByViolation(
    @Param('tenantId')    tenantId:    string,
    @Param('violationId') violationId: string,
  ) {
    return this.objectionsService.findByViolation(tenantId, violationId);
  }

  // ── Admin board: all objections ───────────────────────────────────────────────

  @Get('objections')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({ summary: 'لوحة الاعتراضات — جميع اعتراضات المنشأة' })
  @ApiQuery({ name: 'status', required: false, description: 'فلتر الحالة' })
  findAll(
    @Param('tenantId') tenantId: string,
    @Query('status') status?: ObjectionStatus,
  ) {
    return this.objectionsService.findAll(tenantId, status);
  }

  // ── Employee: my objections ───────────────────────────────────────────────────

  @Get('objections/my')
  @Version('1')
  @Roles('employee', 'entity_admin', 'sovereign')
  @ApiOperation({ summary: 'اعتراضاتي — سجل اعتراضات الموظف المسجّل' })
  findMine(
    @Param('tenantId') tenantId: string,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.objectionsService.findMyObjections(tenantId, req.user.uid);
  }

  // ── Get single objection ──────────────────────────────────────────────────────

  @Get('objections/:objectionId')
  @Version('1')
  @Roles('employee', 'entity_admin', 'sovereign')
  @ApiOperation({ summary: 'تفاصيل اعتراض' })
  findOne(
    @Param('tenantId')    tenantId:    string,
    @Param('objectionId') objectionId: string,
  ) {
    return this.objectionsService.findById(tenantId, objectionId);
  }

  // ── Update draft content ──────────────────────────────────────────────────────

  @Patch('objections/:objectionId/content')
  @Version('1')
  @Roles('employee', 'entity_admin', 'sovereign')
  @ApiOperation({ summary: 'تحديث نص الاعتراض (في وضع draft فقط)' })
  updateContent(
    @Param('tenantId')    tenantId:    string,
    @Param('objectionId') objectionId: string,
    @Body() dto: UpdateContentDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.objectionsService.updateContent(
      tenantId, objectionId, dto.content, req.user.uid,
    );
  }

  // ── Submit objection ──────────────────────────────────────────────────────────

  @Patch('objections/:objectionId/submit')
  @Version('1')
  @Roles('employee', 'entity_admin', 'sovereign')
  @ApiOperation({
    summary: 'تقديم الاعتراض (draft → submitted) + تحويل المخالفة إلى "قيد الاعتراض" + C9 Seal',
  })
  submitObjection(
    @Param('tenantId')    tenantId:    string,
    @Param('objectionId') objectionId: string,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.objectionsService.submitObjection(tenantId, objectionId, req.user.uid);
  }

  // ── Admin review ──────────────────────────────────────────────────────────────

  @Patch('objections/:objectionId/review')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @ApiOperation({
    summary: 'مراجعة اعتراض (قبول / رفض) + C9 Seal + إغلاق المخالفة تلقائياً عند القبول',
  })
  reviewObjection(
    @Param('tenantId')    tenantId:    string,
    @Param('objectionId') objectionId: string,
    @Body() dto: ReviewObjectionDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.objectionsService.reviewObjection(tenantId, objectionId, {
      decision:   dto.decision,
      reviewedBy: req.user.uid,
      reviewNote: dto.reviewNote,
    });
  }

  // ── Documents ─────────────────────────────────────────────────────────────────

  @Post('objections/:objectionId/documents')
  @Version('1')
  @Roles('employee', 'entity_admin', 'sovereign')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'إرفاق مستند دليل بالاعتراض + C9 Seal' })
  addDocument(
    @Param('tenantId')    tenantId:    string,
    @Param('objectionId') objectionId: string,
    @Body() dto: AddDocumentDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.objectionsService.addDocument(tenantId, objectionId, {
      label:      dto.label,
      fileUrl:    dto.fileUrl,
      uploadedBy: req.user.uid,
    });
  }

  @Get('objections/:objectionId/documents')
  @Version('1')
  @Roles('employee', 'entity_admin', 'sovereign')
  @ApiOperation({ summary: 'قائمة مستندات الاعتراض' })
  listDocuments(
    @Param('tenantId')    tenantId:    string,
    @Param('objectionId') objectionId: string,
  ) {
    return this.objectionsService.listDocuments(tenantId, objectionId);
  }
}
