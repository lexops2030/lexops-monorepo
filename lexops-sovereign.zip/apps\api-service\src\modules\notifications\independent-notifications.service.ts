/**
 * LexOps — Independent Worker Notifications Service  (Sprint 8)
 *
 * Dedicated notification path for Independent Workers (tenantId starts with IND_).
 *
 * Sovereign Rule — Independent workers are TOP PRIORITY:
 *   - OTP / Authentication challenges → SMS (highest reliability, no push dependency)
 *   - Critical legal alerts (violation, objection status) → SMS + Push simultaneously
 *   - Daily LEXI interactive tips → Push only (non-critical, interactive)
 *
 * Data isolation: all logs go to /users/{uid}/personal_vault/notification_log/
 * No cross-entity exposure — the fullPayload never contains entity tenantIds.
 *
 * Privacy amplification for IND_ users:
 *   maskedBody shows ZERO personally identifiable information —
 *   only generic action prompts are shown on lock-screen.
 */

import { Injectable, Logger, ForbiddenException } from '@nestjs/common';
import { NotificationsService, DispatchInput, DispatchResult } from './notifications.service';
import { C9LedgerRepository } from '../../database/c9-ledger.repository';
import { randomUUID } from 'crypto';

// ── OTP ──────────────────────────────────────────────────────────────────────

export interface OtpDispatchResult {
  otpRef:    string;    // server-side reference (not the OTP itself — never logged raw)
  channel:   'sms';
  maskedTo:  string;    // e.g. "+966 ●●●● ●●●● 12"
  expiresAt: string;    // ISO
}

// ── Service ───────────────────────────────────────────────────────────────────

@Injectable()
export class IndependentNotificationsService {
  private readonly logger = new Logger(IndependentNotificationsService.name);

  constructor(
    private readonly notifService: NotificationsService,
    private readonly c9:           C9LedgerRepository,
  ) {}

  // ══════════════════════════════════════════════════════════════════════════════
  // OTP / AUTHENTICATION — SMS only (highest reliability)
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * sendOtp — sends a one-time password via SMS to the independent worker's phone.
   *
   * Security rules:
   *   - The raw OTP is NEVER stored in Firestore, C9, or any log.
   *   - Only a hashed reference (otpRef) is recorded.
   *   - The masked phone number is shown in the audit trail.
   *   - OTP expires after 5 minutes (enforced by caller, not here).
   */
  async sendOtp(params: {
    uid:   string;
    phone: string;  // E.164
    otp:   string;  // raw OTP — never persisted
  }): Promise<OtpDispatchResult> {
    this.assertIndependent(`IND_${params.uid}`);

    const tenantId   = `IND_${params.uid}`;
    const maskedTo   = this.maskPhone(params.phone);
    const expiresAt  = new Date(Date.now() + 5 * 60_000).toISOString();

    // SMS body uses the raw OTP — but we pass a generic masked title to the log
    const result = await this.notifService.dispatch({
      tenantId,
      recipientUid:   params.uid,
      recipientPhone: params.phone,
      eventType:      'INDEPENDENT_OTP',
      titleTemplate:  'LexOps — رمز التحقق',
      bodyTemplate:   `رمز التحقق الخاص بك: ${params.otp} — صالح لمدة 5 دقائق. لا تشاركه مع أحد.`,
      fullPayload: {
        uid:      params.uid,
        maskedTo,
        expiresAt,
        otpHash:  '[REDACTED — never stored]',
      },
      actorUid: params.uid,
    });

    const otpRef = `otp_${randomUUID().replace(/-/g, '').slice(0, 16)}`;

    // C9 — log OTP dispatch with masked phone only (no raw OTP)
    await this.c9.append({
      tenantId,
      eventType:   'INDEPENDENT_OTP_DISPATCHED',
      actorUid:    params.uid,
      actorRole:   'freelancer',
      subjectUid:  params.uid,
      subjectType: 'independent_otp',
      payload: {
        otpRef,
        maskedPhone: maskedTo,
        expiresAt,
        channel:    'sms',
        notifId:    result.notifId,
      },
    });

    this.logger.log(`[IND-Notif] OTP dispatched → ${maskedTo} ref=${otpRef}`);

    return { otpRef, channel: 'sms', maskedTo, expiresAt };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // CRITICAL LEGAL ALERT — SMS + Push simultaneously (top priority)
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * sendLegalAlert — for critical legal events affecting the independent worker.
   * Examples: new violation in personal_vault, objection status changed, C9 seal alert.
   *
   * Both SMS and Push are fired simultaneously regardless of which channel is primary.
   * maskedBody contains ZERO sensitive details — only a generic "action required" prompt.
   */
  async sendLegalAlert(params: {
    uid:          string;
    phone?:       string;
    fcmToken?:    string;
    alertType:    'violation_added' | 'objection_accepted' | 'objection_rejected' | 'trust_score_changed';
    actionUrl?:   string;   // deep-link into the app
  }): Promise<DispatchResult> {
    this.assertIndependent(`IND_${params.uid}`);

    const tenantId = `IND_${params.uid}`;

    const ALERT_MESSAGES: Record<typeof params.alertType, { title: string; body: string }> = {
      violation_added:       {
        title: '⚖️ تنبيه قانوني — إجراء مطلوب',
        body:  'تم تسجيل حدث قانوني جديد في خزانتك الشخصية. افتح LexOps لمراجعته.',
      },
      objection_accepted:    {
        title: '✅ اعتراضك قُبل',
        body:  'تم قبول اعتراضك وإغلاق الملف. افتح LexOps لعرض التفاصيل.',
      },
      objection_rejected:    {
        title: '⚠️ اعتراضك يحتاج مراجعة',
        body:  'تم اتخاذ قرار بشأن اعتراضك. افتح LexOps للاطلاع على التفاصيل.',
      },
      trust_score_changed:   {
        title: '📊 تحديث درجة الثقة',
        body:  'تم تحديث درجة ثقتك في المنصة. افتح LexOps لمعرفة التفاصيل.',
      },
    };

    const msg = ALERT_MESSAGES[params.alertType];

    // Fire via the main service (routing matrix maps INDEPENDENT_LEGAL_ALERT → SMS + Push)
    const result = await this.notifService.dispatch({
      tenantId,
      recipientUid:   params.uid,
      recipientPhone: params.phone,
      fcmToken:       params.fcmToken,
      eventType:      'INDEPENDENT_LEGAL_ALERT',
      titleTemplate:  msg.title,
      bodyTemplate:   msg.body,
      fullPayload: {
        uid:       params.uid,
        alertType: params.alertType,
        actionUrl: params.actionUrl ?? 'lexops://vault',
        // Sensitive alert details never in push payload
        note:      'Full details available in personal_vault only.',
      },
      actorUid: params.uid,
    });

    this.logger.warn(
      `[IND-Notif] Legal alert dispatched: uid=${params.uid} ` +
      `type=${params.alertType} status=${result.status}`,
    );

    return result;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // DAILY LEXI INTERACTIVE TIP — Push only (non-critical)
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * sendLexiTip — Push-only daily tip from LEXI to help the independent worker
   * understand their legal rights and improve their trust_score.
   *
   * Lock-screen preview is fully generic — no personal data.
   */
  async sendLexiTip(params: {
    uid:        string;
    fcmToken:   string;
    tip:        string;    // LEXI-generated Arabic tip text
    trustScore: number;    // Used to personalise tone — NOT sent in push body
  }): Promise<DispatchResult> {
    this.assertIndependent(`IND_${params.uid}`);

    const tenantId = `IND_${params.uid}`;

    // Truncate tip for push body (max ~100 chars for lock-screen)
    const shortTip = params.tip.length > 100
      ? `${params.tip.slice(0, 97)}…`
      : params.tip;

    return this.notifService.dispatch({
      tenantId,
      recipientUid: params.uid,
      fcmToken:     params.fcmToken,
      eventType:    'INDEPENDENT_LEXI_TIP',
      titleTemplate: '💡 نصيحة LEXI اليومية',
      bodyTemplate:  shortTip,
      fullPayload: {
        uid:        params.uid,
        fullTip:    params.tip,
        trustScore: '[REDACTED]',   // trust_score is sensitive — C9 only
        sentAt:     new Date().toISOString(),
      },
      actorUid: 'system',
    });
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // QUERIES
  // ══════════════════════════════════════════════════════════════════════════════

  getMyNotifications(uid: string) {
    return this.notifService.getMyNotifications(`IND_${uid}`, uid);
  }

  // ── Private helpers ────────────────────────────────────────────────────────

  private assertIndependent(tenantId: string): void {
    if (!tenantId.startsWith('IND_')) {
      throw new ForbiddenException(
        `IndependentNotificationsService: tenantId '${tenantId}' is not an IND_ tenant. ` +
        `This service is exclusively for independent workers.`,
      );
    }
  }

  private maskPhone(phone: string): string {
    // Keep country code + last 2 digits visible: "+966 ●●●● ●●●● 12"
    if (phone.length < 6) return '●●●●●●';
    const visible = phone.slice(-2);
    return `${phone.slice(0, 4)} ●●●● ●●●● ${visible}`;
  }
}
