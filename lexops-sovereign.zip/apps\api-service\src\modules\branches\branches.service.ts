import { Injectable, NotFoundException } from '@nestjs/common';
import { BranchesRepository, BranchDocument } from './branches.repository';
import { C9LedgerRepository } from '../../database/c9-ledger.repository';

@Injectable()
export class BranchesService {
  constructor(
    private readonly branchesRepo: BranchesRepository,
    private readonly c9: C9LedgerRepository,
  ) {}

  async findAll(tenantId: string): Promise<BranchDocument[]> {
    return this.branchesRepo.findAllByTenant(tenantId);
  }

  async findOne(tenantId: string, branchId: string): Promise<BranchDocument> {
    const branch = await this.branchesRepo.findById(tenantId, branchId);
    if (!branch) {
      throw new NotFoundException(
        `Branch '${branchId}' not found in entity '${tenantId}'`,
      );
    }
    return branch;
  }

  /**
   * Create a branch and seal the event in the C9 Ledger.
   * Validates geofence radiusMeters is within sensible bounds (50m – 5000m).
   */
  async create(
    tenantId: string,
    branchId: string,
    data: Omit<BranchDocument, 'branchId' | 'tenantId' | 'createdAt' | 'updatedAt' | 'employeeCount'>,
    actorUid: string,
  ): Promise<BranchDocument> {
    const { radiusMeters } = data.geofence;
    if (radiusMeters < 50 || radiusMeters > 5000) {
      throw new Error(
        `Geofence radiusMeters must be between 50 and 5000. Got: ${radiusMeters}`,
      );
    }

    const branch = await this.branchesRepo.create(tenantId, branchId, {
      ...data,
      createdBy: actorUid,
    });

    // ── C9 Seal ─────────────────────────────────────────────────────────────
    await this.c9.append({
      tenantId,
      eventType: 'BRANCH_CREATED',
      actorUid,
      actorRole: 'entity_admin',
      subjectUid: branchId,
      subjectType: 'branch',
      payload: {
        branchId,
        name: branch.name,
        city: branch.city,
        geofence: branch.geofence,
      },
    });

    return branch;
  }

  async update(
    tenantId: string,
    branchId: string,
    data: Partial<Omit<BranchDocument, 'branchId' | 'tenantId' | 'createdAt' | 'createdBy'>>,
    actorUid: string,
  ): Promise<void> {
    await this.branchesRepo.update(tenantId, branchId, data);

    await this.c9.append({
      tenantId,
      eventType: 'BRANCH_UPDATED',
      actorUid,
      actorRole: 'entity_admin',
      subjectUid: branchId,
      subjectType: 'branch',
      payload: data as Record<string, unknown>,
    });
  }
}
