/**
 * LexOps — Legal Controller  (Sprint 7 — Legal Engine)
 *
 * Routes (under /v1/entities/:tenantId/legal):
 *
 *   POST /legal/objections/:objectionId/generate
 *     → Generate AI legal draft via Vertex AI (Gemini 1.5 Pro)
 *     → Restricted to entity_admin and sovereign
 *     → Applies Royal Decree 11438 Filter automatically
 *     → Seals LEGAL_DRAFT_GENERATED in C9 Ledger
 *     → Transitions objection to 'under_review'
 */

import {
  Controller, Post,
  Param, Request, Version, UseGuards,
  HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiParam } from '@nestjs/swagger';
import { LegalService } from './legal.service';
import {
  FirebaseAuthGuard, TenantScopeGuard, Roles, LexOpsClaims,
} from '../auth/firebase.guard';
import { Request as ExpressRequest } from 'express';

@ApiTags('Legal AI Engine — محرك الدفاع القانوني')
@ApiBearerAuth('Firebase-JWT')
@Controller('entities/:tenantId/legal')
@UseGuards(FirebaseAuthGuard, TenantScopeGuard)
export class LegalController {
  constructor(private readonly legalService: LegalService) {}

  /**
   * POST /v1/entities/:tenantId/legal/objections/:objectionId/generate
   *
   * Triggers Vertex AI (Gemini 1.5 Pro) to analyze the violation + objection content
   * and produce a structured legal defense draft:
   *   { legalArgument, factsSummary, recommendedDocuments, riskLevel }
   *
   * Royal Decree 11438 Filter is applied automatically server-side — no client input needed.
   * The draft is saved under objection.lexiDraft and the objection status becomes 'under_review'.
   */
  @Post('objections/:objectionId/generate')
  @Version('1')
  @Roles('entity_admin', 'sovereign')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'توليد مسودة قانونية بالذكاء الاصطناعي (Gemini 1.5 Pro) — فلتر المرسوم 11438',
    description:
      'يحلّل LEXI تفاصيل المخالفة واعتراض الموظف ويُنتج حجة قانونية دفاعية هيكلية. ' +
      'يُطبَّق فلتر المرسوم الملكي 11438 تلقائياً: إذا كانت المخالفة غير جسيمة وطُبِّقت ' +
      'عقوبة أشد من الإنذار دون إنذار مسبق، يستشهد LEXI بالمادة 40 من المرسوم. ' +
      'تُحفظ المسودة في objection.lexiDraft وتختم في C9 Ledger.',
  })
  @ApiParam({ name: 'tenantId',    description: 'رقم المنشأة (Fortress 700)' })
  @ApiParam({ name: 'objectionId', description: 'معرّف الاعتراض' })
  generateDraft(
    @Param('tenantId')    tenantId:    string,
    @Param('objectionId') objectionId: string,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    return this.legalService.generateObjectionDraft(
      tenantId,
      objectionId,
      {
        uid:          req.user.uid,
        role:         req.user.role,
        routeToVault: req.user.routeToVault,
      },
    );
  }
}
