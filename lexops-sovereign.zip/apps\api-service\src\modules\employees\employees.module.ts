import { Module } from '@nestjs/common';
import { EmployeesRepository } from './employees.repository';
import { EmployeesService } from './employees.service';
import { EmployeesController } from './employees.controller';
import { BranchesModule } from '../branches/branches.module';

@Module({
  imports: [BranchesModule],   // Injects BranchesRepository for cross-branch validation
  providers: [EmployeesRepository, EmployeesService],
  controllers: [EmployeesController],
  exports: [EmployeesRepository, EmployeesService],
})
export class EmployeesModule {}
