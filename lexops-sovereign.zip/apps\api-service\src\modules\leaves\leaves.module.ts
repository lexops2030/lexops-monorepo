import { Module } from '@nestjs/common';
import { LeavesRepository } from './leaves.repository';
import { LeavePoliciesEngine } from './leave-policies.engine';
import { LeavesService } from './leaves.service';
import { LeavesController } from './leaves.controller';

@Module({
  providers: [LeavesRepository, LeavePoliciesEngine, LeavesService],
  controllers: [LeavesController],
  exports: [LeavesService, LeavesRepository],
})
export class LeavesModule {}
