/**
 * LexOps — Notifications Repository  (Sprint 8)
 *
 * Firestore paths:
 *   Entity users  → /entities/{tenantId}/notification_log/{notifId}
 *   Independent   → /users/{uid}/personal_vault/notification_log/{notifId}
 *
 * Every dispatched notification record is append-only.
 * The delivery reference ID is also forwarded to C9LedgerService by
 * NotificationsService for undeniable legal proof of delivery.
 */

import { Injectable, Inject } from '@nestjs/common';
import { Firestore, FieldValue } from '@google-cloud/firestore';
import { randomUUID } from 'crypto';

// ── Types ─────────────────────────────────────────────────────────────────────

export type NotifChannel   = 'sms' | 'email' | 'push';
export type NotifSeverity  = 'info' | 'warning' | 'critical';
export type NotifStatus    = 'queued' | 'sent' | 'failed' | 'masked';

export type NotifEventType =
  | 'GEOFENCE_BREACH'
  | 'DOCUMENT_EXPIRY_90D'
  | 'DOCUMENT_EXPIRY_FINAL_3D'
  | 'FAKE_GPS_DETECTED'
  | 'LEXI_DAILY_REPORT'
  | 'PROBATION_ALERT'
  | 'PAYROLL_CLOSED'
  | 'OBJECTION_STATUS_UPDATE'
  | 'VIOLATION_AUTO_GENERATED'
  | 'INDEPENDENT_OTP'
  | 'INDEPENDENT_LEGAL_ALERT'
  | 'INDEPENDENT_LEXI_TIP'
  | 'GENESIS_SEAL';

export interface NotificationRecord {
  notifId:       string;
  tenantId:      string;            // entity tenantId or IND_{uid}
  recipientUid:  string;
  eventType:     NotifEventType;
  channel:       NotifChannel;
  severity:      NotifSeverity;
  status:        NotifStatus;
  /** Privacy-masked preview (safe for lock-screen) */
  maskedTitle:   string;
  maskedBody:    string;
  /** Full payload stored server-side — never sent to device directly */
  fullPayload:   Record<string, unknown>;
  /** Provider reference ID (Twilio SID / FCM messageId / SendGrid ID) */
  providerRefId?: string;
  deliveredAt?:  FirebaseFirestore.Timestamp;
  failureReason?: string;
  createdAt:     FirebaseFirestore.Timestamp;
}

// ── Repository ────────────────────────────────────────────────────────────────

@Injectable()
export class NotificationsRepository {
  constructor(@Inject('FIRESTORE') private readonly db: Firestore) {}

  // ── Paths ────────────────────────────────────────────────────────────────────

  private entityLogCol(tenantId: string) {
    return this.db
      .collection('entities').doc(tenantId)
      .collection('notification_log');
  }

  private independentLogCol(uid: string) {
    return this.db
      .collection('users').doc(uid)
      .collection('personal_vault')
      .doc('notification_log')
      .collection('items');
  }

  private isIndependent(tenantId: string) {
    return tenantId.startsWith('IND_');
  }

  // ── Create ───────────────────────────────────────────────────────────────────

  async create(
    data: Omit<NotificationRecord, 'notifId' | 'createdAt'>,
  ): Promise<NotificationRecord> {
    const notifId = `ntf_${randomUUID().replace(/-/g, '').slice(0, 14)}`;
    const now     = FieldValue.serverTimestamp() as unknown as FirebaseFirestore.Timestamp;

    const record: NotificationRecord = { ...data, notifId, createdAt: now };

    if (this.isIndependent(data.tenantId)) {
      const uid = data.tenantId.replace('IND_', '');
      await this.independentLogCol(uid).doc(notifId).set(record);
    } else {
      await this.entityLogCol(data.tenantId).doc(notifId).set(record);
    }

    return record;
  }

  // ── Mark delivered / failed ───────────────────────────────────────────────────

  async markDelivered(
    tenantId:      string,
    notifId:       string,
    providerRefId: string,
  ): Promise<void> {
    const update = {
      status:        'sent' as NotifStatus,
      providerRefId,
      deliveredAt:   FieldValue.serverTimestamp(),
    };

    if (this.isIndependent(tenantId)) {
      const uid = tenantId.replace('IND_', '');
      await this.independentLogCol(uid).doc(notifId).update(update);
    } else {
      await this.entityLogCol(tenantId).doc(notifId).update(update);
    }
  }

  async markFailed(
    tenantId:      string,
    notifId:       string,
    failureReason: string,
  ): Promise<void> {
    const update = { status: 'failed' as NotifStatus, failureReason };

    if (this.isIndependent(tenantId)) {
      const uid = tenantId.replace('IND_', '');
      await this.independentLogCol(uid).doc(notifId).update(update);
    } else {
      await this.entityLogCol(tenantId).doc(notifId).update(update);
    }
  }

  // ── Queries ───────────────────────────────────────────────────────────────────

  async findByRecipient(
    tenantId:     string,
    recipientUid: string,
    limit = 50,
  ): Promise<NotificationRecord[]> {
    if (this.isIndependent(tenantId)) {
      const uid  = tenantId.replace('IND_', '');
      const snap = await this.independentLogCol(uid)
        .orderBy('createdAt', 'desc').limit(limit).get();
      return snap.docs.map(d => d.data() as NotificationRecord);
    }

    const snap = await this.entityLogCol(tenantId)
      .where('recipientUid', '==', recipientUid)
      .orderBy('createdAt', 'desc')
      .limit(limit)
      .get();
    return snap.docs.map(d => d.data() as NotificationRecord);
  }

  async findByTenant(tenantId: string, limit = 100): Promise<NotificationRecord[]> {
    const snap = await this.entityLogCol(tenantId)
      .orderBy('createdAt', 'desc').limit(limit).get();
    return snap.docs.map(d => d.data() as NotificationRecord);
  }
}
