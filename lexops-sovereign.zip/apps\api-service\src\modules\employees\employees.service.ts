import {
  Injectable, NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { EmployeesRepository, EmployeeDocument, EmployeeStatus } from './employees.repository';
import { BranchesRepository } from '../branches/branches.repository';
import { C9LedgerRepository } from '../../database/c9-ledger.repository';
import { randomUUID } from 'crypto';

@Injectable()
export class EmployeesService {
  constructor(
    private readonly employeesRepo: EmployeesRepository,
    private readonly branchesRepo: BranchesRepository,
    private readonly c9: C9LedgerRepository,
  ) {}

  async findAll(
    tenantId: string,
    filters: { branchId?: string; status?: EmployeeStatus } = {},
  ): Promise<EmployeeDocument[]> {
    return this.employeesRepo.findAllByTenant(tenantId, filters);
  }

  async findOne(tenantId: string, employeeId: string): Promise<EmployeeDocument> {
    const emp = await this.employeesRepo.findById(tenantId, employeeId);
    if (!emp) {
      throw new NotFoundException(
        `Employee '${employeeId}' not found in entity '${tenantId}'`,
      );
    }
    return emp;
  }

  /**
   * Create an employee.
   *
   * ── Cross-Branch Validation (HTTP 422) ─────────────────────────────────────
   * Validates that the supplied branchId physically belongs to the same tenantId.
   * This prevents cross-entity branch assignment — a Fortress 700 core rule.
   */
  async create(
    tenantId: string,
    data: Omit<EmployeeDocument, 'employeeId' | 'tenantId' | 'createdAt' | 'updatedAt'>,
    actorUid: string,
  ): Promise<EmployeeDocument> {
    // ── 422 Guard: verify branch belongs to same tenant ────────────────────
    const branchExists = await this.branchesRepo.exists(tenantId, data.branchId);
    if (!branchExists) {
      throw new UnprocessableEntityException(
        `[Fortress 700] Branch '${data.branchId}' does not belong to entity '${tenantId}'. ` +
        `Cross-entity branch assignment is prohibited.`,
      );
    }

    const employeeId = `emp_${randomUUID().replace(/-/g, '').slice(0, 14)}`;

    const employee = await this.employeesRepo.create(tenantId, employeeId, {
      ...data,
      isActive: true,
      createdBy: actorUid,
    });

    // ── Increment branch employee counter ─────────────────────────────────
    await this.branchesRepo.adjustEmployeeCount(tenantId, data.branchId, 1);

    // ── C9 Seal ────────────────────────────────────────────────────────────
    await this.c9.append({
      tenantId,
      eventType: 'EMPLOYEE_CREATED',
      actorUid,
      actorRole: 'entity_admin',
      subjectUid: employeeId,
      subjectType: 'employee',
      payload: {
        employeeId,
        nationalId: data.nationalId,
        name: data.name,
        position: data.position,
        branchId: data.branchId,
        employmentType: data.employmentType,
        joinedAt: data.joinedAt,
      },
    });

    return employee;
  }

  async update(
    tenantId: string,
    employeeId: string,
    data: Partial<Omit<EmployeeDocument, 'employeeId' | 'tenantId' | 'nationalId' | 'createdAt' | 'createdBy'>>,
    actorUid: string,
  ): Promise<void> {
    // If changing branch — re-validate cross-entity rule
    if (data.branchId) {
      const branchExists = await this.branchesRepo.exists(tenantId, data.branchId);
      if (!branchExists) {
        throw new UnprocessableEntityException(
          `[Fortress 700] Branch '${data.branchId}' does not belong to entity '${tenantId}'.`,
        );
      }
    }

    await this.employeesRepo.update(tenantId, employeeId, data);

    await this.c9.append({
      tenantId,
      eventType: 'EMPLOYEE_UPDATED',
      actorUid,
      actorRole: 'entity_admin',
      subjectUid: employeeId,
      subjectType: 'employee',
      payload: data as Record<string, unknown>,
    });
  }

  async terminate(tenantId: string, employeeId: string, actorUid: string): Promise<void> {
    const emp = await this.findOne(tenantId, employeeId);
    await this.employeesRepo.deactivate(tenantId, employeeId);
    await this.branchesRepo.adjustEmployeeCount(tenantId, emp.branchId, -1);

    await this.c9.append({
      tenantId,
      eventType: 'EMPLOYEE_TERMINATED',
      actorUid,
      actorRole: 'entity_admin',
      subjectUid: employeeId,
      subjectType: 'employee',
      payload: { employeeId, reason: 'admin_termination' },
    });
  }
}
