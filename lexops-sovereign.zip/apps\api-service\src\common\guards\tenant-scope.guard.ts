/**
 * LexOps — TenantScope Guard (Fortress 700 Cross-Tenant Isolation)
 *
 * Ensures that the authenticated user can ONLY access resources
 * belonging to their own tenantId. Sovereign bypasses this check.
 *
 * Usage: @UseGuards(TenantScopeGuard) on controller or route level.
 * The route param or body field containing the tenantId must be named
 * consistently as `tenantId` or read from the header `x-tenant-id`.
 *
 * Returns HTTP 403 if the caller's tenantId ≠ the resource's tenantId.
 */

import {
  CanActivate,
  ExecutionContext,
  Injectable,
  ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Request } from 'express';
import type { LexOpsClaims } from '../modules/auth/firebase.guard';

export const TENANT_PARAM_KEY = 'tenantParam';
export const TenantParam = (paramName: string) =>
  Reflect.metadata(TENANT_PARAM_KEY, paramName);

@Injectable()
export class TenantScopeGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const req = context.switchToHttp().getRequest<Request & { user: LexOpsClaims }>();
    const user = req.user;

    // Sovereign has unrestricted cross-tenant read/write
    if (user?.role === 'sovereign') return true;

    // Resolve which tenantId to validate against (param > body > header)
    const paramName = this.reflector.getAllAndOverride<string>(TENANT_PARAM_KEY, [
      context.getHandler(),
      context.getClass(),
    ]) ?? 'tenantId';

    const resourceTenantId: string | undefined =
      req.params[paramName] ??
      (req.body as Record<string, unknown>)?.[paramName] as string ??
      req.headers['x-tenant-id'] as string;

    if (!resourceTenantId) {
      throw new ForbiddenException(
        'Fortress 700: tenantId could not be resolved from the request',
      );
    }

    if (user?.tenantId !== resourceTenantId) {
      throw new ForbiddenException(
        `Fortress 700: Cross-tenant access denied. ` +
        `Caller tenant '${user?.tenantId}' cannot access tenant '${resourceTenantId}'.`,
      );
    }

    return true;
  }
}
