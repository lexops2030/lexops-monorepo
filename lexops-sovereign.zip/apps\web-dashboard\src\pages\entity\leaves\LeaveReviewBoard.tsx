import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  CalendarCheck, CheckCircle2, XCircle,
  Clock, Filter, ChevronDown,
} from 'lucide-react';
import { Button } from '../../../components/ui/Button';
import { Input } from '../../../components/ui/Input';
import { Select } from '../../../components/ui/Select';
import api from '../../../lib/api';
import { cn } from '../../../lib/utils';

// ── Types & constants ─────────────────────────────────────────────────────────

interface LeaveDocument {
  leaveId:       string;
  employeeUid:   string;
  leaveType:     string;
  status:        string;
  startDate:     string;
  endDate:       string;
  daysRequested: number;
  reason:        string;
  review?: {
    decision: string;
    reason:   string;
    reviewedBy: string;
  };
}

const STATUS_STYLES: Record<string, string> = {
  requested: 'border-amber-200 bg-amber-50 text-amber-700',
  approved:  'border-green-200 bg-green-50 text-green-700',
  rejected:  'border-red-200 bg-red-50 text-red-700',
  cancelled: 'border-neutral-200 bg-neutral-50 text-neutral-500',
};

const TYPE_LABELS: Record<string, string> = {
  annual: 'سنوية', sick: 'مرضية', unpaid: 'بدون راتب', other: 'أخرى',
};

const FILTER_STATUS_OPTS = [
  { value: '',           label: 'كل الحالات' },
  { value: 'requested',  label: 'قيد المراجعة' },
  { value: 'approved',   label: 'معتمدة' },
  { value: 'rejected',   label: 'مرفوضة' },
  { value: 'cancelled',  label: 'ملغاة' },
];

const FILTER_TYPE_OPTS = [
  { value: '',        label: 'كل الأنواع' },
  { value: 'annual',  label: 'سنوية' },
  { value: 'sick',    label: 'مرضية' },
  { value: 'unpaid',  label: 'بدون راتب' },
  { value: 'other',   label: 'أخرى' },
];

const TENANT_ID = import.meta.env.VITE_DEMO_TENANT_ID ?? 'ENTITY_700';

// ── Review Panel (per card) ───────────────────────────────────────────────────

function ReviewPanel({
  leave,
  onDecision,
  isPending,
}: {
  leave: LeaveDocument;
  onDecision: (leaveId: string, decision: 'approved' | 'rejected', reason: string) => void;
  isPending: boolean;
}) {
  const [decision, setDecision] = useState<'approved' | 'rejected' | null>(null);
  const [reason, setReason]     = useState('');

  if (leave.status !== 'requested') {
    return (
      <div className={cn(
        'mt-4 rounded-lg border p-3 text-xs',
        STATUS_STYLES[leave.status],
      )}>
        <span className="font-semibold">
          {leave.status === 'approved' ? 'معتمدة' : leave.status === 'rejected' ? 'مرفوضة' : 'ملغاة'}
        </span>
        {leave.review?.reason && (
          <span className="mr-2 opacity-80">— {leave.review.reason}</span>
        )}
      </div>
    );
  }

  return (
    <div className="mt-4 border-t border-neutral-100 pt-4 space-y-3">
      <div className="flex gap-2">
        <button
          onClick={() => setDecision('approved')}
          className={cn(
            'flex flex-1 items-center justify-center gap-2 rounded-lg border py-2.5 text-sm font-semibold transition-colors',
            decision === 'approved'
              ? 'border-green-500 bg-green-50 text-green-700'
              : 'border-neutral-200 text-neutral-600 hover:border-green-300',
          )}
        >
          <CheckCircle2 className="h-4 w-4" /> اعتماد
        </button>
        <button
          onClick={() => setDecision('rejected')}
          className={cn(
            'flex flex-1 items-center justify-center gap-2 rounded-lg border py-2.5 text-sm font-semibold transition-colors',
            decision === 'rejected'
              ? 'border-red-400 bg-red-50 text-red-700'
              : 'border-neutral-200 text-neutral-600 hover:border-red-300',
          )}
        >
          <XCircle className="h-4 w-4" /> رفض
        </button>
      </div>

      <Input
        id={`reason-${leave.leaveId}`}
        placeholder="سبب القرار (يُختم في سجل C9)..."
        value={reason}
        onChange={(e) => setReason(e.target.value)}
      />

      <Button
        className="w-full"
        disabled={!decision || reason.trim().length < 3}
        loading={isPending}
        onClick={() => decision && onDecision(leave.leaveId, decision, reason)}
      >
        تأكيد القرار وختم C9
      </Button>
    </div>
  );
}

// ── Leave Card ────────────────────────────────────────────────────────────────

function LeaveCard({
  leave,
  onDecision,
  isPending,
}: {
  leave: LeaveDocument;
  onDecision: (leaveId: string, decision: 'approved' | 'rejected', reason: string) => void;
  isPending: boolean;
}) {
  const [expanded, setExpanded] = useState(leave.status === 'requested');

  return (
    <div className={cn(
      'rounded-xl border bg-white shadow-card transition-all duration-200',
      leave.status === 'requested' ? 'border-amber-200' : 'border-neutral-200',
    )}>
      {/* Summary */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex w-full items-center gap-4 p-5 text-start"
      >
        <div className={cn(
          'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
          leave.status === 'requested'
            ? 'bg-amber-100'
            : leave.status === 'approved'
              ? 'bg-green-100'
              : 'bg-neutral-100',
        )}>
          <CalendarCheck className={cn(
            'h-5 w-5',
            leave.status === 'requested' ? 'text-amber-600'
              : leave.status === 'approved' ? 'text-green-600'
                : 'text-neutral-400',
          )} />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <span className={cn(
              'inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold',
              STATUS_STYLES[leave.status],
            )}>
              {leave.status === 'requested' ? 'قيد المراجعة'
                : leave.status === 'approved' ? 'معتمدة'
                  : leave.status === 'rejected' ? 'مرفوضة' : 'ملغاة'}
            </span>
            <span className="text-xs text-neutral-500">
              {TYPE_LABELS[leave.leaveType] ?? leave.leaveType}
            </span>
            <span className="text-xs font-bold text-neutral-700">
              {leave.daysRequested} يوم
            </span>
          </div>
          <p className="text-sm text-neutral-600">
            {leave.startDate} ← {leave.endDate}
          </p>
          <p className="text-xs text-neutral-400 mt-0.5 font-mono truncate">
            {leave.employeeUid}
          </p>
        </div>

        <ChevronDown className={cn(
          'h-4 w-4 text-neutral-400 shrink-0 transition-transform',
          expanded && 'rotate-180',
        )} />
      </button>

      {/* Detail */}
      {expanded && (
        <div className="border-t border-neutral-100 px-5 pb-5 animate-fade-in">
          <div className="mt-4 rounded-lg bg-neutral-50 border border-neutral-100 p-3 mb-2">
            <p className="text-xs font-semibold text-neutral-500 mb-1">سبب الموظف</p>
            <p className="text-sm text-neutral-700">{leave.reason}</p>
          </div>

          <ReviewPanel
            leave={leave}
            onDecision={onDecision}
            isPending={isPending}
          />
        </div>
      )}
    </div>
  );
}

// ── Main Board ────────────────────────────────────────────────────────────────

export default function LeaveReviewBoard() {
  const queryClient = useQueryClient();
  const [filterStatus,    setFilterStatus]    = useState('requested');
  const [filterLeaveType, setFilterLeaveType] = useState('');
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);

  const { data: leaves = [], isLoading } = useQuery<LeaveDocument[]>({
    queryKey: ['admin-leaves', TENANT_ID, filterStatus, filterLeaveType],
    queryFn: () => {
      const params = new URLSearchParams();
      if (filterStatus)    params.append('status',    filterStatus);
      if (filterLeaveType) params.append('leaveType', filterLeaveType);
      return api.get(`/entities/${TENANT_ID}/leaves?${params}`).then((r) => r.data);
    },
  });

  const reviewMutation = useMutation({
    mutationFn: ({ leaveId, decision, reason }: {
      leaveId: string; decision: 'approved' | 'rejected'; reason: string;
    }) =>
      api.patch(`/entities/${TENANT_ID}/leaves/${leaveId}/review`, { decision, reason })
         .then((r) => r.data),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['admin-leaves', TENANT_ID] });
      setToast({ msg: data.message, ok: true });
      setTimeout(() => setToast(null), 4000);
    },
    onError: () => {
      setToast({ msg: 'حدث خطأ أثناء تسجيل القرار', ok: false });
      setTimeout(() => setToast(null), 4000);
    },
  });

  const pendingCount = leaves.filter((l) => l.status === 'requested').length;

  return (
    <div>
      {/* ── Header ── */}
      <div className="mb-8 flex items-start justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-secondary/20">
            <CalendarCheck className="h-6 w-6 text-secondary-dark" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">لوحة مراجعة الإجازات</h1>
            <p className="text-sm text-neutral-500">
              كل قرار يُختم تلقائياً في سجل C9
            </p>
          </div>
        </div>
        {pendingCount > 0 && (
          <span className="flex items-center gap-1.5 rounded-full bg-amber-50 border border-amber-200 px-4 py-1.5 text-sm font-semibold text-amber-700">
            <Clock className="h-4 w-4" />
            {pendingCount} طلب قيد المراجعة
          </span>
        )}
      </div>

      {/* ── Toast ── */}
      {toast && (
        <div className={cn(
          'mb-6 flex items-center gap-3 rounded-xl border px-5 py-4 animate-fade-in',
          toast.ok ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50',
        )}>
          {toast.ok
            ? <CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" />
            : <XCircle     className="h-5 w-5 text-red-600  shrink-0" />
          }
          <p className={`text-sm font-medium ${toast.ok ? 'text-green-800' : 'text-red-700'}`}>
            {toast.msg}
          </p>
        </div>
      )}

      {/* ── Filters ── */}
      <div className="mb-6 flex flex-wrap gap-3 items-center">
        <Filter className="h-4 w-4 text-neutral-400" />
        <div className="w-44">
          <Select
            id="filter-status"
            options={FILTER_STATUS_OPTS}
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          />
        </div>
        <div className="w-40">
          <Select
            id="filter-type"
            options={FILTER_TYPE_OPTS}
            value={filterLeaveType}
            onChange={(e) => setFilterLeaveType(e.target.value)}
          />
        </div>
        <span className="text-xs text-neutral-400">{leaves.length} نتيجة</span>
      </div>

      {/* ── Cards ── */}
      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
        </div>
      ) : leaves.length === 0 ? (
        <div className="card-sovereign flex flex-col items-center justify-center py-16 text-center">
          <CalendarCheck className="h-14 w-14 text-neutral-300 mb-4" />
          <p className="text-neutral-500 font-medium">لا توجد طلبات</p>
        </div>
      ) : (
        <div className="space-y-4">
          {leaves.map((leave) => (
            <LeaveCard
              key={leave.leaveId}
              leave={leave}
              isPending={reviewMutation.isPending}
              onDecision={(leaveId, decision, reason) =>
                reviewMutation.mutate({ leaveId, decision, reason })
              }
            />
          ))}
        </div>
      )}
    </div>
  );
}
