import {
  Controller, Get, Post, Patch, Param,
  Body, Request, Version, UseGuards,
  BadRequestException,
} from '@nestjs/common';
import {
  ApiTags, ApiBearerAuth, ApiOperation,
  ApiParam, ApiBody,
} from '@nestjs/swagger';
import {
  IsString, IsNotEmpty, IsNumber, IsOptional,
  IsBoolean, Min, Max, ValidateNested, IsUUID,
} from 'class-validator';
import { Type } from 'class-transformer';
import { BranchesService } from './branches.service';
import { Roles } from '../auth/firebase.guard';
import { TenantScopeGuard } from '../../common/guards';
import { Request as ExpressRequest } from 'express';
import type { LexOpsClaims } from '../auth/firebase.guard';
import { randomUUID } from 'crypto';

// ── DTOs ──────────────────────────────────────────────────────────────────────

class GeofenceDto {
  @IsNumber() @Min(-90) @Max(90)
  lat: number;

  @IsNumber() @Min(-180) @Max(180)
  lng: number;

  @IsNumber() @Min(50) @Max(5000)
  radiusMeters: number;
}

class CreateBranchDto {
  @IsString() @IsNotEmpty()
  name: string;

  @IsString() @IsOptional()
  nameEn?: string;

  @IsString() @IsNotEmpty()
  city: string;

  @IsString() @IsNotEmpty()
  address: string;

  @ValidateNested()
  @Type(() => GeofenceDto)
  geofence: GeofenceDto;

  @IsString() @IsOptional()
  managerUid?: string;
}

class UpdateBranchDto {
  @IsString() @IsOptional()
  name?: string;

  @IsString() @IsOptional()
  nameEn?: string;

  @IsString() @IsOptional()
  city?: string;

  @IsString() @IsOptional()
  address?: string;

  @ValidateNested()
  @Type(() => GeofenceDto)
  @IsOptional()
  geofence?: GeofenceDto;

  @IsString() @IsOptional()
  managerUid?: string;

  @IsBoolean() @IsOptional()
  isActive?: boolean;
}

// ── Controller ────────────────────────────────────────────────────────────────

@ApiTags('Branches — Fortress 700')
@ApiBearerAuth('Firebase-JWT')
@Controller('entities/:tenantId/branches')
@UseGuards(TenantScopeGuard)
export class BranchesController {
  constructor(private readonly branchesService: BranchesService) {}

  @Get()
  @Version('1')
  @Roles('sovereign', 'entity_admin')
  @ApiOperation({ summary: 'List all active branches for an entity' })
  @ApiParam({ name: 'tenantId', description: 'Entity 700-series ID' })
  findAll(@Param('tenantId') tenantId: string) {
    return this.branchesService.findAll(tenantId);
  }

  @Get(':branchId')
  @Version('1')
  @Roles('sovereign', 'entity_admin', 'employee')
  @ApiOperation({ summary: 'Get a single branch by ID' })
  findOne(
    @Param('tenantId') tenantId: string,
    @Param('branchId') branchId: string,
  ) {
    return this.branchesService.findOne(tenantId, branchId);
  }

  @Post()
  @Version('1')
  @Roles('sovereign', 'entity_admin')
  @ApiOperation({ summary: 'Create a new branch with geofencing config' })
  @ApiBody({ type: CreateBranchDto })
  create(
    @Param('tenantId') tenantId: string,
    @Body() dto: CreateBranchDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    const branchId = `branch_${randomUUID().replace(/-/g, '').slice(0, 12)}`;
    return this.branchesService.create(tenantId, branchId, {
      ...dto,
      isActive: true,
      createdBy: req.user.uid,
    }, req.user.uid);
  }

  @Patch(':branchId')
  @Version('1')
  @Roles('sovereign', 'entity_admin')
  @ApiOperation({ summary: 'Update branch details or geofence' })
  update(
    @Param('tenantId') tenantId: string,
    @Param('branchId') branchId: string,
    @Body() dto: UpdateBranchDto,
    @Request() req: ExpressRequest & { user: LexOpsClaims },
  ) {
    if (Object.keys(dto).length === 0) {
      throw new BadRequestException('Update body cannot be empty');
    }
    return this.branchesService.update(tenantId, branchId, dto, req.user.uid);
  }
}
