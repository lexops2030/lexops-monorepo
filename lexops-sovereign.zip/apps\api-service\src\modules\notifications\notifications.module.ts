import { Module } from '@nestjs/common';
import { NotificationsRepository } from './notifications.repository';
import { NotificationsService } from './notifications.service';
import { IndependentNotificationsService } from './independent-notifications.service';
import {
  NotificationsController,
  IndependentNotificationsController,
} from './notifications.controller';
import { DatabaseModule } from '../../database/database.module';

@Module({
  imports: [DatabaseModule],   // Firestore + C9LedgerRepository
  providers: [
    NotificationsRepository,
    NotificationsService,
    IndependentNotificationsService,
  ],
  controllers: [
    NotificationsController,
    IndependentNotificationsController,
  ],
  exports: [NotificationsService, IndependentNotificationsService],
})
export class NotificationsModule {}
