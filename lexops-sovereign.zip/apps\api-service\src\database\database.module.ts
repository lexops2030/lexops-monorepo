import { Module, Global } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Firestore } from '@google-cloud/firestore';
import { Pool } from 'pg';
import { EntitiesRepository } from '../modules/entities/entities.repository';
import { UsersRepository } from '../modules/users/users.repository';
import { C9LedgerRepository } from './c9-ledger.repository';

@Global()
@Module({
  providers: [
    // ── Firestore Client ────────────────────────────────────────────────────────
    {
      provide: 'FIRESTORE',
      useFactory: (config: ConfigService) =>
        new Firestore({
          projectId: config.getOrThrow<string>('GCP_PROJECT_ID'),
          // In Cloud Run: uses ADC automatically
          // Locally: set GOOGLE_APPLICATION_CREDENTIALS
          databaseId: config.get<string>('FIRESTORE_DATABASE', '(default)'),
          preferRest: false,
        }),
      inject: [ConfigService],
    },

    // ── PostgreSQL Pool (C9 Ledger) ─────────────────────────────────────────────
    {
      provide: 'PG_POOL',
      useFactory: (config: ConfigService) =>
        new Pool({
          connectionString: config.getOrThrow<string>('DATABASE_URL'),
          max: 10,
          idleTimeoutMillis: 30_000,
          connectionTimeoutMillis: 5_000,
          ssl: config.get<string>('NODE_ENV') === 'production'
            ? { rejectUnauthorized: true }
            : false,
        }),
      inject: [ConfigService],
    },

    EntitiesRepository,
    UsersRepository,
    C9LedgerRepository,
  ],
  exports: ['FIRESTORE', 'PG_POOL', EntitiesRepository, UsersRepository, C9LedgerRepository],
})
export class DatabaseModule {}
